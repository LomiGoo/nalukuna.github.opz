package mvc;

public class MVCPattern {

    public static void main(String[] args) {
        Student model = retriveStudentFromDatabase();
        
        StudentView view = new StudentView();
        StudentController ctrl = new StudentController(model, view);
        ctrl.updateView();
        ctrl.setStudentName("Jose Rizal");
        ctrl.updateView();
    }    
    
    private static Student retriveStudentFromDatabase() {
        Student student = new Student();
        student.setName("Juan Luna");
        student.setRollNo("10-231036");
        return student;
    }
}
