package login_and_Calculator;

public class Calculator {

    public static void main(String[] args) {
        loginFrame logFrame = new loginFrame();
        
        logFrame.setLocationRelativeTo(null);
        
        logFrame.setVisible(true);     
    }
    
}
