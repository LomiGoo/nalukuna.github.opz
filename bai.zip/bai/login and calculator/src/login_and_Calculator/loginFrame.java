package login_and_Calculator;

public class loginFrame extends javax.swing.JFrame {
    
    public loginFrame() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        titleLabel = new javax.swing.JLabel();
        enterCalcuButton = new javax.swing.JButton();
        passwordField = new javax.swing.JPasswordField();
        passwordLabel = new javax.swing.JLabel();
        userField = new javax.swing.JTextField();
        nameLabel = new javax.swing.JLabel();
        passErrorDisplay = new javax.swing.JLabel();
        userErrorDisplay = new javax.swing.JLabel();
        counter = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Login");
        setResizable(false);
        setSize(new java.awt.Dimension(800, 600));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(153, 0, 153));
        jPanel1.setPreferredSize(new java.awt.Dimension(358, 488));

        titleLabel.setBackground(new java.awt.Color(51, 0, 51));
        titleLabel.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        titleLabel.setForeground(new java.awt.Color(255, 255, 255));
        titleLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titleLabel.setText("Calculator System");
        titleLabel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        titleLabel.setOpaque(true);

        enterCalcuButton.setBackground(new java.awt.Color(51, 0, 51));
        enterCalcuButton.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        enterCalcuButton.setForeground(new java.awt.Color(255, 255, 255));
        enterCalcuButton.setText("Enter Calculator");
        enterCalcuButton.addActionListener(this::enterCalcuButtonActionPerformed);

        passwordField.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        passwordField.setToolTipText("");
        passwordField.addActionListener(this::passwordFieldActionPerformed);

        passwordLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        passwordLabel.setForeground(new java.awt.Color(255, 255, 255));
        passwordLabel.setText("Password :");

        userField.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        nameLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        nameLabel.setForeground(new java.awt.Color(255, 255, 255));
        nameLabel.setText("Name :");

        passErrorDisplay.setBackground(new java.awt.Color(255, 0, 0));
        passErrorDisplay.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        passErrorDisplay.setForeground(new java.awt.Color(255, 255, 255));

        userErrorDisplay.setBackground(new java.awt.Color(255, 0, 0));
        userErrorDisplay.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        userErrorDisplay.setForeground(new java.awt.Color(255, 255, 255));

        counter.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        counter.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(passwordLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(nameLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(62, 62, 62)
                                        .addComponent(titleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(98, 98, 98)
                                        .addComponent(enterCalcuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addComponent(userErrorDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(passErrorDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addComponent(counter, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(132, 132, 132))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(titleLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(98, 98, 98)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(userField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nameLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(userErrorDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passwordField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(passwordLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passErrorDisplay, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(enterCalcuButton, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(counter, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 350, 500));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void passwordFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passwordFieldActionPerformed
       
    }//GEN-LAST:event_passwordFieldActionPerformed

    int attempts = 3;
    private void enterCalcuButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_enterCalcuButtonActionPerformed
        calculatorFrame calcFrame = new calculatorFrame();
        String username = "ricky";
        String password = "rjayyy";
        
        if(username.equals(userField.getText())) {
            userErrorDisplay.setText("");
        }
        
        if(password.equals(passwordField.getText())) {
            passErrorDisplay.setText("");
        }
        
        if(!username.equals(userField.getText()) && !password.equals(passwordField.getText())) {
            attempts--;
            userErrorDisplay.setText("incorrect username.");
            passErrorDisplay.setText("incorrect password.");
            
            counter.setText("Attempts left : " + attempts);
                if(attempts == 0) {
                    this.dispose();
                }
        } else if(!username.equals(userField.getText())) {
            attempts--;
            userErrorDisplay.setText("incorrect username.");
            counter.setText("Attempts left  : " + attempts);
                if(attempts == 0) {
                    this.dispose();
                }
        } else if(!password.equals(passwordField.getText())) {
            attempts--;
            passErrorDisplay.setText("incorrect password.");
            
            counter.setText("Attempts left  : " + attempts);
                if(attempts == 0) {
                    this.dispose();
                }
        }
      else {
            this.dispose();
            calcFrame.setLocationRelativeTo(null);
            calcFrame.setVisible(true);
        }
    }//GEN-LAST:event_enterCalcuButtonActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new loginFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel counter;
    private javax.swing.JButton enterCalcuButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JLabel passErrorDisplay;
    private javax.swing.JPasswordField passwordField;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JLabel titleLabel;
    private javax.swing.JLabel userErrorDisplay;
    private javax.swing.JTextField userField;
    // End of variables declaration//GEN-END:variables
}
