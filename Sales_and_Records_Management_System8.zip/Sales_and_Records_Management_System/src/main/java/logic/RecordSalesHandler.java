package logic;
import entity.Sales;
import entity.Records;

import java.util.Arrays;
import javafx.collections.FXCollections;

import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class RecordSalesHandler {
    private String salesProcessHolder;
    private final Label nextRecordIndicator;
    
    private final HBox[] linesSales;
    private final Label[] salesLabel;
    private final Label[] dateLabel;
    private final Long[] accumulatedSales = new Long[7];
    private final ChoiceBox<String> deleteSelection;
    
    private final String[] recordedLines = {"Record #1", "Record #2", "Record #3", "Record #4", "Record #5", "Record #6", "Record #7"};
        
    public RecordSalesHandler(HBox[] linesSales, Label[] salesLabel, Label[] dateLabel, ChoiceBox<String> deleteSelection, Button deleteItem, Label nextRecordIndicator) {
        this.linesSales = linesSales;
        this.salesLabel = salesLabel;
        this.dateLabel = dateLabel;
        this.deleteSelection = deleteSelection;
        this.nextRecordIndicator = nextRecordIndicator;
    }
    
    public void showNextRecord() {
        for(int i = 0; i < recordedLines.length; i++) {
            if(!linesSales[i].isVisible()) {
                String convertedCounter = Integer.toString(i + 1);
                
                nextRecordIndicator.setText("RECORD ID #" + convertedCounter);
                return;
            }   
            nextRecordIndicator.setText("RECORD ID #N/A");
        }
    }
    
    public void getInputSales(String input) {      
        String stringSalesInput = input.trim();
        if(stringSalesInput.isEmpty()) return;
        setSalesProcessHolder(stringSalesInput);        
    }
    
    public void showRecordedLine(String processedInput, String date) {
        for(int i = 0; i < linesSales.length; i++) {
            if(processedInput != null) {
                if(!linesSales[i].isVisible()) {
                    linesSales[i].setVisible(true);
                    linesSales[i].setManaged(true);
                                       
                    accumulatedSales[i] = (Long.valueOf(processedInput));
                    
                    salesLabel[i].setText("PHP" + processedInput);
                    dateLabel[i].setText(date);
                    return;
                }
            }
        }
    }
    
    public void deleteRecordedLine() {
        for(int i = 0; i < linesSales.length; i++) {
            if(linesSales[i].isVisible()) {                
                linesSales[i].setVisible(false);
                linesSales[i].setManaged(false);
                salesLabel[i].setText(null);
                dateLabel[i].setText(null);
                showNextRecord();
            }           
        }
    }
    
    public void showRecordedList() { 
        int count = 0;  
        for(HBox line : linesSales) {
            if(!line.isVisible()) {
                deleteSelection.getItems().add(recordedLines[count]);
                FXCollections.sort(deleteSelection.getItems());
                return;
            }
            count++;         
        }
    }
  
    public void deleteRecord() {
        if(deleteSelection.getValue() == null || "Select Record to Delete...".equals(deleteSelection.getValue())) return;
      
        String selectedValue = deleteSelection.getSelectionModel().getSelectedItem();
  
        for(int i = 0; i < recordedLines.length; i++) {
            if(selectedValue.equals(recordedLines[i])) {
                linesSales[i].setVisible(false);
                linesSales[i].setManaged(false);
                
                accumulatedSales[i] = null;
                showNextRecord();
                break;
            }
        }
        deleteSelection.getItems().remove(selectedValue);
        deleteSelection.setValue("Select Record...");
    }
    
    public void addToRecordedList() {
        int totalSales = 0;
        int totalRecords = 0;
        for(Long accumulated : accumulatedSales) {  
            if(accumulated != null) totalRecords++;
            if(accumulated == null) continue;
            totalSales += accumulated;
        }
        Sales.setSales(totalSales);
        Records.setRecord(totalRecords);
        
        Arrays.fill(accumulatedSales, null);
        deleteSelection.getItems().clear();
        deleteSelection.setValue("Select Record...");
        deleteRecordedLine();
    }
    
    public void setSalesProcessHolder(String processedInput) {
        this.salesProcessHolder = processedInput;
    }
     
    public String getProcessedInput() {
        return salesProcessHolder;
    }
    
    public void resetInput() {
        salesProcessHolder = null;
    }
}