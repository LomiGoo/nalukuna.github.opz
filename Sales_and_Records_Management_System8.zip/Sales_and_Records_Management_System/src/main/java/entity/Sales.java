package entity;

public class Sales {
    private static int sales;

    public static void setSales(int sales) {
        Sales.sales = sales;
    }

    public static int getSales() {
        return sales;
    }
    
}
