


package com.mycompany.mavenproject1;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class requeststatusController implements Initializable {

    @FXML
    private TableView<?> requestTable; // This MUST match the fx:id in your FXML

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // This is the Java way to do what the FXML was failing to do
        if (requestTable != null) {
            requestTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        }
    }
    
    @FXML
    private void handleHome(ActionEvent event){
        try {
            Parent root = FXMLLoader.load(
            getClass().getResource("/com/mycompany/mavenproject1/menu.fxml")
            );
            
            Stage stage = (Stage)((Node) event.getSource())
                    .getScene().getWindow();
            
            stage.setScene(new Scene(root));
        }catch (Exception e){
            e.printStackTrace();
        }
    
        }
}