package com.mycompany.mavenproject1;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 *
 * @author CLienT 
 */
public class menuController {
 @FXML
private BorderPane main;
 
 private void switchScene(String fxmlFileName, javafx.event.ActionEvent event) {
    try {
        // Load the new FXML file
        javafx.fxml.FXMLLoader loader = new javafx.fxml.FXMLLoader(getClass().getResource("/com/mycompany/mavenproject1/" + fxmlFileName));
        javafx.scene.Parent root = loader.load();
        
        // Get the current window (Stage)
        javafx.stage.Stage stage = (javafx.stage.Stage)((javafx.scene.Node)event.getSource()).getScene().getWindow();
        
        // Set the new scene
        stage.setScene(new javafx.scene.Scene(root));
        stage.show();
    } catch (java.io.IOException e) {
        System.out.println("Error loading " + fxmlFileName + ": " + e.getMessage());
        e.printStackTrace();
    }
}

@FXML
private void openrequestform(ActionEvent event) throws IOException {
    Parent root = FXMLLoader.load(
        getClass().getResource("requestform.fxml")
    );

    Stage stage = (Stage) ((Node) event.getSource())
            .getScene().getWindow();

    stage.setScene(new Scene(root));
    stage.show();
}

@FXML
private void openrequeststatus(ActionEvent event) {
    try {
        Parent root = FXMLLoader.load(getClass().getResource("/com/mycompany/mavenproject1/RequestStatus.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.show();
    } catch (Exception e) {
        e.printStackTrace();
    }
}

@FXML
private void handleNotificationsClick(javafx.event.ActionEvent event) {
    switchScene("Notifications.fxml", event);
}

@FXML
private void handleHistoryClick(javafx.event.ActionEvent event) {
    switchScene("history.fxml", event);
}

@FXML
private void handleAccountSettingsClick(javafx.event.ActionEvent event) {
    switchScene("AccountSettings.fxml", event);
}
}
    

