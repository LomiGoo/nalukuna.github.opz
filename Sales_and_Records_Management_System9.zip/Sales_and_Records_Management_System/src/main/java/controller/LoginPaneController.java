package controller;
import database.DataProcessExecutor;
import database.UserDataProcessor;
import database.UserData;
import entity.User;
import util.Transitions;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;


public class LoginPaneController {
   @FXML
    private Circle loginLogo;
    @FXML
    private Label inputNotify, usernameNotifier, passwordNotifier, passwordShowNotifier;
    @FXML
    private TextField userField, passShownField;
    @FXML
    private VBox vboxPassword, vboxShownPass;
    @FXML
    private PasswordField passField;  
    @FXML
    private CheckBox showPasswordCB;
    @FXML
    private Button loginButton;
    @FXML
    private Hyperlink signUpHyperLink;
    
    private final Transitions fadeTrans = new Transitions();
    private User session;
    
    @SuppressWarnings("unused")
    @FXML
    private void initialize() {
        Image imgImage = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        loginLogo.setFill(new ImagePattern(imgImage));
        
        passShownField.textProperty().bindBidirectional(passField.textProperty());
        showPasswordCB.setOnAction(e -> {
            if(showPasswordCB.isSelected()) {
                vboxPassword.setVisible(false);
                vboxPassword.setManaged(false);
                vboxShownPass.setVisible(true);
                vboxShownPass.setManaged(true);
            } else {
                vboxShownPass.setVisible(false);
                vboxShownPass.setManaged(false);
                vboxPassword.setVisible(true);
                vboxPassword.setManaged(true);
            }
        });
        
        UserData userData = new UserDataProcessor();
        DataProcessExecutor readData = new DataProcessExecutor();
        
        
        userNotify("Username Required.");
        userField.textProperty().addListener((obs, oldTxt, newTxt) -> {         
            validateInputUser(newTxt);           
        });
        
        passNotify("Password Required.");
        passField.textProperty().addListener((obs, oldTxt, newTxt) -> {     
            validateInputPass(newTxt);
        });
        
        loginButton.setOnAction(e -> {
            if(!userField.getText().isEmpty() && !passField.getText().isEmpty()){
                boolean inputExists = readData.readData(userData,userField.getText(), passField.getText());
              
                if(inputExists) {
                    System.out.println("INFO EXIST");
                    
                    switchToMainAppPane();
                    return;
                }                     
            }  
            fadeTrans.fade(inputNotify);          
        });
        
        signUpHyperLink.setOnAction(e -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/signup_pane.fxml"));
                Parent root = loader.load();
                signUpHyperLink.getScene().setRoot(root);
                } catch(IOException ex) {
                    System.out.println("Something Went Wrong.");
                }
        });
        
        
    }
    
    private boolean validateInputUser(String username) {       
        String user = username;
        if(!user.isEmpty()) {
            usernameNotifier.setVisible(false);
            return true;
        }       
        userNotify("Username Required.");
        return false;
    }
    
    private boolean validateInputPass(String password) {       
        String pass = password;
        if(!pass.isEmpty()) {
            passwordNotifier.setVisible(false);
            passwordShowNotifier.setVisible(false);
            return true;
        } 
        passNotify("Password Required.");
        return false;
    }
    
  
    
    private void switchToMainAppPane() {
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/main_app_interface.fxml"));
        Parent root = loader.load();
        
        loginButton.getScene().setRoot(root);       
        } catch(IOException e) {
            System.out.println("Something Went Wrong on Switching.");
        }
    }
    
    public void userNotify(String message) {
        usernameNotifier.setVisible(true);
        usernameNotifier.setText(message);
    }
    
    public void passNotify(String message) {
        passwordNotifier.setVisible(true);
        passwordNotifier.setText(message);
        passwordShowNotifier.setVisible(true);
        passwordShowNotifier.setText(message);
    }
  
    public Label getInputNotify() {
        return inputNotify;
    }
}
