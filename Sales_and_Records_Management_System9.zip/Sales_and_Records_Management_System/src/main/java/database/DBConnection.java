package database;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {  
    public static Connection connectTest() throws SQLException, IOException {
        try {                 
            File DB_FILE = new File("database/Sales and Records Management System.db").getCanonicalFile();
            String DB_URL = "jdbc:sqlite:" + DB_FILE.getPath();
            Connection connection = DriverManager.getConnection(DB_URL);        
            System.out.println("Connection Successful.");
            return connection;
        } catch(SQLException e) {
            System.out.println("Connection Failed.");
            return null;
        }    
    }
}
