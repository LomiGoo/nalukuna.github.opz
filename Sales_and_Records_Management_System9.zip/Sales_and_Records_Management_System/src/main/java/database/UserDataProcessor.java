package database;

import entity.User;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDataProcessor extends UserData {
    private final String insertToUsers = ("INSERT INTO Users(Username, Password) VALUES(?, ?)");
    
    @Override
    public void createUsersData(String usernameInput, String passwordInput) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(insertToUsers)) {
            prst.setString(1, usernameInput);
            prst.setString(2, passwordInput);

            prst.executeUpdate();

            System.out.println("Data Inserted!");

        } catch(IOException ioEx) {
            ioEx.printStackTrace();
        } catch(SQLException exc) {
            exc.printStackTrace();
        }
    }   
    
    private final String readUsers = ("SELECT * FROM USERS WHERE Username = ? AND Password = ?");
    
    @Override
    public boolean readUsersData(String user, String pass) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(readUsers)) {       
            prst.setString(1, user);
            prst.setString(2, pass);
            
            ResultSet resultSet = prst.executeQuery();
            
            if(resultSet.next()) {
                System.out.println("user exists");
                int user_ID = resultSet.getInt("User_ID");
                
                User.setCurrentUserID(user_ID);
                return true;
            } else {
                System.out.println("user not found");
                return false;
            }                       
        }  catch(IOException ioEx) {
            ioEx.printStackTrace();
            return false;
        } catch(SQLException exc) {
            exc.printStackTrace();
            return false;
        }
    }
}
