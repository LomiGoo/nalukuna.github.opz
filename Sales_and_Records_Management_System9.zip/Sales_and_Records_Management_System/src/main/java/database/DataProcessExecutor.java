package database;

public class DataProcessExecutor {
    public void createData(UserData ud, String usernameInput, String passwordInput) {   
        ud.createUsersData(usernameInput, passwordInput);
    }  
 
    public boolean readData(UserData ud, String user, String pass) {
        boolean readExist = ud.readUsersData(user, pass);
        return readExist;
    }
     
    public void createData(SalesData sd, int userID, int year, int month, int sales, int totalRecords) {
        sd.createRecSalesData(userID, year, month, sales, totalRecords);
    }
    
    public void readData(SalesData sd, int userID,  int year) {
        sd.readRecSalesData(userID, year);
    }
    
    public void readData(SalesData sd, int userID, int year, int month) {
        sd.readRecSalesData(userID, year, month);
    }
    
    public void updateData(SalesData sd, int userID, int year, int month, int sales, int totalRecords) {
        sd.updateRecSalesData(userID, year, month, sales, totalRecords);
    }
    
    public boolean valueCheck(SalesData sd, int userID, int year, int month) {
        return sd.existsYearMonth(userID, year, month);
    }
    
    public boolean valueCheck(SalesData sd, int userID, int year) {
        return sd.existsYear(userID, year);
    }
    
    public void createData(ExpensesData ed, int userID, int year, int month, int expenses, int totalRecords) {
        ed.createRecExpensesData(userID, year, month, expenses, totalRecords);
    }
    
    public void readData(ExpensesData ed, int userID, int year) {
        ed.readRecExpensesData(userID, year);
    }
    
    public void readData(ExpensesData ed, int userID, int year, int month) {
        ed.readRecExpensesData(userID, year, month);
    }
    
    public void updateData(ExpensesData ed, int userID, int year, int month, int sales, int totalRecords) {
        ed.updateRecExpensesData(userID, year, month, sales, totalRecords);
    }
    
    public boolean valueCheck(ExpensesData ed, int userID, int year, int month) {
        return ed.existsYearMonth(userID, year, month);
    }
    
    public boolean valueCheck(ExpensesData ed, int userID, int year) {
        return ed.existsYear(userID, year);
    }
}
