package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class ItemIDRepo {
    private final ArrayList<String> itemID = new ArrayList<>(
            List.of("ITEM-" + String.format("%03d", 002))
    );

    public ArrayList<String> getItemID() {
        return itemID;
    }
      
}
