package com.goat.project.system.model;

public class Quantity {
    
}
