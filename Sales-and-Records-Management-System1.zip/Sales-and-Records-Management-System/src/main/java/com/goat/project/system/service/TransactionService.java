package com.goat.project.system.service;

import com.goat.project.system.repository.ItemIDRepo;
import com.goat.project.system.repository.ItemRepo;
import com.goat.project.system.repository.PriceRepo;
import com.goat.project.system.repository.QuantityRepo;

public class TransactionService {
    private final QuantityRepo repo1 = new QuantityRepo();
    private final ItemIDRepo repo2 = new ItemIDRepo();
    private final ItemRepo repo3 = new ItemRepo();
    private final PriceRepo repo4 = new PriceRepo();

    public QuantityRepo getRepoQTY() {
        return repo1;
    }

    public ItemIDRepo getRepoItemID() {
        return repo2;
    }

    public ItemRepo getRepoItem() {
        return repo3;
    }

    public PriceRepo getRepoPrice() {
        return repo4;
    }
     
}
