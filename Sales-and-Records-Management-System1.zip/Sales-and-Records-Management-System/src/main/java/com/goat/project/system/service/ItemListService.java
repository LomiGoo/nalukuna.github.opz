package com.goat.project.system.service;
import com.goat.project.system.repository.ItemNameRepo;
import com.goat.project.system.repository.ItemPriceRepo;

public class ItemListService {
    private final ItemNameRepo repo1 = new ItemNameRepo();
    private final ItemPriceRepo repo2 = new ItemPriceRepo();

    public ItemNameRepo getRepoName() {
        return repo1;
    }

    public ItemPriceRepo getRepoPrice() {
        return repo2;
    }
    
}
