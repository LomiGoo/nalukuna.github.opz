package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class QuantityRepo {
    private final ArrayList<String> quantity = new ArrayList<>(
            List.of("x" + 2)
    );

    public ArrayList<String> getQuantityList() {
        return quantity;
    }
       
}
