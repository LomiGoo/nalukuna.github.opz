package com.goat.project.system.controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

public class LoginController {
    
    @FXML
    private AnchorPane loginPane;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
      
    }
    
    public void handleExit() {
        Platform.exit();
    }
}
