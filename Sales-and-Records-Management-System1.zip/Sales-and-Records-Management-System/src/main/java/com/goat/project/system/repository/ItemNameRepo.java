package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class ItemNameRepo {
    private final ArrayList<String> itemName = new ArrayList<>(
            List.of("Sisig", "Sisig", "Sisig", "Sisig", "Sisig", "Sisig", "Sisig", "Sisig", "Sisig", "Sisig")
    );

    public ArrayList<String> getItemName() {
        return itemName;
    }
  
}