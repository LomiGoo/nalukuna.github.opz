package database;

public class DataProcessExecutor {
    public void createData(UserData ud, String usernameInput, String passwordInput) {   
        ud.createUsersData(usernameInput, passwordInput);
    }  
 
    public boolean readData(UserData ud, String user, String pass) {
        boolean readExist = ud.readUsersData(user, pass);
        return readExist;
    }
     
    public void createData(SalesData sd, int year, int month, int sales, int totalRecords) {
        sd.createRecSalesData(year, month, sales, totalRecords);
    }
    
    public void readData(SalesData sd, int year) {
        sd.readRecSalesData(year);
    }
    
    public void readData(SalesData sd, int year, int month) {
        sd.readRecSalesData(year, month);
    }
    
    public void updateData(SalesData sd, int year, int month, int sales, int totalRecords) {
        sd.updateRecSalesData(year, month, sales, totalRecords);
    }
    
    public boolean valueCheck(SalesData sd, int year, int month) {
        return sd.existsYearMonth(year, month);
    }
    
    public boolean valueCheck(SalesData sd, int year) {
        return sd.existsYear(year);
    }
    
    public void createData(ExpensesData ed, int year, int month, int expenses, int totalRecords) {
        ed.createRecExpensesData(year, month, expenses, totalRecords);
    }
    
    public void readData(ExpensesData ed, int year) {
        ed.readRecExpensesData(year);
    }
    
    public void readData(ExpensesData ed, int year, int month) {
        ed.readRecExpensesData(year, month);
    }
    
    public void updateData(ExpensesData ed, int year, int month, int sales, int totalRecords) {
        ed.updateRecExpensesData(year, month, sales, totalRecords);
    }
    
    public boolean valueCheck(ExpensesData ed, int year, int month) {
        return ed.existsYearMonth(year, month);
    }
    
    public boolean valueCheck(ExpensesData ed, int year) {
        return ed.existsYear(year);
    }
}
