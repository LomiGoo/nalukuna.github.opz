package database;

public abstract class UserData {
    abstract void createUsersData(String user, String pass);
    abstract boolean readUsersData(String user, String pass); 
}
