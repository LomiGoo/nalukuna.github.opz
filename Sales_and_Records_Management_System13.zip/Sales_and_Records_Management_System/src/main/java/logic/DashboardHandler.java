package logic;

import database.DataProcessExecutor;
import database.ExpensesDataProcessor;
import database.SalesDataProcessor;
import entity.User;

public class DashboardHandler {
    private int salesYearly, expensesYearly, profitYearly;
    private int salesMonthly, expensesMonthly, profitMonthly;
    private final Integer currentUserID = User.getCurrentUserID();
    
    public void processSummaryYearly(int year) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, currentUserID, year) ||  process.valueCheck(expensesData, currentUserID, year)) {
            process.readData(salesData, currentUserID, year);
            process.readData(expensesData, currentUserID, year);
            System.out.println("year sales is = " + salesData.getSalesSumYearly());
            System.out.println("year expenses is = " + expensesData.getExpensesSumYearly());
            this.salesYearly = salesData.getSalesSumYearly();
            this.expensesYearly = expensesData.getExpensesSumYearly();
            this.profitYearly = this.salesYearly - this.expensesYearly;
        } else {
            System.out.println("row not exists.");
        }
    }
    
    public void processSummaryMonthly(int year, int month) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, currentUserID, year, month) || process.valueCheck(expensesData, currentUserID, year, month)) {
            process.readData(salesData, currentUserID, year, month);
            process.readData(expensesData, currentUserID, year, month);
            System.out.println("month sales is = " + salesData.getSalesSumMonthly());
            System.out.println("month expenses is = " + expensesData.getExpensesSumMonthly());
            this.salesMonthly = salesData.getSalesSumMonthly();
            this.expensesMonthly =  expensesData.getExpensesSumMonthly();           
            this.profitMonthly = this.salesMonthly - this.expensesMonthly;
        } else {
            System.out.println("row not exists.");
        }
    }
   
    public int getSalesYearly() {
        return salesYearly;
    }

    public int getExpensesYearly() {
        return expensesYearly;
    }

    public int getProfitYearly() {
        return profitYearly;
    }

    public int getSalesMonthly() {
        return salesMonthly;
    }

    public int getExpensesMonthly() {
        return expensesMonthly;
    }

    public int getProfitMonthly() {
        return profitMonthly;
    }  
}
