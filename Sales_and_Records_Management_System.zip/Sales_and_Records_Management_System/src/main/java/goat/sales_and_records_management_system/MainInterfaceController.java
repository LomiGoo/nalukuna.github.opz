package goat.sales_and_records_management_system;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class MainInterfaceController {
    @FXML
    private Circle logo;
    @FXML
    private BarChart<String, Number> barChartDB;
    @FXML
    private PieChart pieChartSales, pieChartExpenses;
    
    public void initialize() {
        Image logoImg = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        logo.setFill(new ImagePattern(logoImg));
        
        implementBarChart();
        implementPieSales();
        implementPieExpenses();
    }
    
    private void implementBarChart() {
        CategoryAxis xAxis = (CategoryAxis) barChartDB.getXAxis();
        xAxis.setLabel("February");
        
        XYChart.Series<String, Number> cashflowSeries = new XYChart.Series<>();
        cashflowSeries.setName("2025 Sales");

        cashflowSeries.getData().add(new XYChart.Data<>("Sales", 100));
        cashflowSeries.getData().add(new XYChart.Data<>("Expenses", 150));
       
        
        barChartDB.getData().addAll(cashflowSeries);
    }
    
    private void implementPieSales() {
        ObservableList<PieChart.Data> pieSales = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 500),
            new PieChart.Data("Feb", 100)
        ); 
        pieChartSales.setData(pieSales);
        pieChartSales.setTitle("INCOME");
    }
    
    private void implementPieExpenses() {
        ObservableList<PieChart.Data> pieExpenses = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 50),
            new PieChart.Data("Feb", 10)
        ); 
        pieChartExpenses.setData(pieExpenses);
        pieChartExpenses.setTitle("EXPENSES");
    }
    
}
