package SignUpPane_Validations;

import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;

public class Password_Validation {
    
    private final PasswordField passField;
    private final Label passwordNotifier, passwordShowNotifier;
        
    public Password_Validation(PasswordField passField, Label passwordNotifier, Label passwordShowNotifier) {
        this.passField = passField;
        this.passwordNotifier = passwordNotifier;
        this.passwordShowNotifier = passwordShowNotifier;
    }

    public void dynamicValidation() {
        showNotify("Password Required.");
        passField.textProperty().addListener((obs, oldTxt, newTxt) -> {
            validateInput();
        });
    }
    
    public boolean validateInput() {
        String password = passField.getText();
        int passLength = password.length();

        if (password.isEmpty()) {
            showNotify("Password Required.");
            return false;
        }
        
        boolean minValid = validateMin(passLength);
        boolean maxValid = validateMax(passLength);
     
        return validateFinal(minValid, maxValid);
    }

    private boolean validateMin(int length) {
        if (length < 8) {
            showNotify("Minimum of 8 characters.");
            return false;
        }
        return true;
    }

    private boolean validateMax(int length) {
        if (length > 14) {
            showNotify("Maximum of 14 characters.");
            return false;
        }
        return true;
    }

    private boolean validateFinal(boolean minValid, boolean maxValid) {
        if (minValid && maxValid) {
                passwordNotifier.setVisible(false);
                passwordShowNotifier.setVisible(false);
                System.out.println("password validate final = " + getPasswordInput());
            return true;
        }
        return false;
    }
  
    private void showNotify(String message) {
        passwordNotifier.setVisible(true);
        passwordNotifier.setText(message);
        passwordShowNotifier.setVisible(true);
        passwordShowNotifier.setText(message);
    }
    
    public String getPasswordInput() {
        return passField.getText();
    }
}
