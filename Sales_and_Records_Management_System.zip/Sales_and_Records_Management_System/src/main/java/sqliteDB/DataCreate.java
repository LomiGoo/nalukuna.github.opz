package services.sqliteDB;

import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DataCreate extends UserInputFinalizer {
    private final DBConnection dbConnect = new DBConnection();   
    private final String inserToDB = ("INSERT INTO Users(Username, Password) VALUES(?, ?)");
    
    @Override
    public void createData(String usernameInput, String passwordInput) {
        try {
            PreparedStatement prst = dbConnect.connectTest().prepareStatement(inserToDB);

            prst.setString(1, usernameInput);
            prst.setString(2, passwordInput);

            prst.executeUpdate();

            System.out.println("Data Inserted!");

            dbConnect.connectTest().close(); 
        } catch(SQLException exc) {
             System.out.println("Data not Inserted.");
        }
    }   
}
