package sqliteDB;

public abstract class FinalizerUserInputs {
   void createData(String user, String pass){};
   boolean readData(String user, String pass){return true;};
   
   public void executeCreateData(String usernameInput, String passwordInput) {   
       createData(usernameInput, passwordInput);
       System.out.println("executed\n");
   }
   
   public boolean executeReadData(String user, String pass) {
       boolean readExist = readData(user, pass);
       System.out.println("executed\n");
       return readExist;
   }
}
