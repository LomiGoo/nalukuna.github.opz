package com.goat.project.system.model;

public record Category (long categoryID, String category) {
    public long getCategoryID() {
        return categoryID;
    }
    
    public String getCategory() {
        return category;
    }   
}
