package com.goat.project.system.repository;

import com.goat.project.system.model.ItemList;
import java.math.BigInteger;
import java.util.ArrayList;

public class ItemListRepo {
    private final ArrayList<ItemList> itemList;
    
    public ItemListRepo() {
        itemList = new ArrayList<>();
        
        itemList.add(new ItemList(BigInteger.valueOf(1), "Tapsilog Tapsilog, Tapsilog, Tapsilog, Tapsilog, Tapsilog, Tapsilog, Tapsilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(2), "Chicksilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(3), "Pork silog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(4), "Hungarian silog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(5), "Hot silog", 40.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(6), "Coke", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(7), "Royal", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(8), "Mineral Water", 12.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(9), "Adobong Manok", 95.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(10), "Sinigang na Baboy", 120.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(11), "Beef Pares w/ Rice", 110.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(12), "Kare-Kare Special", 150.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(13), "Crispy Pata Small", 350.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(14), "Lechon Kawali", 130.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(15), "Bicol Express", 100.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(16), "Pritong Tilapia", 85.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(17), "Dinuguan w/ Rice", 90.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(18), "Bangusilog", 95.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(19), "Liemposilog", 105.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(20), "Longsilog", 75.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(21), "Spamsilog", 85.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(22), "Tocilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(23), "Cornsilog", 70.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(24), "Chopsuey Guisado", 90.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(25), "Pinakbet w/ Bagnet", 115.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(26), "Ginataang Kalabasa", 75.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(27), "Tortang Talong", 60.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(28), "Kalderetang Baka", 140.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(29), "Sinigang na Baboy", 120.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(30), "Adobong Manok", 95.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(31), "Beef Pares w/ Rice", 110.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(32), "Kare-Kare Beef", 150.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(33), "Lechon Kawali", 130.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(34), "Bicol Express", 100.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(35), "Pritong Tilapia", 85.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(36), "Dinuguan w/ Rice", 90.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(37), "Bangusilog", 95.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(38), "Liemposilog", 105.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(39), "Longsilog", 75.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(40), "Spamsilog", 85.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(41), "Tocilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(42), "Cornsilog", 70.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(43), "Chopsuey Guisado", 90.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(44), "Pinakbet w/ Bagnet", 115.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(45), "Tortang Talong", 60.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(46), "Kalderetang Baka", 140.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(47), "Menudo Special", 95.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(48), "Ginataang Kalabasa at Sitaw", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(49), "Buko Juice (Plastic)", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(50), "Sago't Gulaman Large", 35.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(51), "Pineapple Juice Can", 45.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(52), "Iced Tea Bottomless", 60.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(53), "Barako Coffee Black", 40.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(54), "Mountain Dew 290ml", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(55), "Sprite 290ml", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(56), "Mango Shake Special", 75.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(57), "Calamansi Juice (Cold)", 35.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(58), "San Miguel Pale Pilsen", 75.00, "Drinks"));
    }

    public ArrayList<ItemList> getItemList() {
        return itemList;
    }
}
