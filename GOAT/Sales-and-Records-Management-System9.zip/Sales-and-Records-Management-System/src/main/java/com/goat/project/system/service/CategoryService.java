package com.goat.project.system.service;
import com.goat.project.system.model.Category;
import com.goat.project.system.repository.CategoryRepo;
import java.util.function.BiConsumer;

public class CategoryService {
    private final CategoryRepo categoryRepo = new CategoryRepo();
    
    public void loadAllCategories(BiConsumer<Long, String> broadcastCategory) {        
        for (Category category : getCategoryRepo().getCategoryList()) {
            broadcastCategory.accept(category.getCategoryCount(), category.getCategory());
        }
    }

    public CategoryRepo getCategoryRepo() {
        return categoryRepo;
    }  
}
