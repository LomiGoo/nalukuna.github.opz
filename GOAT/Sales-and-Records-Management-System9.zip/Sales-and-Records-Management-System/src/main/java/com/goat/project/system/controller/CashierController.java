package com.goat.project.system.controller;

import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.utility.CashierHelper;
import com.goat.project.system.utility.DateTimeUtils;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class CashierController {
    @FXML
    private Label cashierUser;
    @FXML
    private Label cashierDateDisplay;
    @FXML
    private Label cashierTimeDisplay;
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label refCategoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label refItemLabel, refPriceLabel;
    @FXML
    private VBox refItemFrame;
    @FXML
    private FlowPane itemContainer;
    
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label refTransactQuantity, refTransactItemID, refTransactItem, refTransactPrice;
    @FXML
    private HBox transactionLine;
    @FXML
    private VBox transactionList;
    
    @FXML
    private RadioButton noActionRadio, deductItemRadio, removeItemRadio;
   
    @FXML
    private Button clearTransactionButton, completeTransactionButton;
    
    @FXML
    private Label totalPrice;
    
    @FXML
    private StackPane appRoot;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        cashierDateDisplay.setText(DateTimeUtils.getFormattedDate());
        displayClock();
        
        displayCategory();
        transactionList.getChildren().clear();
        itemContainer.getChildren().clear();
        
        clearTransactionButton.setOnAction(e -> {
            transactionList.getChildren().clear();
            totalPrice.setText("TOTAL : ₱0.00");
        });
        
            completeTransactionButton.setOnAction(e -> {
            if(!transactionList.getChildren().isEmpty()) {
                // Use trim() and replaceAll to ensure we only get the actual username
                String nameStr = cashierUser.getText().replace("Cashier:", "").trim();
                String receiptContent = buildReceiptString(nameStr);
                displayReceiptPopup(receiptContent);
            }
        });
    }
    
    private void displayReceiptPopup(String receiptText) {
        if (appRoot == null) return;

        // 1. Backdrop Overlay
        Region overlay = new Region();
        overlay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.75);"); 

        // 2. Main Window - Keep it at 450 for that "Big" feel
        VBox receiptWindow = new VBox(0); 
        receiptWindow.setMinWidth(450); 
        receiptWindow.setMaxWidth(450);
        receiptWindow.setMaxHeight(Region.USE_PREF_SIZE); 
        receiptWindow.setStyle("-fx-background-color: white; " +
                               "-fx-background-radius: 15; " +
                               "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.5), 20, 0, 0, 0);");

        // HEADER
        HBox windowHeader = new HBox();
        windowHeader.setPadding(new javafx.geometry.Insets(18, 20, 18, 20));
        windowHeader.setStyle("-fx-background-color: #007bff; -fx-background-radius: 15 15 0 0;");
        Label headerTitle = new Label("TRANSACTION RECEIPT");
        headerTitle.setStyle("-fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 18px;");
        windowHeader.getChildren().add(headerTitle);
        windowHeader.setAlignment(javafx.geometry.Pos.CENTER);

        // BODY
        VBox body = new VBox(25); 
        body.setPadding(new javafx.geometry.Insets(25, 20, 25, 20));
        body.setAlignment(javafx.geometry.Pos.CENTER);

        // TEXT AREA
        TextArea area = new TextArea(receiptText);
        // Setting to 18px ensures 32 characters fit perfectly in 450px width
        area.setFont(javafx.scene.text.Font.font("Courier New", 18)); 
        area.setEditable(false);
        area.setPrefHeight(500); 

        // CRITICAL FIX: Disable wrapping so columns stay aligned
        area.setWrapText(false); 

        // CSS FIX: Force horizontal scrollbar to disappear and remove internal borders
        area.setStyle("-fx-control-inner-background: white; " +
                      "-fx-background-color: white; " +
                      "-fx-background-insets: 0; " +
                      "-fx-padding: 10; " + 
                      "-fx-text-fill: #222222; " + 
                      "-fx-focus-color: transparent; " +
                      "-fx-hbar-policy: never; " + // No horizontal scroll
                      "-fx-vbar-policy: as-needed;"); // Vertical scroll only if long

        // BUTTONS
        HBox buttonContainer = new HBox(15); 
        buttonContainer.setAlignment(javafx.geometry.Pos.CENTER);
        String btnBase = "-fx-text-fill: white; -fx-font-weight: bold; -fx-cursor: hand; -fx-background-radius: 8; -fx-font-size: 14px;";

        Button printBtn = new Button("PRINT");
        printBtn.setStyle("-fx-background-color: #28a745; " + btnBase);
        printBtn.setPadding(new javafx.geometry.Insets(10, 20, 10, 20));
        printBtn.setOnAction(e -> printReceipt(area.getText()));

        Button submitBtn = new Button("SUBMIT");
        submitBtn.setStyle("-fx-background-color: #007bff; " + btnBase);
        submitBtn.setPadding(new javafx.geometry.Insets(10, 20, 10, 20));
        submitBtn.setOnAction(e -> {
            transactionList.getChildren().clear();
            totalPrice.setText("TOTAL : ₱0.00");
            appRoot.getChildren().removeAll(overlay, receiptWindow);
        });

        Button closeBtn = new Button("CLOSE");
        closeBtn.setStyle("-fx-background-color: #6c757d; " + btnBase);
        closeBtn.setPadding(new javafx.geometry.Insets(10, 20, 10, 20));
        closeBtn.setOnAction(e -> appRoot.getChildren().removeAll(overlay, receiptWindow));

        buttonContainer.getChildren().addAll(printBtn, submitBtn, closeBtn);
        body.getChildren().addAll(area, buttonContainer);
        receiptWindow.getChildren().addAll(windowHeader, body);

        StackPane.setAlignment(receiptWindow, javafx.geometry.Pos.CENTER);
        appRoot.getChildren().addAll(overlay, receiptWindow);

        Platform.runLater(() -> area.setScrollTop(0));
    }

    private String buildReceiptString(String cashierName) {
        StringBuilder sb = new StringBuilder();
        double subtotal = 0.0;

        String line = "--------------------------------\n"; 
        String doubleLine = "================================\n"; 

        sb.append(doubleLine);
        sb.append(String.format("%12s%s\n", "", "DIOSARAP"));
        sb.append(doubleLine);

        // FIX: Wrap the Cashier Name so it doesn't overflow or use "..."
        // We use a limit of 32 (the full width of the receipt)
        List<String> wrappedCashierName = wrapText(cashierName, 32);
        for (String nameLine : wrappedCashierName) {
            sb.append(nameLine).append("\n");
        }

        sb.append("Date: ").append(DateTimeUtils.getFormattedDate()).append("\n");
        sb.append("Time: ").append(DateTimeUtils.getCurrentTime()).append("\n");
        sb.append(line);

        // QTY(4) + space(1) + ITEM(18) + space(1) + PRICE(8) = 32 chars
        sb.append(String.format("%-4s %-18s %8s\n", "QTY", "ITEM", "PRICE"));
        sb.append(line);

        for (Node node : transactionList.getChildren()) {
            if (!(node instanceof HBox)) continue;
            HBox row = (HBox) node;

            String qty = CashierHelper.getQtyLabel(row).getText();
            String itemName = CashierHelper.getItemLabel(row).getText();
            String priceText = CashierHelper.getPriceLabel(row).getText();
            double priceValue = CashierHelper.parsePriceString(priceText);
            subtotal += priceValue;

            List<String> wrappedName = wrapText(itemName, 18);
            sb.append(String.format("%-4s %-18s %8.2f\n", qty, wrappedName.get(0), priceValue));

            for (int i = 1; i < wrappedName.size(); i++) {
                sb.append(String.format("%-4s %-18s %8s\n", "", wrappedName.get(i), ""));
            }
        }

        sb.append(line);
        sb.append(String.format("%-23s %8.2f\n", "SUBTOTAL:", subtotal));
        sb.append(String.format("%-23s %8.2f\n", "TOTAL:", subtotal)); 
        sb.append(doubleLine);
        sb.append(String.format("%5s%s\n", "", "Salamat sa Pagbisita!"));

        return sb.toString();
    }

    private List<String> wrapText(String text, int limit) {
        List<String> lines = new ArrayList<>();
        // Remove all commas and extra spaces from the item name for a clean receipt
        String cleanText = text.replace(",", "").trim(); 
        String[] words = cleanText.split(" ");
        StringBuilder currentLine = new StringBuilder();

        for (String word : words) {
            if (currentLine.length() + word.length() + 1 <= limit) {
                if (currentLine.length() > 0) currentLine.append(" ");
                currentLine.append(word);
            } else {
                lines.add(currentLine.toString());
                currentLine = new StringBuilder(word);
            }
        }
        if (currentLine.length() > 0) lines.add(currentLine.toString());
        return lines;
    }
    
    private void printReceipt(String receiptText) {
        javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();

        if (job != null && job.showPrintDialog(appRoot.getScene().getWindow())) {

// 1. Calculate height based on your 36 items (approx 13 points per line)
                        // 2. Force the PageLayout to be narrow (80mm width = ~227 points)
            // We use A4 as a base but override the printable area
            javafx.print.PageLayout pageLayout = job.getPrinter().createPageLayout(
                javafx.print.Paper.A4, 
                javafx.print.PageOrientation.PORTRAIT, 
                0, 0, 0, 0 // SET ALL MARGINS TO ZERO
            );

            javafx.scene.text.Text printableText = new javafx.scene.text.Text(receiptText);

            // 3. MUST use Courier New to keep your columns (QTY, ITEM, PRICE) aligned 
            printableText.setFont(javafx.scene.text.Font.font("Courier New", 9));

            // 4. Set wrapping width to fit inside the 80mm roll
            printableText.setWrappingWidth(210); 

            if (job.printPage(pageLayout, printableText)) {
                job.endJob();
            }
        }
    }





    
    
    
    
    
    public void createCategory(Long categoryCount, String category) {         
        Label newCategory = new Label(categoryCount + ". " + category);
        newCategory.setOnMouseClicked(e -> chooseCategory(category));       
        CashierHelper.setCategoryLabelsCss(newCategory, refCategoryChoice);

        categoryContainer.getChildren().add(newCategory);        
    }
    
    @FXML
    private void displayCategory() {
        CategoryService categoryService = new CategoryService();
        categoryContainer.getChildren().clear();

        categoryService.loadAllCategories((categoryCount, category) -> {          
            createCategory(categoryCount, category);
        });
    }
    
    @FXML
    private void chooseCategory(String chosenCategory) {      
        displayItemLists(chosenCategory);
    }
    
    @FXML
    private void displayItemLists(String chosenCategory) {
        ItemListService itemListService = new ItemListService();

        itemContainer.getChildren().clear();
        
        itemListService.loadAllItemLists(items -> {
           createItemList(items.getItemID(), items.getItemName(), items.getItemPrice());
        }, chosenCategory);
    }
    
    @FXML
    private void createItemList(BigInteger itemID, String newItem, Double newPrice) {            
        VBox newItemContainer = new VBox();       
        newItemContainer.setOnMouseClicked(e -> chooseItemList(itemID, newItem, newPrice, false));
        CashierHelper.setContainerCss(newItemContainer, refItemFrame);
        
        Label itemNameLabel = new Label(newItem);
        Label itemPriceLabel = new Label(String.format("₱%.2f", newPrice));      
        CashierHelper.setItemLabelsCss(itemNameLabel, itemPriceLabel, refItemLabel, refPriceLabel);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(itemNameLabel, itemPriceLabel);     
    }
        
    @FXML
    private void chooseItemList(BigInteger itemID, String chosenItem, Double itemPrice, boolean isInTransaction) {   
        HBox recordLineExistence = recordLineCheck(chosenItem);
        if(recordLineExistence == null) {
            addItemToTransaction(itemID, chosenItem, itemPrice);
            updateGrandTotal();
            return;
        }
        
        Label qtyLabel = CashierHelper.getQtyLabel(recordLineExistence);
        Label priceLabel = (Label) CashierHelper.getPriceLabel(recordLineExistence);
        
        if(!noActionRadio.isSelected() && isInTransaction) {
            removeItem(recordLineExistence);
            deductItem(recordLineExistence, itemPrice, qtyLabel, priceLabel);
            updateGrandTotal();
            return;
        }
        
        int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
        qtyLabel.setText(String.valueOf(newQty));
        priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
        updateGrandTotal();
    }
    
    @FXML
    private HBox recordLineCheck(String chosenItem) {
        for(Node node : transactionList.getChildren()) {
            HBox row = (HBox) node;
            if(row.getChildren().size() != 4) continue;
            
            Label nameLabel = CashierHelper.getItemLabel(row);
            if(!nameLabel.getText().equals(chosenItem)) continue;  
            
            return row;
        }
        return null;
    }
    
    @FXML
    private void removeItem(HBox existing) {
        if(removeItemRadio.isSelected()) transactionList.getChildren().remove(existing);      
        updateGrandTotal();
    }

    @FXML
    private void deductItem(HBox existing, Double itemPrice, Label qtyLabel, Label priceLabel) {
        if(existing == null) return; 
        
        if(deductItemRadio.isSelected()) {         
            int currentQty = Integer.parseInt(qtyLabel.getText());
            
            if(currentQty <= 1) {
                transactionList.getChildren().remove(existing);
                return;
            }
            
            int deductedQty = currentQty - 1;
            qtyLabel.setText(String.valueOf(deductedQty));            
            priceLabel.setText(String.format("₱%.2f", deductedQty * itemPrice));                            
        }
    }
  
    @FXML
    private void updateGrandTotal() {
    double grandTotal = 0.0;
    for(Node node : transactionList.getChildren()) {
        HBox row = (HBox) node;
        
        Label priceLabel = CashierHelper.getPriceLabel(row);
        String priceText = priceLabel.getText();
        double convertedPrice = CashierHelper.parsePriceString(priceText);
        
        grandTotal += convertedPrice;
     }
    totalPrice.setText("TOTAL : " + String.format("₱%.2f", grandTotal));
}
    
    @FXML
    private void addItemToTransaction(BigInteger itemID, String chosenItem, Double itemPrice) {   
        HBox newRow = new HBox();         
        newRow.setOnMouseClicked(e -> {
            chooseItemList(itemID, chosenItem, itemPrice, true);
        });
        
        Label quantityLabel = new Label("1");
        String formattedItemID = String.format("ITEM-%03d", itemID);
        Label itemIDLabel = new Label(formattedItemID);            
        Label itemLabel = new Label(chosenItem);            
        Label priceLabel = new Label(String.format("₱%.2f", itemPrice));
        
        CashierHelper.setTransactionLabelsCss(quantityLabel, itemIDLabel, itemLabel, priceLabel, 
                                                    refTransactQuantity, refTransactItemID, refTransactItem, refTransactPrice);      
        newRow.setPrefSize(transactionLine.getPrefWidth(), transactionLine.getPrefHeight());
        newRow.setMinHeight(transactionLine.getMinHeight());
        
        newRow.getChildren().addAll(quantityLabel, itemIDLabel, itemLabel, priceLabel);
        transactionList.getChildren().add(newRow);
    }
    
    @FXML 
    public void displayName(String username) {
        cashierUser.setText("Cashier: " + username);
    }
    
    public void displayClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            String CURRENT_TIME = DateTimeUtils.getCurrentTime();
             cashierTimeDisplay.setText(CURRENT_TIME); 
        }),
        new KeyFrame(Duration.seconds(1))
    );    
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void handleExit() {
        Platform.exit();
    }
}