package com.goat.project.system.service;

import com.goat.project.system.model.ItemList;
import com.goat.project.system.repository.ItemListRepo;
import java.util.function.Consumer;

public class ItemListService {
    private final ItemListRepo itemListRepo = new ItemListRepo();

    public void loadAllItemLists(Consumer<ItemList> broadcastItems, String chosenCategory) {        
        for (ItemList itemList : getItemListRepo().getItemList()) {
            if(itemList.getCategory().equalsIgnoreCase(chosenCategory)) {
                broadcastItems.accept(new ItemList(itemList.getItemID(), itemList.getItemName(), itemList.getItemPrice(), itemList.getCategory()));
            }
        }
    }
    
    public ItemListRepo getItemListRepo() {
        return itemListRepo;
    }
}
