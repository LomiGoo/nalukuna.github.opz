package com.goat.project.system.utility;

import com.goat.project.system.model.FinancialSummary;
import com.goat.project.system.service.FinancialSummaryService;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.text.Font;

public class Charts {
    private BarChart<String, Number> yearlyBar, monthlyBar;
    private Label yearLabel, monthLabel, yearProfit, yearSales, yearExpenses, monthProfit, monthSales, monthExpenses;
    private final String months[] = {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    };
    
    public Charts(String barType, BarChart<String, Number> bar, Label date, Label profit, Label sales, Label expenses) {
        if(barType.equalsIgnoreCase("year")) {
            this.yearlyBar = bar;
            this.yearLabel = date;
            this.yearProfit = profit;
            this.yearSales = sales;
            this.yearExpenses = expenses;
        } else {
            this.monthlyBar = bar;
            this.monthLabel = date;
            this.monthProfit = profit;
            this.monthSales = sales;
            this.monthExpenses = expenses;
        }
    }

    public void implementYearSum(int year) {      
        FinancialSummary summary = FinancialSummaryService.getYearSummary(year);
        double sales = summary.getSales();
        double expenses = summary.getExpenses();
        double profit = summary.getProfit();
        yearlyBar.getData().clear();

        XYChart.Data<String, Number> salesData = new XYChart.Data<>("Sales", sales);
        XYChart.Data<String, Number> expensesData = new XYChart.Data<>("Expenses", expenses);
        XYChart.Data<String, Number> profitData = new XYChart.Data<>("Profit", profit);
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.getData().addAll(salesData, expensesData, profitData);
        
        CategoryAxis xAxis = (CategoryAxis) yearlyBar.getXAxis();
        NumberAxis yAxis = (NumberAxis) yearlyBar.getYAxis();

        xAxis.setTickLabelFont(Font.font("Arial", 18));
        yAxis.setTickLabelFont(Font.font("Arial", 18));
        
        yearlyBar.getData().add(series1);

        salesData.getNode().setStyle("-fx-bar-fill: #2ecc71;");   
        expensesData.getNode().setStyle("-fx-bar-fill: #e74c3c;");
        profitData.getNode().setStyle("-fx-bar-fill: #3498db;");  
        
        yearLabel.setText(Integer.toString(year));
        yearProfit.setText("PHP " + String.format("%.2f", profit));
        yearSales.setText("PHP " + String.format("%.2f", sales));
        yearExpenses.setText("PHP " + String.format("%.2f", expenses));
    }
    
    public void implementMonthSum(int year, String month) { 
        FinancialSummary summary = FinancialSummaryService.getMonthSummary(year, month);       
        double sales = summary.getSales();
        double expenses = summary.getExpenses();
        double profit = summary.getProfit();
        monthlyBar.getData().clear();
        
        XYChart.Data<String, Number> salesData = new XYChart.Data<>("Sales", sales);
        XYChart.Data<String, Number> expensesData = new XYChart.Data<>("Expenses", expenses);
        XYChart.Data<String, Number> profitData = new XYChart.Data<>("Profit", profit);

        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.getData().addAll(salesData, expensesData, profitData);

        CategoryAxis xAxis = (CategoryAxis) monthlyBar.getXAxis();
        NumberAxis yAxis = (NumberAxis) monthlyBar.getYAxis();

        xAxis.setTickLabelFont(Font.font("Arial", 18));
        yAxis.setTickLabelFont(Font.font("Arial", 18));

        monthlyBar.getData().add(series1);

        salesData.getNode().setStyle("-fx-bar-fill: #2ecc71;");   
        expensesData.getNode().setStyle("-fx-bar-fill: #e74c3c;");
        profitData.getNode().setStyle("-fx-bar-fill: #3498db;");  

        monthLabel.setText(month);
        monthProfit.setText("PHP " + String.format("%.2f", profit));
        monthSales.setText("PHP " + String.format("%.2f", sales));
        monthExpenses.setText("PHP " + String.format("%.2f", expenses));    
    }
}
