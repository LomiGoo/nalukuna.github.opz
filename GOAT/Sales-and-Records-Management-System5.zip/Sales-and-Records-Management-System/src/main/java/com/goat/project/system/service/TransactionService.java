package com.goat.project.system.service;

import com.goat.project.system.repository.TransactionRepo;

public class TransactionService {
    private TransactionRepo transactionRepo;
    
    public TransactionRepo setTransaction(Integer quantity, long itemID, String item, Double price) {
        transactionRepo = new TransactionRepo(quantity, itemID, item, price);
        return transactionRepo;
        
        
    }

    public TransactionRepo getTransactionRepo() {
        return transactionRepo;
    }
}
