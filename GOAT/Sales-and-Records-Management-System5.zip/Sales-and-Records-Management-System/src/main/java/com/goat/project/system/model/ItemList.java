package com.goat.project.system.model;

import java.math.BigInteger;

public class ItemList {
    private final BigInteger itemIndex;
    private final String itemName;
    private final Double itemPrice;
    private final String category;
    
    public ItemList(BigInteger itemIndex, String itemName, Double itemPrice, String category) {
        this.itemIndex = itemIndex;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.category = category;
    }

    public BigInteger getItemIndex() {
        return itemIndex;
    }
    
    public String getItemName() {
        return itemName;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public String getCategory() {
        return category;
    }  
}
