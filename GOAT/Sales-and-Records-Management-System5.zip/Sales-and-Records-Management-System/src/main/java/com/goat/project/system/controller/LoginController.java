package com.goat.project.system.controller;

import com.goat.project.system.service.UserService;
import com.goat.project.system.utility.loginHelper;
import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

public class LoginController {
   
    @FXML
    private TextField usernameField, shownPasswordField;
    @FXML
    private PasswordField passwordField;

    @FXML
    private CheckBox showPassword;
    
    @FXML
    private ToggleGroup roleGroup;
    
    @FXML
    private Label notificationError, notificationAttempts;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
        passwordField.textProperty().bindBidirectional(shownPasswordField.textProperty());
        showPassword.setOnAction(e -> {
            if(showPassword.isSelected()) {    
                shownPasswordField.setText(passwordField.getText());
                shownPasswordField.setVisible(true);
                passwordField.setVisible(false);
            } else {
                passwordField.setText(shownPasswordField.getText());
                passwordField.setVisible(true);
                shownPasswordField.setVisible(false);
            }
        });
        
    }
    
    
    @SuppressWarnings("unused")
    @FXML
    private void checkCredentials(ActionEvent loginButtonActionEvent) throws IOException {      
        UserService authValidate = new UserService();
        loginHelper loginHelper = new loginHelper();
        
        Toggle selectedToggle = roleGroup.getSelectedToggle();
        
        if(selectedToggle == null) return;
        
        String username = usernameField.getText();
        String password = passwordField.getText();
        loginHelper.isInputEmpty(username, password);
        
        RadioButton radioSelected = (RadioButton) roleGroup.getSelectedToggle();
        String selectedRole = radioSelected.getText();
        
        if(!authValidate.AuthenticateLogIn(username, password, selectedRole, loginButtonActionEvent)) {
            loginHelper.displayErrorNotification(notificationError, notificationAttempts);
            return;
        }
        loginHelper.switchInterface(selectedRole, loginButtonActionEvent);
    }
    
    public void handleExit() {
        Platform.exit();
    }
}
