package com.goat.project.system.repository;
import com.goat.project.system.model.User;

import java.util.ArrayList;

public class UserRepo {
    
    private final ArrayList<User> user;
    
    public UserRepo() {
        user = new ArrayList<>();
        
        user.add(new User("Cashier", "Cashier123", "Cashier"));
        user.add(new User("Admin", "Admin123", "Admin"));
    }

    public ArrayList<User> getUserList() {
        return user;
    }
  
}
