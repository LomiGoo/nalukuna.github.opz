package com.goat.project.system.controller;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.model.Transaction;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.TransactionService;
import com.goat.project.system.utility.CashierControllerHelper;
import java.math.BigInteger;
import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierController {
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label categoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label item, price;
    @FXML
    private VBox itemFrame;
    @FXML
    private FlowPane itemContainer;
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label transactQuantity, transactItemID, transactItem, transactPrice;
    @FXML
    private HBox transactionLine;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        loadAllCategories();
        transactionLine.getChildren().clear();
        itemContainer.getChildren().clear();
    }
    
    @FXML
    private void createCategory(Long categoryCount, String category) {         
        Label newCategory = new Label(categoryCount + ". " + category);

        newCategory.setOnMouseClicked(e -> {
            chooseCategory(category);
        });
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();      
        cashierControllerHelper.applyCategoryCssProperty(newCategory, categoryChoice);

        categoryContainer.getChildren().add(newCategory);
    }
    
    @FXML
    private void loadAllCategories() {
        CategoryService categoryService = new CategoryService();
        categoryContainer.getChildren().clear();
        
        for (Category category : categoryService.getCategoryRepo().getCategoryList()) {
            createCategory(category.getCategoryCount(), category.getCategory());   
        }
    }
    
    @FXML
    private void chooseCategory(String chosenCategory) {      
        loadItemList(chosenCategory);
    }
    
    int marginStop = 0;
    @FXML
    private void createItemList(String newItem, Double newPrice) {            
        VBox newItemContainer = new VBox();
        
        newItemContainer.setOnMouseClicked(e -> {
            chooseItemList(newItem, newPrice);
        });
        
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
   
        if(marginStop == 1) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 0));
        if(marginStop == 0) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 10));
        marginStop++;
        if(marginStop == 6) marginStop = 0;
        
        Label newItemName = new Label(newItem);
        Label newItemPrice = new Label("₱" + newPrice);
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();
        cashierControllerHelper.applyItemListCssProperty(newItemName, newItemPrice, item, price);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(newItemName, newItemPrice);     
    }
    
    @FXML
    private void loadItemList(String chosenCategory) {
    ItemListService itemListService = new ItemListService();
    
    itemContainer.getChildren().clear();
    marginStop = 0;

        for (ItemList items : itemListService.getItemListRepo().getItemList()) {    
            if(items.getCategory().equalsIgnoreCase(chosenCategory)) {
                createItemList(items.getItemName(), items.getItemPrice());  
            }
        }
    }
    private static ArrayList<Integer> activeRecordLine = new ArrayList<>();
    private long idCounter = 001;
    priv
    @FXML
    private void chooseItemList(String chosenItem, Double itemPrice) {
        boolean existing = false;
        
        if()
        
        if (existing != null) {
            Label qtyLabel = (Label) existing.getChildren().get(0);
            int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
            qtyLabel.setText(String.valueOf(newQty));

            Label priceLabel = (Label) existing.getChildren().get(3);
            priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
        } else {
            String customID = String.format("ITEM-%03d", idCounter++);
            addItemToTransaction(customID, chosenItem, itemPrice);
        }
    }
    
    @FXML
    private void addItemToTransaction(String itemID, String chosenItem, Double itemPrice) {   
        HBox newRow = new HBox(); 
                
        Label newQuantityLabel = new Label("1");
        Label newItemIDLabel = new Label(itemID);            
        Label newItemLabel = new Label(chosenItem);            
        Label newPriceLabel = new Label(String.format("₱%.2f", itemPrice));
        
        CashierControllerHelper helper = new CashierControllerHelper();
        helper.applyTransactionCssProperty(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel, 
                                           transactQuantity, transactItemID, transactItem, transactPrice);
        
        newRow.getChildren().addAll(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel);

        transactionLine.getChildren().add(newRow);
    }
       
}

/*
 HBox newRow = new HBox(); 

        Transaction transaction = new Transaction(quantity, newItemID, newItem, newPrice);

        Label newQuantityLabel = new Label(String.valueOf(transaction.getQuantity()));
        Label newItemIDLabel = new Label(String.valueOf(transaction.getItemID()));
        
        Label newPriceLabel = new Label(String.format("₱%.2f", transaction.getPrice()));

        CashierControllerHelper helper = new CashierControllerHelper();
        helper.applyTransactionCssProperty(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel, 
                                           transactQuantity, transactItemID, transactItem, transactPrice);

        newRow.getChildren().addAll(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel);

        transactionLine.getChildren().add(newRow);

        TransactionService transactionService = new TransactionService();
        transactionService.setTransaction(quantity, newItemID, newItem, newPrice);
*/