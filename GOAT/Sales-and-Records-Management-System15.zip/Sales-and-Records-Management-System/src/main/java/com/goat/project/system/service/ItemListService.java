package com.goat.project.system.service;

import com.goat.project.system.model.ItemList;
import com.goat.project.system.repository.ItemListRepo;

public class ItemListService {
    public static boolean findItem(int itemID)  {
        return ItemListRepo.getItemByID(itemID) != null;
    }
    
    public static int getItemID() {
        return ItemList.getItemID();
    }
    
    public static int getItemCategoryID() {
        return ItemList.getCategoryID();
    }
}
