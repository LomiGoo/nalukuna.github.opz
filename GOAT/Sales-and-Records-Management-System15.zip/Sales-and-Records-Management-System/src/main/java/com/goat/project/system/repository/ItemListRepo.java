package com.goat.project.system.repository;

import com.goat.project.system.model.ItemList;
import com.goat.project.system.model.User;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ItemListRepo {
   public static void addItem() {
        String sql = "INSERT INTO users(username, password, role) "
                   + "VALUES(?, ?, ?)";
        
        try(Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, User.getUsername());
            pstmt. setString(2, User.getPassword());
            pstmt. setString(3, User.getRole());
            
            pstmt.executeUpdate();
            System.out.println("User added!");
            
        }catch (SQLException e) {
            System.err.println("Error adding User: " + e.getMessage());
        }
    }
        
    public static ItemList getItemByID(int itemID) {
        String sql = "SELECT * FROM item_list "
                   + "WHERE item_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement statement = conn. prepareStatement(sql)) {
            
            statement.setInt(1, itemID);
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                return new ItemList(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getDouble("price")
                );
            }
            
        } catch(SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;
    }
}
