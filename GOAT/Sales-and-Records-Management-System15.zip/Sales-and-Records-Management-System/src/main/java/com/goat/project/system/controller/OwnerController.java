package com.goat.project.system.controller;

import com.goat.project.system.model.Receipt;
import com.goat.project.system.service.ReceiptService;
import com.goat.project.system.utility.CashierHelper;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class OwnerController {
    @FXML
    private Circle diosarapLogo;
    
    @FXML
    private Label upperLabelTitle;
    
    @FXML
    private AnchorPane dashboardDisplay;
    @FXML
    private AnchorPane recentRecordsDisplay;
    
    @FXML
    private TextArea recentRecordsBody;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
        Image img = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
        ImagePattern pattern = new ImagePattern(img);
        diosarapLogo.setFill(pattern);        
    }
    
    private String buildRecords(String receiptID, String userID, String username, String sales, String time, String date) {
    String userIdentifier = username + "#" + userID;

        String cleanSales = sales.replace("PHP", "").trim();
        double salesValue = Double.parseDouble(cleanSales);

        return String.format("%13s %19s                PHP %,-10.2f %22s %25s\n", 
                receiptID, 
                userIdentifier, 
                salesValue, 
                time, 
                date);
    }

    @FXML
    private void dashboard() {
        recentRecordsDisplay.setVisible(false);
        dashboardDisplay.setVisible(true);
        
        upperLabelTitle.setText("DASHBOARD");
    }
    
    @FXML
    private void recentRecords() {
        dashboardDisplay.setVisible(false);
        recentRecordsDisplay.setVisible(true);
        upperLabelTitle.setText("RECENT RECORDS");
        
        StringBuilder allRecords = new StringBuilder();
        ReceiptService receipt = new ReceiptService();

        for(Receipt r : receipt.getReceipt()) {
            String receiptID = CashierHelper.formattedReceiptID(r.getReceiptID());     
            String userID = CashierHelper.formattedUser(r.getUserID());
            String username = r.getUsername();
            String sales = String.format("%s %.2f", "PHP ", (r.getSales()));
            String time = r.getTime();
            String date = r.getDate();

            allRecords.append(buildRecords(
                receiptID, userID, username,
                sales, time, date
            )); 

        allRecords.append("\n");
        }
    
        recentRecordsBody.setStyle(
              "-fx-text-fill: black; " 
            + "-fx-font-size: 25; "  
            + "-fx-font-family: 'Consolas';"
        );
        recentRecordsBody.setText(allRecords.toString());
        deleteNewLine();
        recentRecordsBody.positionCaret(0);
    }

    @FXML
    private void deleteNewLine() {
        String currentText = recentRecordsBody.getText();

        if (currentText.endsWith("\n")) {
            String backUp = currentText.substring(0, currentText.length() - 1);
            recentRecordsBody.setText(backUp);

            recentRecordsBody.positionCaret(backUp.length());
        }
    }
    
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/goat/project/system/view/loginPane.fxml"));     
            Parent root = loader.load();
            
            Stage newStage = new Stage();

            Scene scene = new Scene(root);
            newStage.setScene(scene);
            
            Image iconImage = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
            newStage.getIcons().add(iconImage);
            newStage.setTitle("Sales and Records Management System");

            scene.getStylesheets().add(getClass().getResource("/com/goat/project/system/css/loginPane.css").toExternalForm());

            newStage.setResizable(true);
            newStage.setMaximized(false);

            newStage.initStyle(StageStyle.TRANSPARENT);
            scene.setFill(Color.TRANSPARENT);

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            System.err.println("Error loading login screen: " + e.getMessage());
        }
    }
}