package com.goat.project.system.controller;

import com.goat.project.system.service.UserService;
import com.goat.project.system.utility.LoginHelper;
import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class LoginController {
    @FXML
    private Circle diosarapLogo;
    
    @FXML
    private TextField usernameField, shownPasswordField, userIDField;
    @FXML
    private PasswordField passwordField;

    @FXML
    private CheckBox showPassword;
    
    @FXML
    private Label notificationError, notificationAttempts;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
        Image img = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
        ImagePattern pattern = new ImagePattern(img);
        diosarapLogo.setFill(pattern);
        
        userIDField.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.matches("\\d*")) {
                userIDField.setText(newValue.replaceAll("[^\\d]", ""));
            }
        });
        passwordField.textProperty().bindBidirectional(shownPasswordField.textProperty());
        showPassword.setOnAction(e -> {
            if(showPassword.isSelected()) {    
                shownPasswordField.setText(passwordField.getText());
                shownPasswordField.setVisible(true);
                passwordField.setVisible(false);
            }else {
                passwordField.setText(shownPasswordField.getText());
                passwordField.setVisible(true);
                shownPasswordField.setVisible(false);
            }
        });
        
    }
    
    
    @SuppressWarnings("unused")
    @FXML
    private void checkCredentials(ActionEvent loginButtonActionEvent) throws IOException {       
        LoginHelper loginHelper = new LoginHelper();
        
        String username = usernameField.getText();
        String password = passwordField.getText();
        String userID = userIDField.getText();
        
        if(LoginHelper.isInputEmpty(username, password, userID)) return;
        
        if(!UserService.findUser(Integer.parseInt(userID))) {
            loginHelper.displayErrorNotification(notificationError, notificationAttempts);
            return;
        }
        
        loginHelper.switchInterface(username, loginButtonActionEvent);
    }
    
    public void handleExit() {
        Platform.exit();
    }
}
