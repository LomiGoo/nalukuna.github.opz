package com.goat.project.system.utility;

import com.goat.project.system.controller.CashierController;
import com.goat.project.system.service.UserService;
import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class LoginHelper {
    public static boolean isInputEmpty(String username, String password, String userID) {
        return username.trim().isBlank()|| 
               password.trim().isBlank()||
               userID.trim().isBlank();
    }
    
    static int attempts = 3;
    public void displayErrorNotification(Label notificationError, Label notificationAttempts) {     
        notificationError.setVisible(true);
        notificationError.setText("Note : User Not Found, Please Try Again");
        notificationAttempts.setVisible(true);
        notificationAttempts.setText("Attempts Left : " + --attempts); 

        if(attempts == 0) {
            Platform.exit();
        }
    }
    
    public void createInterface(int userID, String username, String role, ActionEvent loginButtonEvent, String fxmlAbsolutePath, String cssAbsolutePath) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlAbsolutePath));
        Parent root = loader.load();
        String formatedUserID = String.format("%03d", userID);
        
        if(role.equalsIgnoreCase("Cashier")) {
            CashierController cashierController = loader.getController();
            cashierController.displayName(username + "#" + formatedUserID);
        }
        
        root.getStylesheets().add(getClass().getResource(cssAbsolutePath).toExternalForm());
        
        Stage stage = (Stage) ((Node) loginButtonEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setMaximized(true);
    }
    
    
    public void switchInterface(String username, ActionEvent loginButtonActionEvent) throws IOException {
        int userID = UserService.getUserID();
        String role = UserService.getRole();
        
        switch(role) {
            case "Admin" -> createInterface(userID, username, role, loginButtonActionEvent,
                            "/com/goat/project/system/view/owner_dashboard.fxml",
                            "/com/goat/project/system/css/owner_dashboard.css");

            case "Cashier" -> createInterface(userID, username, role, loginButtonActionEvent,
                            "/com/goat/project/system/view/cashier.fxml",
                            "/com/goat/project/system/css/cashier.css");

            default -> createInterface(attempts, username, username, loginButtonActionEvent, username, username);
        }
    }
}
