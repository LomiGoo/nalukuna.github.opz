package com.goat.project.system.repository;

import com.goat.project.system.model.Receipt;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ReceiptRepo {
    public static void addReceipt(Receipt receipt) {
        
        String sql = "INSERT INTO receipt(user_id, sales, time, date) "
                   + "VALUES(?, ?, ?, ?)";
        
        try(Connection conn = DatabaseConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            
            statement.setInt(1, receipt.getUserID());
            statement.setDouble(2, receipt.getSales());
            statement.setString(3, receipt.getTime());
            statement.setString(4, receipt.getDate());    
            
            statement.executeUpdate();
            System.out.println("Receipt added!");
            
        } catch(SQLException e) {
            System.err.println("Error adding Receipt: " + e.getMessage());
        }
    }
    
    public static ArrayList<Receipt> readReceipt() {
        String sql = "SELECT receipt.*, user.username FROM receipt " 
                   + "JOIN user ON receipt.user_id = user.user_id "
                   + "ORDER BY receipt.receipt_id DESC";
        ArrayList<Receipt> receiptList = new ArrayList<>();
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            
            ResultSet rs = statement.executeQuery();
            
            while(rs.next()) {
                Receipt receipt = new Receipt(
                    rs.getInt("receipt_id"),
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getFloat("sales"),
                    rs.getString("time"),
                    rs.getString("date")
                );
                receiptList.add(receipt);
            }
            
        return receiptList;
        } catch(SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;
    }
    
    
    public static void deleteAndResetReceipt(int ReceiptIdToDelete) {
        String deleteSql = "DELETE FROM receipt WHERE receipt_id = ?";
        String resetSql = "UPDATE sqlite_sequence SET seq = (SELECT COALESCE(MAX(receipt_id), 0) FROM receipt) WHERE name = 'receipt'";

        try (Connection conn = DatabaseConnection.getConnection()) {
            PreparedStatement deleteStatement = conn.prepareStatement(deleteSql);
            deleteStatement.setInt(1, ReceiptIdToDelete);
            
            int rowsDeleted = deleteStatement.executeUpdate();
            if(rowsDeleted == 0) {
                System.out.println("Warning: No row found with ID: " + ReceiptIdToDelete);
                return;
            }
            System.out.println("Receipt Deleted!");

            PreparedStatement resetStatement = conn.prepareStatement(resetSql);
            resetStatement.executeUpdate();
            System.out.println("Receipt Auto Inc. Resets!");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static int getReceiptID() {
        String sql = "SELECT receipt_id FROM receipt ORDER BY receipt_id DESC LIMIT 1";
        
        try (Connection conn = DatabaseConnection.getConnection();
             Statement statement = conn.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt("receipt_id"); 
            }
        } catch (SQLException e) {
            System.out.println("receipt ID not found.");
        }
        return 0;
    }
}