package com.goat.project.system.model;

public class Category {
    private static int categoryID;
    private static String categoryName;

    public Category(int categoryID, String categoryName) {
        Category.categoryID = categoryID;
        Category.categoryName = categoryName;
    }
    
    public static int getCategoryID() {
        return categoryID;
    }
    
    public static String getCategoryName() {
        return categoryName;
    }   
}
