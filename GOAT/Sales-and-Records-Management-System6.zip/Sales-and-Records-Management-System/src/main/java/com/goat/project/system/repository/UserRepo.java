package com.goat.project.system.repository;
import com.goat.project.system.model.User;

import java.util.ArrayList;

public class UserRepo {
    
    private final ArrayList<User> user;
    
    public UserRepo() {
        user = new ArrayList<>();
        
        user.add(new User("Cjhay Bibit", "bibit123", "Cashier"));
        user.add(new User("Chevelle Nacionales", "lomiAdmin123", "Admin"));
    }

    public ArrayList<User> getUserList() {
        return user;
    }
  
}
