package com.goat.project.system.utility;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class CashierHelper {
    public static double parsePriceString(String priceText) {
        String fixPriceString = priceText.replaceAll("[^0-9.]", "");
        return Double.parseDouble(fixPriceString);
    }
    
    public static int parseQtyString(String qtyText) {
        String fixQtyString = qtyText.replaceAll("[^0-9.]", "");
        return Integer.parseInt(fixQtyString);
    }

    public static String formattedReceiptID(double receiptID) {
        return String.format("%010d", (long) receiptID);
    }
    
    public static String formattedUser(int userID) {
        return String.format("%03d", userID);
    }
     
    public static void setCategoryLabelsCss(Label newCategory, Label refCategoryChoice) {
        newCategory.setStyle(refCategoryChoice.getStyle());
        newCategory.setFont(refCategoryChoice.getFont());
        newCategory.setTextFill(refCategoryChoice.getTextFill());
        newCategory.setPrefSize(refCategoryChoice.getPrefWidth(), refCategoryChoice.getPrefHeight());
        newCategory.setMinHeight(refCategoryChoice.getMinHeight());
        newCategory.setMaxHeight(refCategoryChoice.getMaxHeight());
        newCategory.setPadding(refCategoryChoice.getPadding());
        VBox.setMargin(newCategory, VBox.getMargin(refCategoryChoice));
    }
    
    public static void setContainerCss(VBox newItemContainer, VBox itemFrame) {
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
    }
    
    public static void setItemLabelsCss(Label itemNameLabel, Label itemPriceLabel, Label refItemLabel, Label refPriceLabel) {
        itemNameLabel.setFont(refItemLabel.getFont());
        itemNameLabel.setTextFill(refItemLabel.getTextFill());
        itemNameLabel.setAlignment(Pos.TOP_LEFT);
        itemNameLabel.setPrefSize(refItemLabel.getPrefWidth(), refItemLabel.getPrefHeight());
        itemNameLabel.setPadding(refItemLabel.getPadding());
        VBox.setMargin(itemNameLabel, new Insets(15, 0, 0, 0));
        itemNameLabel.setWrapText(true);
        
        itemPriceLabel.setStyle(refPriceLabel.getStyle());
        itemPriceLabel.setFont(refPriceLabel.getFont());
        itemPriceLabel.setTextFill(refItemLabel.getTextFill());
        itemPriceLabel.setPrefSize(refPriceLabel.getPrefWidth(), refPriceLabel.getPrefHeight());
        itemPriceLabel.setPadding(refPriceLabel.getPadding());
        VBox.setMargin(itemPriceLabel, new Insets(15, 0, 0, 0));
        itemPriceLabel.setPadding(refPriceLabel.getPadding());
    }
    
    public static void setTransactionLabelsCss(Label quantityLabel, Label itemIDLabel, Label itemLabel, Label priceLabel, Label refTransactQuantity, Label refTransactItemID, Label refTransactItem, Label refTransactPrice) {
        quantityLabel.setFont(refTransactQuantity.getFont());
        quantityLabel.setStyle(refTransactQuantity.getStyle());
        quantityLabel.setAlignment(Pos.CENTER);
        quantityLabel.setPrefSize(refTransactQuantity.getPrefWidth(), refTransactQuantity.getPrefHeight());
        quantityLabel.setWrapText(true);
        
        itemIDLabel.setFont(refTransactItemID.getFont());
        itemIDLabel.setStyle(refTransactItemID.getStyle());
        itemIDLabel.setStyle(refTransactItemID.getStyle());
        itemIDLabel.setAlignment(Pos.CENTER);
        itemIDLabel.setPrefSize(refTransactItemID.getPrefWidth(), refTransactItemID.getPrefHeight());
        itemIDLabel.setWrapText(true);
        
        itemLabel.setFont(refTransactItem.getFont());
        itemLabel.setStyle(refTransactItem.getStyle());
        itemLabel.setStyle(refTransactItem.getStyle());
        itemLabel.setAlignment(Pos.CENTER);
        itemLabel.setPrefSize(refTransactItem.getPrefWidth(), refTransactItem.getPrefHeight());
        itemLabel.setWrapText(true);
        
        priceLabel.setFont(refTransactPrice.getFont());
        priceLabel.setStyle(refTransactPrice.getStyle());
        priceLabel.setStyle(refTransactPrice.getStyle());
        priceLabel.setAlignment(Pos.CENTER);
        priceLabel.setPrefSize(refTransactPrice.getPrefWidth(), refTransactPrice.getPrefHeight());
        priceLabel.setWrapText(true);
    }
    
    public static Label getQtyLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(0);
    }

    public static Label getItemLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(2);
    }
    
    public static Label getPriceLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(3);
    }
}
