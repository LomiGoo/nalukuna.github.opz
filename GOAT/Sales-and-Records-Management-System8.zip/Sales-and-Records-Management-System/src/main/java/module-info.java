module com.goat.project.system {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql; 
    requires org.xerial.sqlitejdbc; // Essential for the SQLite driver
    opens com.goat.project.system.controller to javafx.fxml;
    exports com.goat.project.system;
}
