package com.goat.project.system.repository;
import com.goat.project.system.model.User;

import java.util.ArrayList;

public class UserRepo {
    
    private final ArrayList<User> user;
    
    public UserRepo() {
        user = new ArrayList<>();
        
        user.add(new User("Ron Samaniego", "SBAPN123", "Cashier"));
        user.add(new User("admin", "admin123", "Admin"));
    }

    public ArrayList<User> getUserList() {
        return user;
    }
  
}
