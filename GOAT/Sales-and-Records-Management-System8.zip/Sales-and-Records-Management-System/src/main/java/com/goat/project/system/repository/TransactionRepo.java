package com.goat.project.system.repository;

import com.goat.project.system.model.Transaction;
import java.util.ArrayList;

public class TransactionRepo {
    private final ArrayList<Transaction> transaction;

    public TransactionRepo(Integer quantity, long itemID, String item, Double price) {
        transaction = new ArrayList<>();
        
        transaction.add(new Transaction(quantity, itemID, item, price));
    }

    public ArrayList<Transaction> getTransaction() {
        return transaction;
    }
}