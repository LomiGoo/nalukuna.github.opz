package com.goat.project.system.utility;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierControllerHelper {
    public void applyCategoryCssProperty(Label label, Label referencedLabel) {
        label.setStyle(referencedLabel.getStyle());
        label.setFont(referencedLabel.getFont());
        label.setTextFill(referencedLabel.getTextFill());
        label.setPrefSize(referencedLabel.getPrefWidth(), referencedLabel.getPrefHeight());
        label.setMinHeight(referencedLabel.getMinHeight());
        label.setMaxHeight(referencedLabel.getMaxHeight());
        label.setPadding(referencedLabel.getPadding());
        VBox.setMargin(label, VBox.getMargin(referencedLabel));
    }
    
    public void applyItemListCssProperty(Label label1, Label label2, Label referencedLabel1, Label referencedLabel2) {
        label1.setFont(referencedLabel1.getFont());
        label1.setTextFill(referencedLabel1.getTextFill());
        label1.setAlignment(Pos.TOP_LEFT);
        label1.setPrefSize(referencedLabel1.getPrefWidth(), referencedLabel1.getPrefHeight());
        label1.setPadding(referencedLabel1.getPadding());
        VBox.setMargin(label1, new Insets(15, 0, 0, 0));
        label1.setWrapText(true);
        
        label2.setStyle(referencedLabel2.getStyle());
        label2.setFont(referencedLabel2.getFont());
        label2.setTextFill(referencedLabel1.getTextFill());
        label2.setPrefSize(referencedLabel2.getPrefWidth(), referencedLabel2.getPrefHeight());
        label2.setPadding(referencedLabel2.getPadding());
        VBox.setMargin(label2, new Insets(15, 0, 0, 0));
        label2.setPadding(referencedLabel2.getPadding());
    }
    
    public void applyTransactionCssProperty(Label label1, Label label2, Label label3, Label label4, Label referencedLabel1, Label referencedLabel2, Label referencedLabel3, Label referencedLabel4) {
        label1.setFont(referencedLabel1.getFont());
        label1.setStyle(referencedLabel1.getStyle());
        label1.setAlignment(Pos.CENTER);
        label1.setPrefSize(referencedLabel1.getPrefWidth(), referencedLabel1.getPrefHeight());
        label1.setWrapText(true);
        
        label2.setFont(referencedLabel2.getFont());
        label2.setStyle(referencedLabel2.getStyle());
        label2.setStyle(referencedLabel2.getStyle());
        label2.setAlignment(Pos.CENTER);
        label2.setPrefSize(referencedLabel2.getPrefWidth(), referencedLabel2.getPrefHeight());
        label2.setWrapText(true);
        
        label3.setFont(referencedLabel3.getFont());
        label3.setStyle(referencedLabel3.getStyle());
        label3.setStyle(referencedLabel3.getStyle());
        label3.setAlignment(Pos.CENTER);
        label3.setPrefSize(referencedLabel3.getPrefWidth(), referencedLabel3.getPrefHeight());
        label3.setWrapText(true);
        
        label4.setFont(referencedLabel4.getFont());
        label4.setStyle(referencedLabel4.getStyle());
        label4.setStyle(referencedLabel4.getStyle());
        label4.setAlignment(Pos.CENTER);
        label4.setPrefSize(referencedLabel4.getPrefWidth(), referencedLabel4.getPrefHeight());
        label4.setWrapText(true);
    }
}
