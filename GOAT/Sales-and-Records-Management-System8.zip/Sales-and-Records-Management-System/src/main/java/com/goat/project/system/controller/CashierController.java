package com.goat.project.system.controller;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.utility.CashierControllerHelper;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javafx.application.Platform;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Labeled;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class CashierController {
    @FXML
    private Label cashierUser;
    @FXML
    private Label cashierDateDisplay;
    @FXML
    private Label cashierTimeDisplay;
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label categoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label item, price;
    @FXML
    private VBox itemFrame;
    @FXML
    private FlowPane itemContainer;
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label transactQuantity, transactItemID, transactItem, transactPrice;
    @FXML
    private HBox transactionLine;
    @FXML
    private VBox transactionList;
    
    @FXML
    private RadioButton deductItemRadio, removeItemRadio;
   
    @FXML
    private Button clearTransactionButton, completeTransactionButton;
    
    @FXML
    private Label totalPrice;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        java.time.format.DateTimeFormatter dateFormatter = 
        java.time.format.DateTimeFormatter.ofPattern("MMMM dd, yyyy");
    
        String formattedDate = java.time.LocalDate.now().format(dateFormatter);
    
        cashierDateDisplay.setText(formattedDate);
        
        java.time.format.DateTimeFormatter timeFormatter = 
        java.time.format.DateTimeFormatter.ofPattern("h:mm:ss a");

        javafx.animation.Timeline clock = new javafx.animation.Timeline(
        new javafx.animation.KeyFrame(javafx.util.Duration.ZERO, e -> {
            String currentTime = java.time.LocalTime.now().format(timeFormatter);
            cashierTimeDisplay.setText(currentTime); 
        }),
        new javafx.animation.KeyFrame(javafx.util.Duration.seconds(1))
    );    
        clock.setCycleCount(javafx.animation.Timeline.INDEFINITE);
        clock.play();
        
        loadAllCategories();
        transactionList.getChildren().clear();
        itemContainer.getChildren().clear();
        
        totalPrice.setText("TOTAL : ₱0.00");
        clearTransactionButton.setOnAction(e -> {
            transactionList.getChildren().clear();
            totalPrice.setText("TOTAL : ₱0.00");
        });
    }
    
    @FXML 
    public void displayName(String username) {
        cashierUser.setText("Cashier: " + username);
    }

    @FXML
    private void createCategory(Long categoryCount, String category) {         
        Label newCategory = new Label(categoryCount + ". " + category);

        newCategory.setOnMouseClicked(e -> {
            chooseCategory(category);
        });
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();      
        cashierControllerHelper.applyCategoryCssProperty(newCategory, categoryChoice);

        categoryContainer.getChildren().add(newCategory);
        
        completeTransactionButton.setOnAction(e -> {
            if (!transactionList.getChildren().isEmpty()) {
            saveTransactionToFile();  
            transactionList.getChildren().clear();
            totalPrice.setText("₱0.00");
            System.out.println("Transaction finalized and recorded.");
        }
        });
    }
    
    @FXML
    private void loadAllCategories() {
        CategoryService categoryService = new CategoryService();
        categoryContainer.getChildren().clear();
        
        for (Category category : categoryService.getCategoryRepo().getCategoryList()) {
            createCategory(category.getCategoryCount(), category.getCategory());   
        }
    }
    
    @FXML
    private void chooseCategory(String chosenCategory) {      
        loadItemList(chosenCategory);
    }
    
    int marginStop = 0;
    @FXML
    private void createItemList(String itemID, String newItem, Double newPrice) {            
        VBox newItemContainer = new VBox();
        
        newItemContainer.setOnMouseClicked(e -> {
            chooseItemList(itemID, newItem, newPrice, false);
        });
        
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
   
        if(marginStop == 1) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 0));
        if(marginStop == 0) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 10));
        marginStop++;
        if(marginStop == 4) marginStop = 0;
        
        Label newItemName = new Label(newItem);
        Label newItemPrice = new Label(String.format("₱%.2f", newPrice));
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();
        cashierControllerHelper.applyItemListCssProperty(newItemName, newItemPrice, item, price);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(newItemName, newItemPrice);     
    }
    
    @FXML
    private void loadItemList(String chosenCategory) {
    ItemListService itemListService = new ItemListService();
    
    itemContainer.getChildren().clear();
    marginStop = 0;

        for (ItemList items : itemListService.getItemListRepo().getItemList()) {    
            if(items.getCategory().equalsIgnoreCase(chosenCategory)) {
                String formattedID = String.format("ITEM-%03d", items.getItemID());
                createItemList(formattedID, items.getItemName(), items.getItemPrice());  
            }
        }
    }
    private static ArrayList<Integer> activeRecordLine = new ArrayList<>();
    private int recordLineID = 1;
    
    @FXML
private void chooseItemList(String itemID, String chosenItem, Double itemPrice, boolean isFromHBox) {
    HBox existing = null;

    for (Node node : transactionList.getChildren()) {
        if (node instanceof HBox row && row.getChildren().size() == 4) {
            Label nameLabel = (Label) row.getChildren().get(2);
            if (nameLabel.getText().equals(chosenItem)) {
                existing = row;
                break; 
            }
        }
    }

    if (existing != null) {
        if (isFromHBox) {
            if (removeItemRadio.isSelected()) {
                transactionList.getChildren().remove(existing);
            } 
            else if (deductItemRadio.isSelected()) {
                Label qtyLabel = (Label) existing.getChildren().get(0);
                int currentQty = Integer.parseInt(qtyLabel.getText());
                if (currentQty > 1) {
                    int newQty = currentQty - 1;
                    qtyLabel.setText(String.valueOf(newQty));
                    Label priceLabel = (Label) existing.getChildren().get(3);
                    priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
                } else {
                    transactionList.getChildren().remove(existing);
                }
            }
        } else {
            Label qtyLabel = (Label) existing.getChildren().get(0);
            int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
            qtyLabel.setText(String.valueOf(newQty));
            Label priceLabel = (Label) existing.getChildren().get(3);
            priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
        }
    }else if (!isFromHBox) {
        addItemToTransaction(itemID, chosenItem, itemPrice);      
    }
    updateGrandTotal();
}

    @FXML
    private void updateGrandTotal() {
    double grandTotal = 0.0;
    for (Node node : transactionList.getChildren()) {
        if (node instanceof HBox row) {
            Label pLabel = (Label) row.getChildren().get(3);
            
            String priceText = pLabel.getText().replace("₱", "").replace(",", "").trim();
            grandTotal += Double.parseDouble(priceText);
        }
    }
    totalPrice.setText("TOTAL : " + String.format("₱%.2f", grandTotal));
}
    
    @FXML
    private void addItemToTransaction(String itemID, String chosenItem, Double itemPrice) {   
        HBox newRow = new HBox(); 
        newRow.setId("Record ID : " + recordLineID);
        activeRecordLine.add(recordLineID);
        recordLineID++;
        
        newRow.setOnMouseClicked(e -> {
            chooseItemList(itemID, chosenItem, itemPrice, true);
        });
        
        Label newQuantityLabel = new Label("1");
        Label newItemIDLabel = new Label(itemID);            
        Label newItemLabel = new Label(chosenItem);            
        Label newPriceLabel = new Label(String.format("₱%.2f", itemPrice));
        
        CashierControllerHelper helper = new CashierControllerHelper();
        helper.applyTransactionCssProperty(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel, 
                                           transactQuantity, transactItemID, transactItem, transactPrice);
        
        newRow.setPrefSize(transactionLine.getPrefWidth(), transactionLine.getPrefHeight());
        newRow.setMinHeight(transactionLine.getMinHeight());
        newRow.getChildren().addAll(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel);

        transactionList.getChildren().add(newRow);
    }
       
    //private static final BigInteger recordLog = BigInteger.ONE;
    
    @FXML
    private void saveTransactionToFile() {
    java.time.format.DateTimeFormatter dateTimeFormatter = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");
    String timestamp = java.time.LocalDateTime.now().format(dateTimeFormatter);
    
    LocalDateTime now = LocalDateTime.now();
    DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    //String dateFormatString = now.format(dateFormat);
    
    try (java.io.FileWriter writer = new java.io.FileWriter("Sales Records/sales_history.txt", true)) {
        //recordLog.add(BigInteger.ONE);

        writer.write("=================================================\n");
        writer.write("           DIOSARAP SYSTEM RECEIPT        \n");
        writer.write("          Date: " + timestamp + "\n");
        writer.write("=================================================\n");
        
        writer.write(String.format("%-5s | %-10s | %-15s | %-10s%n", "QTY", "ID", "ITEM", "PRICE"));
        writer.write("-------------------------------------------------\n");

        for (Node node : transactionList.getChildren()) {
            if (node instanceof HBox row) {
                String qty = ((Labeled) row.getChildren().get(0)).getText();
                var id = ((Labeled) row.getChildren().get(1)).getText();
                String name = ((Labeled) row.getChildren().get(2)).getText();
                String price = ((Labeled) row.getChildren().get(3)).getText();
                
                writer.write(String.format("%-5s | %-10s | %-15s | %-10s%n", qty, id, name, price));
            }
        }
        
        writer.write("-------------------------------------------------\n");
        writer.write(String.format("%30s %s%n", "GRAND TOTAL:", totalPrice.getText()));
        writer.write("=================================================\n\n");
        
        System.out.println("Receipt finalized and saved.");
    } catch (java.io.IOException e) {
        System.err.println("Error saving receipt: " + e.getMessage());
    }
}
    
    @FXML
    private void handleExit() {
        Platform.exit();
    }
}