package com.goat.project.system.model;

public class ItemList {
    private static int itemID;
    private static int categoryID;
    private static String itemName;
    private static double price;
    
    public ItemList(int itemID, int categoryID, String itemName, double price) {
        ItemList.itemID = itemID;
        ItemList.categoryID = categoryID;
        ItemList.itemName = itemName;
        ItemList.price = price;
    }

    public static int getItemID() {
        return itemID;
    }
    
    public static String getItemName() {
        return itemName;
    }

    public static double getPrice() {
        return price;
    }

    public static int getCategoryID() {
        return categoryID;
    }  
}
