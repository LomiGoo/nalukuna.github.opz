package com.goat.project.system.utility;

import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;

public class Charts {
    private final BarChart<String, Number> monthlyBar, yearlyBar;
    
    String[] months = {"January", "February", "March",
                       "April", "May", "June", "July",
                       "August", "September", "October",
                       "November", "December"};
    
    public Charts(BarChart<String, Number> monthlyBar, BarChart yearlyBar) {
        this.monthlyBar = monthlyBar;
        this.yearlyBar = yearlyBar;
    }
    
    public void implementMonthlyBar(int year, int month, int sales, int expenses, int profit) { 
        monthlyBar.getData().clear();

        XYChart.Data<String, Number> salesData = new XYChart.Data<>("Sales", sales);
        XYChart.Data<String, Number> expensesData = new XYChart.Data<>("Expenses", expenses);
        XYChart.Data<String, Number> profitData = new XYChart.Data<>("Profit", profit);
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.getData().addAll(salesData, expensesData, profitData);

        monthlyBar.getData().add(series1);

        salesData.getNode().setStyle("-fx-bar-fill: #2ecc71;");   
        expensesData.getNode().setStyle("-fx-bar-fill: #e74c3c;"); 
        profitData.getNode().setStyle("-fx-bar-fill: #3498db;");  
    }
    
    public void implementYearlyBar(int year, int sales, int expenses, int profit) {      
        yearlyBar.getData().clear();

        XYChart.Data<String, Number> salesData = new XYChart.Data<>("Sales", sales);
        XYChart.Data<String, Number> expensesData = new XYChart.Data<>("Expenses", expenses);
        XYChart.Data<String, Number> profitData = new XYChart.Data<>("Profit", profit);
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.getData().addAll(salesData, expensesData, profitData);

        yearlyBar.getData().add(series1);

        salesData.getNode().setStyle("-fx-bar-fill: #2ecc71;");   
        expensesData.getNode().setStyle("-fx-bar-fill: #e74c3c;");
        profitData.getNode().setStyle("-fx-bar-fill: #3498db;");  
    }
    /*
    public void implementMonthlyPie(int year, int month, int sales, int expenses, int profit) {
        monthlyPie.getData().clear();
        monthlyPie.setLegendVisible(false);
        PieChart.Data salesData = new PieChart.Data("Sales", sales);
        PieChart.Data expensesData = new PieChart.Data("Expenses", expenses);
        PieChart.Data profitData = new PieChart.Data("Profit", profit);
        
        monthlyPie.setData(FXCollections.observableArrayList(
                salesData, expensesData, profitData
        ));
        
        monthlabel.setText(months[month]);
        monthlyPie.setLegendVisible(true);
    }
    
     public void implementYearlyPie(int year, int sales, int expenses, int profit) {
        yearlyPie.getData().clear();
        yearlyPie.setLegendVisible(false);
        PieChart.Data salesData = new PieChart.Data("Sales", sales);
        PieChart.Data expensesData  = new PieChart.Data("Expenses", expenses);
        PieChart.Data profitData = new PieChart.Data("Profit", profit);
        
        yearlyPie.setData(FXCollections.observableArrayList(
                salesData, expensesData, profitData
        ));
        
        yearLabel.setText("YEAR " + year);
        yearlyPie.setLegendVisible(true);
    }
    */
}
