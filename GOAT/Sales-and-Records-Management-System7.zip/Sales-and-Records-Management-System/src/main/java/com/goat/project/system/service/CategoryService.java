package com.goat.project.system.service;
import com.goat.project.system.repository.CategoryRepo;

public class CategoryService {
    private final CategoryRepo categoryRepo = new CategoryRepo();

    public CategoryRepo getCategoryRepo() {
        return categoryRepo;
    }  
}
