package com.goat.project.system.utility;

import com.goat.project.system.controller.CashierController;
import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class loginHelper {
    public boolean isInputEmpty(String username, String password) {
        if(username.trim().isEmpty()) return false;
        return !password.trim().isEmpty();
    }
    
    static int attempts = 3;
    public void displayErrorNotification(Label notificationError, Label notificationAttempts) {     
        notificationError.setVisible(true);
        notificationError.setText("Note : User Not Found, Please Try Again");
        notificationAttempts.setVisible(true);
        notificationAttempts.setText("Attempts Left : " + --attempts); 

        if(attempts == 0) {
            Platform.exit();
        }
    }
    
    public void createInterface(String username, String selectedRole, ActionEvent loginButtonEvent, String fxmlAbsolutePath, String cssAbsolutePath) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlAbsolutePath));
        Parent root = loader.load();
        
        if("Cashier".equals(selectedRole)) {
            CashierController cashierController = loader.getController();
            cashierController.displayName(username);
        }
        
        root.getStylesheets().add(getClass().getResource(cssAbsolutePath).toExternalForm());
        
        Stage stage = (Stage) ((Node) loginButtonEvent.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setMaximized(true);
    }
    
    public void switchInterface(String username, String selectedRole, ActionEvent loginButtonActionEvent) throws IOException {
        switch(selectedRole) {
            case "Admin" -> createInterface(username, selectedRole, loginButtonActionEvent,
                            "/com/goat/project/system/ui/owner_dashboard.fxml",
                            "/com/goat/project/system/css/owner_dashboard.css");

            case "Cashier" -> createInterface(username, selectedRole, loginButtonActionEvent,
                            "/com/goat/project/system/ui/cashier.fxml",
                            "/com/goat/project/system/css/cashier.css");

            default -> System.out.println("No such Role Exists.");
        }
    }
}
