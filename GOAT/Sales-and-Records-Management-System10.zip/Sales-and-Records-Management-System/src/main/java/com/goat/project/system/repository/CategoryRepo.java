package com.goat.project.system.repository;

import com.goat.project.system.model.Category;
import java.util.ArrayList;


public class CategoryRepo {
    private final ArrayList<Category> category;
    
    public CategoryRepo() {
        category = new ArrayList<>();
        
        category.add(new Category(1, "Main Dish"));
        category.add(new Category(2, "Drinks"));
    }

    public ArrayList<Category> getCategoryList() {
        return category;
    }
}
