package com.goat.project.system.repository;

import com.goat.project.system.model.Transaction;
import java.util.ArrayList;

public class TransactionRepo {
    private final ArrayList<Transaction> transaction;

    public TransactionRepo(String item, Integer quantity, Double price) {
        transaction = new ArrayList<>();
        
        transaction.add(new Transaction(item, quantity, price));
    }

    public ArrayList<Transaction> getTransaction() {
        return transaction;
    }
}