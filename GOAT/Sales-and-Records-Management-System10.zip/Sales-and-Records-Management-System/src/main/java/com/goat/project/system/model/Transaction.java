package com.goat.project.system.model;

public class Transaction {
    private final Integer quantity;
    private final String item;
    private final Double price;

    public Transaction(String item, Integer quantity, Double price) {
        this.item = item;
        this.quantity = quantity;
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public String getItem() {
        return item;
    }

    public Double getPrice() {
        return price;
    }
}
