package com.goat.project.system.service;

import com.goat.project.system.model.User;
import com.goat.project.system.repository.UserRepo;


public class UserService {
    public static boolean findUser(int userID)  {
        return UserRepo.getUserById(userID) != null;
    }
    
    public static int getUserID() {
        return User.getUserID();
    }
    
    public static String getRole() {
        return User.getRole();
    }
}
