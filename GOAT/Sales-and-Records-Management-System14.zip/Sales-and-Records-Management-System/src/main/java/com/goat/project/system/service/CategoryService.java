package com.goat.project.system.service;
import com.goat.project.system.model.Category;
import com.goat.project.system.repository.CategoryRepo;

public class CategoryService {
    public static boolean findCategory(int categoryID)  {
        return CategoryRepo.getCategoryByID(categoryID) != null;
    }
    
    public static int getCategoryID() {
        return Category.getCategoryID();
    }
    
     public static String getCategory() {
        return Category.getCategory();
    }
}
