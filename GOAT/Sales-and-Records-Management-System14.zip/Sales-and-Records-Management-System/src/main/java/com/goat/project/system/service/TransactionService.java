package com.goat.project.system.service;

import com.goat.project.system.model.Transaction;
import com.goat.project.system.repository.TransactionRepo;
import java.util.function.Consumer;

public class TransactionService {

    public TransactionService() {
    }
    private TransactionRepo transactionRepo;
    
    public void displayAllOrders(Consumer<Transaction> broadcastOrder) {        
        for(Transaction order : getTransactionRepo().getTransaction()) {
            broadcastOrder.accept(new Transaction(order.getItem(), order.getQuantity(), order.getPrice()));
        }
    }

    public TransactionRepo getTransactionRepo() {
        return transactionRepo;
    }
}
