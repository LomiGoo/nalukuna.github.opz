package com.goat.project.system.utility;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class CashierHelper { 
    public static double parsePriceString(String priceText) {
        String fixPriceString = priceText.replaceAll("[^0-9.]", "");
        return Double.parseDouble(fixPriceString);
    }
    
    public static int parseQtyString(String qtyText) {
        String fixQtyString = qtyText.replaceAll("[^0-9.]", "");
        return Integer.parseInt(fixQtyString);
    }

    public static String formattedReceiptID(double receiptID) {
        return String.format("%010d", (long) receiptID);
    }
    
    public static String formattedUser(int userID) {
        return String.format("%03d", userID);
    }
     
    public static void setCategoryLabelsCss(Label newCategory, Label refCategoryChoice) {
        newCategory.setStyle(refCategoryChoice.getStyle());
        newCategory.setFont(refCategoryChoice.getFont());
        newCategory.setTextFill(refCategoryChoice.getTextFill());
        newCategory.setPrefSize(refCategoryChoice.getPrefWidth(), refCategoryChoice.getPrefHeight());
        newCategory.setMinHeight(refCategoryChoice.getMinHeight());
        newCategory.setMaxHeight(refCategoryChoice.getMaxHeight());
        newCategory.setPadding(refCategoryChoice.getPadding());
        VBox.setMargin(newCategory, VBox.getMargin(refCategoryChoice));
    }
    
    public static void setContainerCss(VBox newItemFrame, VBox refItemFrame) {
        newItemFrame.setStyle(refItemFrame.getStyle());
        newItemFrame.setPrefSize(refItemFrame.getPrefWidth(), refItemFrame.getPrefHeight());
        newItemFrame.setPadding(refItemFrame.getPadding());
        newItemFrame.setFillWidth(true);
    }
    
    public static void setItemLabelsCss(Label itemNameLabel, Label itemPriceLabel, Label refItemLabel, Label refPriceLabel) {
        itemNameLabel.setFont(refItemLabel.getFont());
        itemNameLabel.setTextFill(refItemLabel.getTextFill());
        itemNameLabel.setAlignment(Pos.TOP_LEFT);
        itemNameLabel.setPrefSize(refItemLabel.getPrefWidth(), refItemLabel.getPrefHeight());
        itemNameLabel.setPadding(refItemLabel.getPadding());
        VBox.setMargin(itemNameLabel, new Insets(15, 0, 0, 0));
        itemNameLabel.setWrapText(true);
        
        itemPriceLabel.setStyle(refPriceLabel.getStyle());
        itemPriceLabel.setFont(refPriceLabel.getFont());
        itemPriceLabel.setTextFill(refPriceLabel.getTextFill());
        itemPriceLabel.setPrefSize(refPriceLabel.getPrefWidth(), refPriceLabel.getPrefHeight());
        itemPriceLabel.setPadding(refPriceLabel.getPadding());
        VBox.setMargin(itemPriceLabel, new Insets(15, 0, 0, 0));
        itemPriceLabel.setPadding(refPriceLabel.getPadding());
    }
    
    public static void setTransactionLabelsCss(HBox quantityModifier, Button addQuantity, Button deductQuantity, Button deleteItem,
                                               Label quantityLabel, Label itemIDLabel, Label itemLabel, Label priceLabel, Label customerType,
                                               HBox refQuantityModifier, Button refAddQuantity, Button refDeductQuantity, Button refDeleteItem, 
                                               Label refTransactQuantity, Label refTransactItemID, Label refTransactItem,
                                               Label refTransactPrice, Label refCustomerType) {
        quantityModifier.setAlignment(Pos.CENTER);
        quantityModifier.setPrefSize(refQuantityModifier.getPrefWidth(), refQuantityModifier.getPrefHeight());
        HBox.setMargin(quantityModifier, HBox.getMargin(refQuantityModifier));
        quantityModifier.setSpacing(refQuantityModifier.getSpacing());
        
        addQuantity.setFont(refAddQuantity.getFont());
        addQuantity.setStyle(refAddQuantity.getStyle());
        addQuantity.setPrefSize(refAddQuantity.getPrefWidth(), refAddQuantity.getPrefHeight());
        
        deductQuantity.setFont(refDeductQuantity.getFont());
        deductQuantity.setStyle(refDeductQuantity.getStyle());
        deductQuantity.setPrefSize(refDeductQuantity.getPrefWidth(), refDeductQuantity.getPrefHeight());
        
        deleteItem.setFont(refDeleteItem.getFont());
        deleteItem.setStyle(refDeleteItem.getStyle());
        deleteItem.setPrefSize(refDeleteItem.getPrefWidth(), refDeleteItem.getPrefHeight());
        
        quantityLabel.setFont(refTransactQuantity.getFont());
        quantityLabel.setStyle(refTransactQuantity.getStyle());
        quantityLabel.setAlignment(Pos.CENTER);
        quantityLabel.setPrefSize(refTransactQuantity.getPrefWidth(), refTransactQuantity.getPrefHeight());
        quantityLabel.setWrapText(true);
        
        itemIDLabel.setFont(refTransactItemID.getFont());
        itemIDLabel.setStyle(refTransactItemID.getStyle());
        itemIDLabel.setAlignment(Pos.CENTER);
        itemIDLabel.setPrefSize(refTransactItemID.getPrefWidth(), refTransactItemID.getPrefHeight());
        itemIDLabel.setWrapText(true);
        
        itemLabel.setFont(refTransactItem.getFont());
        itemLabel.setStyle(refTransactItem.getStyle());
        itemLabel.setAlignment(Pos.CENTER);
        itemLabel.setPrefSize(refTransactItem.getPrefWidth(), refTransactItem.getPrefHeight());
        itemLabel.setWrapText(true);
        
        priceLabel.setFont(refTransactPrice.getFont());
        priceLabel.setStyle(refTransactPrice.getStyle());
        priceLabel.setAlignment(Pos.CENTER);
        priceLabel.setPrefSize(refTransactPrice.getPrefWidth(), refTransactPrice.getPrefHeight());
        priceLabel.setWrapText(true);
        
         
        customerType.setFont(refCustomerType.getFont());
        customerType.setStyle(refCustomerType.getStyle());
        customerType.setAlignment(Pos.CENTER);
        customerType.setPrefSize(refCustomerType.getPrefWidth(), refCustomerType.getPrefHeight());
        customerType.setWrapText(true);
        
    }
    
    public static Label getQtyLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(1);
    }

    public static Label getItemLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(3);
    }
    
    public static Label getPriceLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(4);
    }
    
    public static Label getCustomerLabel(HBox hboxNode) {
        return (Label) hboxNode.getChildren().get(5);
    }
}
