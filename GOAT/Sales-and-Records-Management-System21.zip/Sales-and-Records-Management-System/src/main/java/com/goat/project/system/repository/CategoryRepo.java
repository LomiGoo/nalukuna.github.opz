package com.goat.project.system.repository;

import com.goat.project.system.model.Category;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class CategoryRepo {
    public static void addCategory(String categoryName) {
        String sql = "INSERT INTO category(category_name) "
                   + "VALUES(?)";
        
        try(Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, categoryName);
            
            pstmt.executeUpdate();
            System.out.println("Category added!");
            
        } catch(SQLException e) {
            System.err.println("Error adding Category : " + e.getMessage());
        }
    }
        
    public static Category getCategoryByID(int categoryID) {
        String sql = "SELECT * FROM category "
                   + "WHERE category_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement statement = conn. prepareStatement(sql)) {
            
            statement.setInt(1, categoryID);
            ResultSet rs = statement.executeQuery();
            
            if(rs.next()) {
                return new Category(
                    rs.getInt("category_id"),
                    rs.getString("category_name")
                );
            }
            
        } catch(SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;
    }
}
