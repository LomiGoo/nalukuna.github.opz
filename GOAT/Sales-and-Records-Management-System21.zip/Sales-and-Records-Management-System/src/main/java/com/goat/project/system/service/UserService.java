package com.goat.project.system.service;

import com.goat.project.system.model.User;
import com.goat.project.system.repository.UserRepo;


public class UserService {
    public static boolean findUser(int userID, String username, String password)  {
        return UserRepo.getUserById(userID, username, password) != null;
    }
    
    public static int getUserID() {
        return User.getUserID();
    }
    
    public static String getUsername() {
        return User.getUsername();
    }
    
    public static String getRole() {
        return User.getRole();
    }
}
