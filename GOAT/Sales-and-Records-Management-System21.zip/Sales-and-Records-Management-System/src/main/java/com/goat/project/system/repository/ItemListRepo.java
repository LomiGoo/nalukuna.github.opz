package com.goat.project.system.repository;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ChoiceBox;

public class ItemListRepo {
    public static void addItem(int categoryID, String itemName, double price, double expenses) {
        String sql = "INSERT INTO item_list(category_id, item_name, price, expenses) "
                   + "VALUES(?, ?, ?, ?)";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, categoryID);
            pstmt.setString(2, itemName);
            pstmt.setDouble(3, price);
            pstmt.setDouble(4, expenses);

            pstmt.executeUpdate();
            System.out.println("Item added!");

        } catch(SQLException e) {
            System.err.println("Error adding Item : " + e.getMessage());
        }
    }
    
    public static void updateItem(int categoryID, String itemName, int itemID, double price, double expenses) {
        String sql = "UPDATE item_list SET category_id = ?, item_name = ?, price = ?, expenses = ? WHERE item_id = ?";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, categoryID);
            pstmt.setString(2, itemName);
            pstmt.setDouble(3, price);
            pstmt.setDouble(4, expenses);
            pstmt.setDouble(5, itemID);
            
            pstmt.executeUpdate();
            System.out.println("Item updated!");

        } catch(SQLException e) {
            System.err.println("Error Updating Item : " + e.getMessage());
        }
    }
    
    public static void populateCategory(ChoiceBox categoryChoice) {
        ObservableList<Category> categoryList = FXCollections.observableArrayList();

        String query = "SELECT * FROM category";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pst = conn.prepareStatement(query);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                categoryList.add(new Category(
                    rs.getInt("category_id"), 
                    rs.getString("category_name")
                ));
            }

            categoryChoice.setItems(categoryList);

        } catch(SQLException e) {
            System.err.println("Error Populating CategoryChoice : " + e.getMessage());
        }
    }
    
    public static ItemList getItemByID(int itemID) {
        String sql = "SELECT * FROM item_list "
                   + "WHERE item_id = ?";
        
        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement statement = conn. prepareStatement(sql)) {
            
            statement.setInt(1, itemID);
            ResultSet rs = statement.executeQuery();
            
            if (rs.next()) {
                return new ItemList(
                    rs.getInt("item_id"),
                    rs.getInt("category_id"),
                    rs.getString("item_name"),
                    rs.getDouble("price")
                );
            }
            
        } catch(SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;
    }
}
