package com.goat.project.system.controller;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.ReceiptService;
import com.goat.project.system.utility.CashierHelper;
import com.goat.project.system.utility.DateTimeUtils;
import java.io.IOException;

import java.util.ArrayList;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class CashierController {
    @FXML
    private Circle diosarapLogo;
    
    @FXML
    private AnchorPane posBody;
    
    @FXML
    private Label cashierUser;
    @FXML
    private Label dateDisplay;
    @FXML
    private Label timeDisplay;
    
    private Label selectedLabel = null;
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label refCategoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label refItemLabel, refPriceLabel;
    @FXML
    private VBox refItemFrame;
    @FXML
    private FlowPane itemContainer;
    
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label refQuantity, refItemID, refItem, refPrice, refCustomerType;
    @FXML
    private ScrollPane transactionBody;
    @FXML
    private HBox transactionLine;
    @FXML
    private VBox transactionList;
    @FXML
    private Label paymentErrorDisplay;
    @FXML
    private VBox receiptPopUp;
    @FXML
    private TextArea receiptBodyDisplay;
    
    @FXML
    private TextField paymentField;
    
    @FXML
    private HBox refQuantityModifier;
    @FXML
    private Button refAddQuantity, refDeductQuantity, refDeleteItem;
    @FXML
    private RadioButton legalDiscount, ownerDiscount;
   
    @FXML
    private Button clearTransactionButton, completeTransactionButton;
    
    @FXML
    private Label subTotalLabel, totalDueLabel;
    
    private double totalDueReceipt = 0;

    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        Image img = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
        ImagePattern pattern = new ImagePattern(img);
        diosarapLogo.setFill(pattern);
        
        dateDisplay.setText(DateTimeUtils.getFormattedDate());
        displayClock();
        
        displayCategory();
        transactionList.getChildren().clear();
        itemContainer.getChildren().clear();
        
        clearTransactionButton.setOnAction(e -> {
            transactionList.getChildren().clear();
            subTotalLabel.setText("SUB TOTAL : ₱0.00");
            totalDueLabel.setText("TOTAL DUE : ₱0.00");
        });
        
        receiptBodyDisplay.setStyle("-fx-font-family: 'monospace'; -fx-font-size: 11pt;");
        
        paymentField.textProperty().addListener((observable, oldValue, newValue) -> {
            if(newValue == null || newValue.isEmpty()) return; 

            // Updated Regex: Allows digits and ONE optional decimal point
            if(!newValue.matches("\\d*(\\.\\d*)?")) {
                paymentField.setText(oldValue);
            }
        });
        
        completeTransactionButton.setOnAction(e -> {
            if(!transactionList.getChildren().isEmpty()) {
                String cashierName = cashierUser.getText();
                String receiptContent = buildReceipt(cashierName);
                if(receiptContent.isBlank()) return;
                receiptBodyDisplay.setText(receiptContent);
                posBody.setMouseTransparent(true);
                displayReceiptPopup();
            }
        });
        
        Platform.runLater(() -> {
            Node thumb = receiptBodyDisplay.lookup(".scroll-bar .thumb");
            if(thumb != null) {
                thumb.setStyle("-fx-background-color: #ff6f5a; -fx-background-radius: 5;");
            }

            Node track = receiptBodyDisplay.lookup(".scroll-bar .track");
            if(track != null) {
                track.setStyle("-fx-background-color: #303344; -fx-background-radius: 5;");
            }
            
            Node content = receiptBodyDisplay.lookup(".content");
            if(content != null) {
                content.setStyle("-fx-cursor: default;");
            }
        });
        
        receiptBodyDisplay.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if(!e.getTarget().toString().contains("ScrollBar")) {
                receiptBodyDisplay.requestFocus(); 
            }
        });

        receiptBodyDisplay.addEventFilter(MouseEvent.MOUSE_DRAGGED, Event::consume);
        
        Platform.runLater(() -> {
            Node thumb = transactionBody.lookup(".scroll-bar .thumb");
            if(thumb != null) {
                thumb.setStyle("-fx-background-color: #ff6f5a; -fx-background-radius: 5;");
            }

            Node track = transactionBody.lookup(".scroll-bar .track");
            if(track != null) {
                track.setStyle("-fx-background-color: #303344; -fx-background-radius: 5;");
            }
            
            Node content = transactionBody.lookup(".content");
            if(content != null) {
                content.setStyle("-fx-cursor: default;");
            }
        });
        
        transactionBody.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if(!e.getTarget().toString().contains("ScrollBar")) {
                transactionBody.requestFocus(); 
            }
        });
        receiptBodyDisplay.addEventFilter(MouseEvent.MOUSE_DRAGGED, Event::consume);
    }
    
    private void displayReceiptPopup() {
        receiptPopUp.setVisible(true);
        receiptPopUp.setManaged(true);
    }
    
    private String buildReceipt(String cashierName) {
        StringBuilder receipt = new StringBuilder();
        double[] totals = receiptList(new StringBuilder());
        int qtyTotal = (int) totals[0];
        double subTotal = totals[1], discount = totals[2], vatSales = totals[3], 
               vatAmount = totals[4], vatExempt = totals[5], totalDue = totals[6];
        
        try {
            double[] payment = calculateCashPayment(totalDue);
            if(payment == null) return "";
            ReceiptService.saveReceipt(totalDueReceipt);
            double cash = payment[0], change = payment[1];
            paymentErrorDisplay.setVisible(false);

            String headerName = String.format("%27s", "DIOSARAP TAPSIHAN\n");
            String headerLocation = String.format("%33s", "F.Victorino st. Villa Alfonso\n");
            String headerLocation2 = String.format("%28s", "Bambang, Pasig City\n");
            String headerOfficialReceipt = String.format("OR No   : " + CashierHelper.formattedReceiptID(ReceiptService.getReceiptID()) + "\n");
            String headerDate = "DATE    : " + DateTimeUtils.getFormattedDate() + "\n";
            String headerTime = "TIME    : " + DateTimeUtils.getCurrentTime() + "\n";

            String bodyHeader = String.format("%3s %20s %10s\n", "ITEM", "QTY", "PRICE");
            String bodyItemTotal = "ITEM TOTAL : " + qtyTotal + "\n";

            String footSubTotal = String.format("%-20s %15.2f\n", "SUBTOTAL:", subTotal);
            String footDiscount = String.format("%-20s %15.2f\n", "DISCOUNT:", discount);
            String footVatable  = String.format("%-20s %15.2f\n", "VATABLE SALES:", vatSales);
            String footVatAmnt  = String.format("%-20s %15.2f\n", "VAT AMOUNT:", vatAmount);
            String footVatEx = String.format("%-20s %15.2f\n", "VAT EXEMPT:", vatExempt);
            String footTotalDue = String.format("%-20s %15.2f\n", "TOTAL DUE:", totalDue);
            String footCash = String.format("%-20s %15.2f\n", "CASH:", cash);
            String footChange = String.format("%-20s %15.2f\n", "CHANGE:", change);
            String footThanks = " THANK YOU FOR ORDERING! COME AGAIN.\n";

            receipt.append("====================================\n");
            receipt.append(headerName);
            receipt.append(headerLocation);
            receipt.append(headerLocation2);
            receipt.append("====================================\n");
            ArrayList<String> wrappedName = wrapText(cashierName, 23);    
            receipt.append(String.format("%s\n", wrappedName.get(0)));
            for(int i = 1; i < wrappedName.size(); i++) {
                receipt.append(String.format("%-10s%s\n", "", wrappedName.get(i)));
            } 
            receipt.append(headerOfficialReceipt);
            receipt.append(headerDate);
            receipt.append(headerTime);
            receipt.append("====================================\n");
            receipt.append(bodyHeader);
            receipt.append("------------------------------------\n");
            receiptList(receipt);
            receipt.append("\n------------------------------------\n");
            receipt.append(bodyItemTotal);
            receipt.append("------------------------------------\n");
            receipt.append(footSubTotal);
            receipt.append(footDiscount);
            receipt.append("------------------------------------\n");
            receipt.append(footVatable);
            receipt.append(footVatAmnt);
            receipt.append(footVatEx);
            receipt.append("------------------------------------\n");
            receipt.append(footTotalDue);
            totalDueReceipt = totalDue;
            receipt.append(footCash);
            receipt.append(footChange);
            receipt.append("====================================\n");
            receipt.append(footThanks);
            receipt.append("====================================\n");           
        } catch(NullPointerException npe){
            return "";
        }
        return receipt.toString();
    }
    
    private double[] receiptList(StringBuilder receipt) {      
        double totalDue = 0, vatSales = 0, vatAmount = 0, vatExempt = 0, totalDiscount = 0;
        int totalQty = 0;

        for (Node node : transactionList.getChildren()) {
            HBox row = (HBox) node;

            String item = CashierHelper.getItemLabel(row).getText();
            String customerType = CashierHelper.getCustomerLabel(row).getText().toLowerCase();
            int qty = CashierHelper.parseQtyString(CashierHelper.getQtyLabel(row).getText());
            double rowPrice = CashierHelper.parsePriceString(CashierHelper.getPriceLabel(row).getText());

            totalQty += qty;
            totalDue += rowPrice;

            switch (customerType) {
                case "sc/pwd" -> {
                    vatExempt += rowPrice;
                    double originalPrice = (rowPrice / 0.80) * 1.12;
                    totalDiscount += (originalPrice - rowPrice);
                }
                default -> {
                    double vatable = rowPrice / 1.12;
                    vatSales += vatable;
                    vatAmount += (rowPrice - vatable);
                }
            }
            ArrayList<String> wrappedName = wrapText(item, 18);
            receipt.append(String.format("%-18s x%5d %10.2f\n", wrappedName.get(0), qty, rowPrice));
            for (int i = 1; i < wrappedName.size(); i++) {
                receipt.append(String.format("%-18s %5s %10s\n", wrappedName.get(i), "", ""));
            }   
        }
        double subTotal = totalDue + totalDiscount; 
        return new double[]{(double) totalQty, subTotal, totalDiscount, vatSales, vatAmount, vatExempt, totalDue};
    }
    
    private ArrayList<String> wrapText(String text, int limit) {
        ArrayList<String> lines = new ArrayList<>();
        String cleanText = text.replace(",", "").trim(); 
        String[] words = cleanText.split(" ");
        StringBuilder currentLine = new StringBuilder();

        for(String word : words) {
            if(currentLine.length() + word.length() + 1 <= limit) {
                if(currentLine.length() > 0) currentLine.append(" ");
                currentLine.append(word);
            } else{
                lines.add(currentLine.toString());
                currentLine = new StringBuilder(word);
            }
        }
        if(currentLine.length() > 0) lines.add(currentLine.toString());
        return lines;
    }
    
    private double[] calculateCashPayment(double roundedTotal) {
        double cashPaid;

        try {
            String input = paymentField.getText();
            if (input == null || input.isBlank()) return null;
            cashPaid = Double.parseDouble(input);
        } catch(NumberFormatException e) {
            return null;
        }

        double acceptableTotal = Math.floor(roundedTotal);

        if (cashPaid < acceptableTotal) {
            paymentErrorDisplay.setVisible(true);
            return null;
        }

        double change = Math.max(0, cashPaid - roundedTotal);
        if (change < 0.01) change = 0.0;

        return new double[]{cashPaid, change};
    }

    public void createCategory(int categoryLabelCount, int categoryID, String categoryName) {         
        Label newCategory = new Label(categoryLabelCount + ". " + categoryName);
        
        newCategory.setOnMouseClicked(e -> {
            if(selectedLabel != null && selectedLabel != newCategory) {
                selectedLabel.setStyle(""
                + "-fx-background-color : #ff5941;"
                + "-fx-background-radius : 15px;");           
            }
                
            newCategory.setStyle(""
                + "-fx-background-color : green;"
                + "-fx-background-radius : 15px;");
            
            selectedLabel = newCategory;
            
            chooseCategory(categoryID);
        });
        
        CashierHelper.setCategoryLabelsCss(newCategory, refCategoryChoice);

        categoryContainer.getChildren().add(newCategory);        
    }
    
    @FXML
    private void displayCategory() {
        categoryContainer.getChildren().clear();
        int displayLabelCount = 1;

        while(true) {
            Category foundCategory = CategoryService.findCategoryByID(displayLabelCount);

            if(foundCategory != null) {
                createCategory(
                    displayLabelCount, 
                    foundCategory.getCategoryID(), 
                    foundCategory.getCategoryName()
                );
                displayLabelCount++;
            } else break;          
        }
    }
    
    @FXML
    private void chooseCategory(int chosenCategory) {     
        displayItemLists(chosenCategory);
    }
    
    @FXML
    private void displayItemLists(int chosenCategory) {
        itemContainer.getChildren().clear();
        int displayCount = 1;
        
        do {
            if(!ItemListService.findItem(displayCount)) return;
            if(ItemListService.getItemCategoryID()!= chosenCategory) {
                displayCount++;
                continue;
            }
            createItemList(ItemList.getItemID(), ItemList.getItemName(), ItemList.getPrice());
            displayCount++;
        } while(true);
    }
    
    @FXML
    private void createItemList(int itemID, String itemName, double price) {            
        VBox newItemContainer = new VBox();       
        
        newItemContainer.setOnMouseClicked(e -> chooseItemList(itemID, itemName, price, false));
        CashierHelper.setContainerCss(newItemContainer, refItemFrame);
        
        Label itemNameLabel = new Label(itemName);
        Label itemPriceLabel = new Label(String.format("₱%.2f", price));      
        CashierHelper.setItemLabelsCss(itemNameLabel, itemPriceLabel, refItemLabel, refPriceLabel);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(itemNameLabel, itemPriceLabel);     
    }
        
    @FXML
    private void chooseItemList(int itemID, String chosenItem, Double itemPrice, boolean isInTransaction) {   
        String customerType;
        double effectivePrice = itemPrice;

        if (legalDiscount.isSelected()) {
            customerType = "sc/pwd";
            effectivePrice = (itemPrice / 1.12) * 0.80;
        } else {
            customerType = "regular";
        }

        HBox recordLineExistence = recordLineCheck(chosenItem, customerType);

        if (recordLineExistence == null) {
            addItemToTransaction(itemID, chosenItem, effectivePrice, customerType); 
            updateGrandTotal();
            return;
        }    

        if (isInTransaction) return;

        Label qtyLabel = CashierHelper.getQtyLabel(recordLineExistence);
        Label priceLabel = CashierHelper.getPriceLabel(recordLineExistence);
        int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
        qtyLabel.setText(String.valueOf(newQty));
        priceLabel.setText(String.format("₱%.2f", newQty * effectivePrice));
        updateGrandTotal();
    }

    @FXML
    private HBox recordLineCheck(String chosenItem, String customerType) { 
        for (Node node : transactionList.getChildren()) {
            HBox row = (HBox) node;
         
            Label nameLabel = CashierHelper.getItemLabel(row);
            Label typeLabel = CashierHelper.getCustomerLabel(row); 
            
            if (nameLabel.getText().equals(chosenItem) && 
                typeLabel.getText().equalsIgnoreCase(customerType)) {
                return row;
            }
        }
        return null;
    }
    
    @FXML
    private void removeItem(HBox existing) {
        transactionList.getChildren().remove(existing);      
        updateGrandTotal();
    }

    @FXML
    private void deductItem(HBox existing, Double itemPrice, Label qtyLabel, Label priceLabel) {
        if(existing == null) return; 
           
        int currentQty = Integer.parseInt(qtyLabel.getText());

        if(currentQty <= 1) {
            transactionList.getChildren().remove(existing);
            return;
        }

        int deductedQty = currentQty - 1;
        qtyLabel.setText(String.valueOf(deductedQty));            
        priceLabel.setText(String.format("₱%.2f", deductedQty * itemPrice));     
        updateGrandTotal();
    }
  
    @FXML
    private void updateGrandTotal() {
        double subtotal = 0.0;
        double totalDue = 0.0; 

        for (Node node : transactionList.getChildren()) {
            if (node instanceof HBox row) {
                Label priceLabel = CashierHelper.getPriceLabel(row);
                Label typeLabel = CashierHelper.getCustomerLabel(row);

                double currentPrice = CashierHelper.parsePriceString(priceLabel.getText());
                String type = typeLabel.getText().toLowerCase();

                totalDue += currentPrice;

               
                switch(type) {
                    case "sc/pwd" -> subtotal += (currentPrice / 0.80) * 1.12;
                    default -> subtotal += currentPrice;
                }
            }
        }
        subTotalLabel.setText(String.format("SUB TOTAL : ₱%.2f", subtotal));
        totalDueLabel.setText(String.format("TOTAL DUE : ₱%.2f", totalDue));
    }

    @FXML
    private void addItemToTransaction(int itemID, String chosenItem, Double itemPrice, String customerType) {   
        HBox newRow = new HBox();         
        
        Button addQuantity = new Button("+");       
        Button deductQuantity = new Button("-");       
        Button deleteItem = new Button("DELETE");           
        HBox quantityModifier = new HBox();       
        
        Label quantityLabel = new Label("1");
        String formattedItemID = String.format("ITEM-%03d", itemID);
        Label itemIDLabel = new Label(formattedItemID);            
        Label itemLabel = new Label(chosenItem);            
        Label priceLabel = new Label(String.format("₱%.2f", itemPrice));
        Label customerTypeLabel = new Label(customerType.toUpperCase());
        
        addQuantity.setOnAction(e -> {incrementItem(itemPrice, quantityLabel, priceLabel);});
        deductQuantity.setOnAction(e -> {deductItem(newRow, itemPrice, quantityLabel, priceLabel);});
        deleteItem.setOnAction(e -> {removeItem(newRow);});
        
        CashierHelper.setTransactionLabelsCss(
                quantityModifier, 
                addQuantity,
                deductQuantity,
                deleteItem,
                quantityLabel, 
                itemIDLabel, 
                itemLabel, 
                priceLabel, 
                customerTypeLabel,                                          
                refQuantityModifier, 
                refAddQuantity,
                refDeductQuantity,
                refDeleteItem,
                refQuantity, 
                refItemID, 
                refItem, 
                refPrice, 
                refCustomerType);    
        
        newRow.setPrefSize(transactionLine.getPrefWidth(), transactionLine.getPrefHeight());
        newRow.setMinHeight(transactionLine.getMinHeight());
        
        quantityModifier.getChildren().addAll(addQuantity, deductQuantity, deleteItem);
        newRow.getChildren().addAll(
                quantityModifier, 
                quantityLabel, 
                itemIDLabel, 
                itemLabel, 
                priceLabel, 
                customerTypeLabel);
        transactionList.getChildren().add(newRow);
    }
    
    @FXML
    private void incrementItem(Double itemPrice, Label qtyLabel, Label priceLabel) {
        int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
        qtyLabel.setText(String.valueOf(newQty));
        priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
        updateGrandTotal();
    }
    
    @FXML 
    public void displayName(String username) {
        cashierUser.setText("CASHIER : " + username);
    }
    
    public void displayClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            String CURRENT_TIME = DateTimeUtils.getCurrentTime();
             timeDisplay.setText(CURRENT_TIME); 
        }),
        new KeyFrame(Duration.seconds(1))
    );    
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelReportSubmission() {
        ReceiptService.deleteAndResetReceipt(ReceiptService.getReceiptID());
        posBody.setMouseTransparent(false);
        receiptBodyDisplay.clear();
        receiptPopUp.setVisible(false);
        receiptPopUp.setManaged(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void submitReport() {
        receiptBodyDisplay.clear();
        transactionList.getChildren().clear();
        paymentField.setText(null);
        updateGrandTotal();
        
        String formattedTotalDue = String.format("%.2f", totalDueReceipt);
        double finalFormatTotalDue = Double.parseDouble(formattedTotalDue);
        
        ReceiptService.deleteAndResetReceipt(ReceiptService.getReceiptID());
        ReceiptService.saveReceipt(finalFormatTotalDue);
        posBody.setMouseTransparent(false);
        
        receiptPopUp.setVisible(false);
        receiptPopUp.setManaged(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void printReceipt() {
        javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();

        if (job != null) {
            // 1. Get the current window (required to center the dialog)
            javafx.stage.Window owner = receiptBodyDisplay.getScene().getWindow();

            // 2. Show the print dialog and check if the user clicked "Print"
            boolean proceed = job.showPrintDialog(owner);

            if (proceed) {
                javafx.print.PageLayout pageLayout = job.getPrinter().createPageLayout(
                    javafx.print.Paper.A4, 
                    javafx.print.PageOrientation.PORTRAIT, 
                    0, 0, 55, 0 
                );

                javafx.scene.text.Text printableText = new javafx.scene.text.Text(receiptBodyDisplay.getText());
                printableText.setFont(javafx.scene.text.Font.font("Courier New", 9));
                printableText.setWrappingWidth(210); 

                if (job.printPage(pageLayout, printableText)) {
                    job.endJob();
                }
            }
        }
    }

    @SuppressWarnings("unused")
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/goat/project/system/view/loginPane.fxml"));     
            Parent root = loader.load();
            
            Stage newStage = new Stage();

            Scene scene = new Scene(root);
            newStage.setScene(scene);
            
            Image iconImage = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
            newStage.getIcons().add(iconImage);
            newStage.setTitle("Sales and Records Management System");

            newStage.setResizable(true);
            newStage.setMaximized(false);

            newStage.initStyle(StageStyle.TRANSPARENT);
            scene.setFill(Color.TRANSPARENT);

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            System.err.println("Error loading login screen: " + e.getMessage());
        }
    }
}