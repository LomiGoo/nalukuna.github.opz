package com.goat.project.system.utility;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierControllerHelper {
    public void applyCategoryCssProperty(Label label, Label referencedLabel) {
        label.getStyleClass().addAll(referencedLabel.getStyleClass());
        label.setStyle(referencedLabel.getStyle());
        label.setFont(referencedLabel.getFont());
        label.setPrefSize(referencedLabel.getPrefWidth(), referencedLabel.getPrefHeight());
        label.setMinSize(referencedLabel.getMinWidth(), referencedLabel.getMinHeight());
        label.setPadding(referencedLabel.getPadding());
        VBox.setMargin(label, VBox.getMargin(referencedLabel));
    }
    
    public void applyItemListCssProperty(Label label1, Label label2, Label referencedLabel1, Label referencedLabel2) {
        label1.setFont(new Font(17));
        label1.setStyle(referencedLabel1.getStyle());
        label1.setPrefSize(referencedLabel1.getPrefWidth(), referencedLabel1.getPrefHeight());
        label1.setPadding(referencedLabel1.getPadding());
        VBox.setMargin(label1, new Insets(15, 0, 0, 0));
        label1.setWrapText(true);
        
       
        label2.setFont(new Font(15));
        label2.setStyle(referencedLabel2.getStyle());
        label2.setPrefSize(referencedLabel2.getPrefWidth(), referencedLabel2.getPrefHeight());
        VBox.setMargin(label2, new Insets(15, 0, 0, 0));
        label2.setPadding(referencedLabel2.getPadding());
    }
    
    public void applyTransactionCssProperty(Label label1, Label label2, Label label3, Label label4, Label referencedLabel1, Label referencedLabel2, Label referencedLabel3, Label referencedLabel4) {
        label1.setFont(new Font(20));
        label1.setStyle(referencedLabel1.getStyle());
        label1.setPrefSize(referencedLabel1.getPrefWidth(), referencedLabel1.getPrefHeight());
        label1.setWrapText(true);
        HBox.setMargin(label1, new Insets(0, 96, 0, 0));
        
        label2.setFont(new Font(20));
        label2.setStyle(referencedLabel2.getStyle());
        label2.setPrefSize(referencedLabel2.getPrefWidth(), referencedLabel2.getPrefHeight());
        label2.setWrapText(true);
        HBox.setMargin(label2, new Insets(0, 45, 0, 0));
        
        label3.setFont(new Font(20));
        label3.setStyle(referencedLabel3.getStyle());
        label3.setPrefSize(referencedLabel3.getPrefWidth(), referencedLabel3.getPrefHeight());
        label3.setWrapText(true);
        HBox.setMargin(label3, new Insets(0, 65, 0, 0));
        
        label4.setFont(new Font(20));
        label4.setStyle(referencedLabel4.getStyle());
        label4.setPrefSize(referencedLabel4.getPrefWidth(), referencedLabel4.getPrefHeight());
        label4.setWrapText(true);
        HBox.setMargin(label4, new Insets(0, 0, 0, 0));
    }
}
