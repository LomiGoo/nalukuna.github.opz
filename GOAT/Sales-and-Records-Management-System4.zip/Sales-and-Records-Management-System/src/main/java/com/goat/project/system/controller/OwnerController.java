package com.goat.project.system.controller;

public class OwnerController {
    
}
