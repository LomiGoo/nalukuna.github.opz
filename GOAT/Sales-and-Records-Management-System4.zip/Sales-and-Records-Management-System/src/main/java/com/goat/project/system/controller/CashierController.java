package com.goat.project.system.controller;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.model.Transaction;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.TransactionService;
import com.goat.project.system.utility.CashierControllerHelper;
import java.math.BigInteger;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierController {
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label categoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label item, price;
    @FXML
    private VBox itemFrame;
    @FXML
    private FlowPane itemContainer;
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label transactQuantity, transactItemID, transactItem, transactPrice;
    @FXML
    private HBox transactionLine;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        loadAllCategories();
    }
    
    @FXML
    private void createCategory(Long categoryCount, Category category) {         
        Label newCategory = new Label(categoryCount + ". " + category);

        newCategory.setOnMouseClicked(e -> {
            chooseCategory(category);
        });
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();      
        cashierControllerHelper.applyCategoryCssProperty(newCategory, categoryChoice);

        categoryContainer.getChildren().add(newCategory);
    }
    
    @FXML
    private void loadAllCategories() {
        CategoryService categoryService = new CategoryService();
        categoryContainer.getChildren().clear();
        
        long categoryCount = 1;
        for (Category category : categoryService.getCategoryRepo().getCategoryList()) {
            createCategory(categoryCount, category);   
            categoryCount++;
        }
    }
    
    @FXML
    private void chooseCategory(Category chosenCategory) {      
        loadAllItemList(chosenCategory);
    }
    
    int marginStop = 0;
    @FXML
    private void createItemList(BigInteger itemCount, String newItem, Double newPrice, String category, Category chosenCategory) {            
        VBox newItemContainer = new VBox();
        
        newItemContainer.setOnMouseClicked(e -> {
            chooseItemList(itemCount, newItem, newPrice, category);
        });
        
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
   
        if(marginStop == 1) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 0));
        if(marginStop == 0) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 10));
        marginStop++;
        if(marginStop == 6) marginStop = 0;
        
        Label newItemName = new Label(newItem);
        Label newItemPrice = new Label("₱" + newPrice);
        
        CashierControllerHelper cashierControllerHelper = new CashierControllerHelper();
        cashierControllerHelper.applyItemListCssProperty(newItemName, newItemPrice, item, price);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(newItemName, newItemPrice);     
    }
    
    @FXML
    private void loadAllItemList(Category chosenCategory) {
    ItemListService itemListService = new ItemListService();
    
    itemContainer.getChildren().clear();
    marginStop = 0;

        for (ItemList items : itemListService.getItemListRepo().getItemList()) {       
            createItemList(items.getItemIndex(), items.getItemName(), items.getItemPrice(), items.getCategory(), chosenCategory);            
        }
    }
   
    private static int quantityIncrement = 0;
    private static long itemIDIncrement = 0;
    @FXML
    private void chooseItemList(BigInteger itemCount, String newItem, Double newPrice, String category) {
        quantityIncrement++;
        createTransaction(itemCount, newItem, newPrice, category, quantityIncrement, itemIDIncrement);
        quantityIncrement--;
    }
    
    @FXML
    private void createTransaction(BigInteger itemCount, String newItem, Double newPrice, String category, int quantity, long newItemID) {      
        HBox newRow = new HBox(); 

        Transaction transaction = new Transaction(quantity, newItemID, newItem, newPrice);

        Label newQuantityLabel = new Label(String.valueOf(transaction.getQuantity()));
        Label newItemIDLabel = new Label(String.valueOf(transaction.getItemID()));
        Label newItemLabel = new Label(transaction.getItem());
        Label newPriceLabel = new Label(String.format("₱%.2f", transaction.getPrice()));

        CashierControllerHelper helper = new CashierControllerHelper();
        helper.applyTransactionCssProperty(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel, 
                                         transactQuantity, transactItemID, transactItem, transactPrice);

        newRow.getChildren().addAll(newQuantityLabel, newItemIDLabel, newItemLabel, newPriceLabel);

        transactionLine.getChildren().add(newRow);

        TransactionService transactionService = new TransactionService();
        transactionService.setTransaction(quantity, newItemID, newItem, newPrice);
    }
}
