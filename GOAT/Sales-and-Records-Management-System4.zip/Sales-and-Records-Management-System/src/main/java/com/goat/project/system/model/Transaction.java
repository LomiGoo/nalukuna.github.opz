package com.goat.project.system.model;

public class Transaction {
    private final Integer quantity;
    private final long itemID;
    private final String item;
    private final Double price;

    public Transaction(Integer quantity, long itemID, String item, Double price) {
        this.quantity = quantity;
        this.itemID = itemID;
        this.item = item;
        this.price = price;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public long getItemID() {
        return itemID;
    }

    public String getItem() {
        return item;
    }

    public Double getPrice() {
        return price;
    }
}
