package com.goat.project.system.utility;

public class AuthenticationValidate {
    public boolean isInputEmpty(String username, String password) {
        if(username.trim().isEmpty()) return false;
        return !password.trim().isEmpty();
    }
   
}
