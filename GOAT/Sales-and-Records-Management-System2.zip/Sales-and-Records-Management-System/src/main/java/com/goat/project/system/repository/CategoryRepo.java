package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class CategoryRepo {
    
    private final ArrayList<String> categories = new ArrayList<>(
        List.of("Main Dish", "Drinks", "Fried")
    );

    public ArrayList<String> getCategories() {
        return categories;
    }

}
