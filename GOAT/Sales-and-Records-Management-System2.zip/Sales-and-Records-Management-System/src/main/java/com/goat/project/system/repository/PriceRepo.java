package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class PriceRepo {
    private final ArrayList<String> price = new ArrayList<>(
            List.of("₱400.00")
    );

    public ArrayList<String> getPrice() {
        return price;
    }
        
}
