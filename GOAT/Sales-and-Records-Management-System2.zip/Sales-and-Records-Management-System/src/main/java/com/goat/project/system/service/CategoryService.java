package com.goat.project.system.service;
import com.goat.project.system.repository.CategoryRepo;

public class CategoryService {
    private final CategoryRepo repo = new CategoryRepo();

    public CategoryRepo getRepo() {
        return repo;
    }  
}
