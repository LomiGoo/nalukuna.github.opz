package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class ItemPriceRepo {
    private final ArrayList<String> itemPrice = new ArrayList<>(
            List.of("₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00, "₱" + 30.00)
    );

    public ArrayList<String> getItemPrice() {
        return itemPrice;
    }
       
}
