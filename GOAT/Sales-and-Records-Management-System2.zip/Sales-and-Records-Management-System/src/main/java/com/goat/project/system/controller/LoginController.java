package com.goat.project.system.controller;

import com.goat.project.system.service.UserService;
import com.goat.project.system.utility.AuthenticationValidate;
import com.goat.project.system.utility.FxmlHelper;
import java.io.IOException;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

public class LoginController {
   
    @FXML
    private TextField usernameField, shownPasswordField;
    @FXML
    private PasswordField passwordField;

    @FXML
    private CheckBox showPassword;
    
    @FXML
    private ToggleGroup roleGroup;
    
    @FXML
    private Label notificationError, notificationAttempts;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
        passwordField.textProperty().bindBidirectional(shownPasswordField.textProperty());
        showPassword.setOnAction(e -> {
            if(showPassword.isSelected()) {    
                shownPasswordField.setText(passwordField.getText());
                shownPasswordField.setVisible(true);
                passwordField.setVisible(false);
            } else {
                passwordField.setText(shownPasswordField.getText());
                passwordField.setVisible(true);
                shownPasswordField.setVisible(false);
            }
        });
        
    }
    
    int attempts = 3;
    @SuppressWarnings("unused")
    @FXML
    private void checkCredentials(ActionEvent loginButtonActionEvent) throws IOException {      
        UserService authValidate = new UserService();
        AuthenticationValidate validate = new AuthenticationValidate();
        FxmlHelper fxmlHelper = new FxmlHelper();
        
        String username = usernameField.getText();
        String password = passwordField.getText();
        Toggle selectedToggle = roleGroup.getSelectedToggle();
        
        if(selectedToggle == null) return;
        validate.isInputEmpty(username, password);

        RadioButton radioSelected = (RadioButton) roleGroup.getSelectedToggle();
        String selectedRole = radioSelected.getText();
        
        if(!authValidate.AuthenticateLogIn(username, password, selectedRole, loginButtonActionEvent)) {
            notificationError.setVisible(true);
            notificationError.setText("Note : User Not Found, Please Try Again");
            notificationAttempts.setVisible(true);
            notificationAttempts.setText("Attempts Left : " + --attempts); 

            if(attempts == 0) {
                attempts = 3;
                handleExit();
            }
        } else {
            switch(selectedRole) {
                case "Admin" :
                        fxmlHelper.switchInterface(loginButtonActionEvent,
                                "/com/goat/project/system/ui/owner_dashboard.fxml",
                                "/com/goat/project/system/css/owner_dashboard.css");
                    break;

                case "Cashier" :
                        fxmlHelper.switchInterface(loginButtonActionEvent,
                                "/com/goat/project/system/ui/cashier.fxml",
                                "/com/goat/project/system/css/cashier.css");
                    break;

                default :
                    System.out.println("No such Role Exists.");
                    break;
            }
        }
    }
    
    public void handleExit() {
        Platform.exit();
    }
}
