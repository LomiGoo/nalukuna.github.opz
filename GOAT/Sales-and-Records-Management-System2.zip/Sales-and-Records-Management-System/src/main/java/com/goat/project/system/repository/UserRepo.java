package com.goat.project.system.repository;
import com.goat.project.system.model.Users;

import java.util.ArrayList;

public class UserRepo {
    
    private final ArrayList<Users> user;
    
    public UserRepo() {
        user = new ArrayList<>();
        
        user.add(new Users("Cashier", "Cashier123", "Cashier"));
        user.add(new Users("Admin", "Admin123", "Admin"));
    }

    public ArrayList<Users> getUserList() {
        return user;
    }
  
}
