package com.goat.project.system.service;

import com.goat.project.system.model.Users;
import com.goat.project.system.repository.UserRepo;
import com.goat.project.system.utility.AuthenticationValidate;

import java.io.IOException;
import java.util.List;
import javafx.event.ActionEvent;


public class UserService {
    private final UserRepo repo = new UserRepo();

    public UserRepo getUserRepo() {
        return repo;
    }
      
    public boolean AuthenticateLogIn(String username, String password, String selectedRole, ActionEvent loginButtonEvent) throws IOException {
        List<Users> userList = getUserRepo().getUserList();
                
        for(Users account : userList) {
            boolean isCredentialsMatched = account.matches(username, password, selectedRole);  
            
            if(isCredentialsMatched) return true;
        }
        return false;
    }
}
