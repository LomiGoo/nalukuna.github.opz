package com.goat.project.system.repository;

import java.util.ArrayList;
import java.util.List;

public class ItemRepo {
    private final ArrayList<String> item = new ArrayList<>(
            List.of("BaconSilog")
    );

    public ArrayList<String> getItem() {
        return item;
    }
        
}
