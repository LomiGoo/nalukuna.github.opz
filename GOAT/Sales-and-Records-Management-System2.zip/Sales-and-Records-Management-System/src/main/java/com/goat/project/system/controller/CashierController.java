package com.goat.project.system.controller;

import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.TransactionService;

import java.util.ArrayList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierController {
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label categoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label item, price;
    @FXML
    private VBox itemFrame;
    @FXML
    private FlowPane itemContainer;
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label transactQuantity, transactItemID, transactItem, transactPrice;
    @FXML
    private HBox transactionLine;
  
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
  
        displayCategories();
        displayItemList();
        displayTransaction();
     
    }
    
    @FXML
    private void displayCategories() {
        CategoryService categoryService = new CategoryService();

        int count = 1;
        
        categoryChoice.setVisible(false);
        categoryChoice.setManaged(false);
        
        for(String categ : categoryService.getRepo().getCategories()) {
            Label newCategory = new Label(count + ". " + categ);
            
            newCategory.getStyleClass().addAll(categoryChoice.getStyleClass());
            
            newCategory.setStyle(categoryChoice.getStyle());
            newCategory.setFont(categoryChoice.getFont());
            newCategory.setPrefSize(categoryChoice.getPrefWidth(), categoryChoice.getPrefHeight());
            newCategory.setMinSize(categoryChoice.getMinWidth(), categoryChoice.getMinHeight());
            VBox.setMargin(newCategory, new Insets(30, 10, 0, 10));
 
            categoryContainer.getChildren().add(newCategory);
            count++;
            
        }
    }
    
    int marginStop = 0;
    @FXML
    private void displayItemList(String newItem, String newPrice) {
        
        itemFrame.setVisible(false);
        itemFrame.setManaged(false);
        
        VBox newItemContainer = new VBox();
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
   
        if(marginStop == 1) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 0));
        if(marginStop == 0) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 10));
        marginStop++;
        if(marginStop == 6) marginStop = 0;
        
        Label newItemName = new Label(newItem);
        Label newItemPrice = new Label(newPrice);
        
        newItemName.setFont(new Font(17));
        newItemName.setStyle(item.getStyle());
        newItemName.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItemName.setPadding(item.getPadding());
        VBox.setMargin(newItemName, new Insets(15, 0, 0, 0));
        newItemName.setWrapText(true);
        
       
        newItemPrice.setFont(new Font(15));
        newItemPrice.setStyle(price.getStyle());
        newItemPrice.setPrefSize(price.getPrefWidth(), price.getPrefHeight());
        VBox.setMargin(newItemPrice, new Insets(15, 0, 0, 0));
        newItemPrice.setPadding(price.getPadding());
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(newItemName, newItemPrice);
        
    }
    
    @FXML
    private void displayItemList() {
        ItemListService itemService = new ItemListService();
        
        for(int i = 0; i < itemService.getRepoName().getItemName().size(); i++) {
            
            String itemIndex = itemService.getRepoName().getItemName().get(i);
            String priceIndex = itemService.getRepoPrice().getItemPrice().get(i);
            
            displayItemList(itemIndex, priceIndex);
            
        }
    }
   
    @FXML
    private void displayTransaction() {
        
        transactQuantity.setVisible(false);
        transactQuantity.setManaged(false);
        transactItemID.setVisible(false);
        transactItemID.setManaged(false);
        transactItem.setVisible(false);
        transactItem.setManaged(false);
        transactPrice.setVisible(false);
        transactPrice.setManaged(false);
        
        TransactionService transactService = new TransactionService();
        
        String quantityIndex = transactService.getRepoQTY().getQuantityList().get(0);
        String itemIDIndex = transactService.getRepoItemID().getItemID().get(0);
        String itemIndex = transactService.getRepoItem().getItem().get(0);
        String priceIndex = transactService.getRepoPrice().getPrice().get(0);
        
        Label newQuantity = new Label(quantityIndex);
        Label newItemID = new Label(itemIDIndex);
        Label newItem = new Label(itemIndex);
        Label newPrice = new Label(priceIndex);
        
        newQuantity.setFont(new Font(20));
        newQuantity.setStyle(item.getStyle());
        newQuantity.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newQuantity.setWrapText(true);
        HBox.setMargin(newQuantity, new Insets(0, 96, 0, 0));
        
        newItemID.setFont(new Font(20));
        newItemID.setStyle(item.getStyle());
        newItemID.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItemID.setWrapText(true);
        HBox.setMargin(newItemID, new Insets(0, 45, 0, 0));
        
        newItem.setFont(new Font(20));
        newItem.setStyle(item.getStyle());
        newItem.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItem.setWrapText(true);
        HBox.setMargin(newItem, new Insets(0, 65, 0, 0));
        
        newPrice.setFont(new Font(20));
        newPrice.setStyle(item.getStyle());
        newPrice.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newPrice.setWrapText(true);
        HBox.setMargin(newPrice, new Insets(0, 0, 0, 0));
        
        transactionLine.getChildren().addAll(newQuantity, newItemID, newItem, newPrice);
    }
}
