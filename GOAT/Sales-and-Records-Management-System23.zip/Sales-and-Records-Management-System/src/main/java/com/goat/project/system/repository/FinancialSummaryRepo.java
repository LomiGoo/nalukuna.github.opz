package com.goat.project.system.repository;

import com.goat.project.system.model.FinancialSummary;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class FinancialSummaryRepo {
    public static FinancialSummary getYearSummary(int year) {
        String readSql = "SELECT sales, expenses, profit FROM year_summary WHERE year = ?";
        
        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtRead = conn.prepareStatement(readSql)) {
            
            pstmtRead.setInt(1, year);
            ResultSet rs = pstmtRead.executeQuery();
            
            if(rs.next()) {
                return new FinancialSummary(
                    rs.getDouble("sales"),
                    rs.getDouble("expenses"),
                    rs.getDouble("profit")
                );
            }
            
        } catch(SQLException e) {
             System.out.println("Failed to get Year Summary :" + e);
        }
        return null;
    }
    
    public static void summarizeYearData(int year) {
        String selectSql = "SELECT " 
                         + "(SELECT SUM(sales) FROM receipt WHERE date LIKE ?) AS total_sales, " 
                         + "(SELECT SUM(r.quantity * i.expenses) "
                         + " FROM receipt r "
                         + " JOIN item_list i ON r.receipt_id = i.item_id" 
                         + " WHERE r.date LIKE ?) AS total_expenses";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtSelect = conn.prepareStatement(selectSql)) {

            pstmtSelect.setString(1, "%_" + year);
            pstmtSelect.setString(2, "%_" + year);
            
            ResultSet rs = pstmtSelect.executeQuery();
            if (rs.next()) {
                double sales = rs.getDouble("total_sales");
                double expenses = rs.getDouble("total_expenses");
                double profit = sales - expenses;
                addYearData(year, sales, expenses, profit);
            }           
        } catch(SQLException e) {
            System.out.println("Failed to Summarize Year Data :" + e);
        }
    }

    public static void addYearData(int year, double sales, double expenses, double profit) {
        String insertSql = "INSERT INTO year_summary(year, sales, expenses, profit) VALUES(?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtInsert = conn.prepareStatement(insertSql)) {

                pstmtInsert.setInt(1, year);
                pstmtInsert.setDouble(2, sales);
                pstmtInsert.setDouble(3, expenses);
                pstmtInsert.setDouble(4, profit);

                pstmtInsert.executeUpdate(); 
                System.out.println("Data saved successfully!");
        } catch(SQLException e) {
            System.out.println("Failed to Add Year Data :" + e);        
        }
    }
    
    public static void deleteYearData() {
        String sql = "DELETE FROM year_summary";

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) System.out.println("A Year Data was deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting Year Data : " + e.getMessage());
        }
    }
    
    public static FinancialSummary getMonthSummary(int year, String month) {
        String readSql = "SELECT sales, expenses, profit FROM month_summary WHERE year = ? AND month = ?";
        
        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtRead = conn.prepareStatement(readSql)) {
            
            pstmtRead.setInt(1, year);
            pstmtRead.setString(2, month);
            ResultSet rs = pstmtRead.executeQuery();
            
            if(rs.next()) {
                return new FinancialSummary(
                    rs.getDouble("sales"),
                    rs.getDouble("expenses"),
                    rs.getDouble("profit")
                );
            }
            
        } catch(SQLException e) {
             System.out.println("Failed to get Month Summary :" + e);
        }
        return null;
    }
    
    public static void summarizeMonthData(int year, String month) {
        String selectSql = "SELECT " 
                         + "(SELECT SUM(sales) FROM receipt WHERE date LIKE ?) AS total_sales, " 
                         + "(SELECT SUM(expenses) FROM item_list) AS total_expenses";

        try(Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtSelect = conn.prepareStatement(selectSql)) {

            pstmtSelect.setString(1, month + "%_" + year);

            ResultSet rs = pstmtSelect.executeQuery();
            if (rs.next()) {
                double sales = rs.getDouble("total_sales");
                double expenses = rs.getDouble("total_expenses");
                double profit = sales - expenses;
                addMonthData(year, month, sales, expenses, profit);
            }           
        } catch(SQLException e) {
            System.out.println("Failed to Summarize Month Data :" + e);
        }
    }
    
    public static void addMonthData(int year, String month, double sales, double expenses, double profit) {
        String insertSql = "INSERT INTO month_summary(year, month, sales, expenses, profit) VALUES(?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmtInsert = conn.prepareStatement(insertSql)) {

                pstmtInsert.setInt(1, year);
                pstmtInsert.setString(2, month);
                pstmtInsert.setDouble(3, sales);
                pstmtInsert.setDouble(4, expenses);
                pstmtInsert.setDouble(5, profit);

                pstmtInsert.executeUpdate(); 
                System.out.println("Data saved successfully!");
        } catch(SQLException e) {
            System.out.println("Failed to Add Month Data :" + e);        
        }
    }
    
    public static void deleteMonthData() {
        String sql = "DELETE FROM month_summary";

        try (Connection conn = DatabaseConnection.getConnection();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) System.out.println("A Month Data was deleted successfully!");
        } catch (SQLException e) {
            System.out.println("Error deleting Month Data : " + e.getMessage());
        }
    }
}
