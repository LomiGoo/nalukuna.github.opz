package com.goat.project.system.service;

import com.goat.project.system.model.FinancialSummary;
import com.goat.project.system.repository.FinancialSummaryRepo;

public class FinancialSummaryService {
    public static FinancialSummary getYearSummary(int year) {
        return FinancialSummaryRepo.getYearSummary(year);
    }
    
    public static void summarizeYearData(int year) {
        FinancialSummaryRepo.summarizeYearData(year);
    }
    
    public static void deleteYearData() {
        FinancialSummaryRepo.deleteYearData();
    }
    
    public static FinancialSummary getMonthSummary(int year, String month) {
        return FinancialSummaryRepo.getMonthSummary(year, month);
    }
    
    public static void summarizeMonthData(int year, String month) {
        FinancialSummaryRepo.summarizeMonthData(year, month);
    }
      
    public static void deleteMonthData() {
        FinancialSummaryRepo.deleteMonthData();
    }
}
