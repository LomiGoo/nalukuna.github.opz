package com.goat.project.system.model;

public class Receipt {
    private int receiptID;
    private int userID;
    private String username;
    private double sales;
    private int quantity;
    private String time;
    private String date;
    
    public Receipt(int receiptID, int userID, String username, double sales, String time, String date) {
        this.receiptID = receiptID;
        this.userID = userID;
        this.username = username;
        this.sales = sales;
        this.time = time;
        this.date = date;
    }
    
    public Receipt(int userID, double sales, int quantity, String time, String date) {
        this.userID = userID;
        this.sales = sales;
        this.quantity = quantity;
        this.time = time;
        this.date = date;
    }

    public int getReceiptID() {
        return receiptID;
    }

    public int getUserID() {
        return userID;
    }

    public String getUsername() {
        return username;
    }
    
    public double getSales() {
        return sales;
    }

    public int getQuantity() {
        return quantity;
    }
    
    public String getTime() {
        return time;
    }

    public String getDate() {
        return date;
    }
}
