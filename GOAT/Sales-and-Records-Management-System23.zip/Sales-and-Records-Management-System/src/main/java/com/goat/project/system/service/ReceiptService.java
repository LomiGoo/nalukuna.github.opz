package com.goat.project.system.service;

import com.goat.project.system.model.Receipt;
import com.goat.project.system.repository.ReceiptRepo;
import com.goat.project.system.utility.DateTimeUtils;
import java.text.DecimalFormat;
import java.util.ArrayList;

public class ReceiptService {
    private static final DecimalFormat MONEY_FORMATTER = new DecimalFormat("#,##0.00");

    public static void saveReceipt(double totalDue, int quantity) {
        Receipt newReceipt = new Receipt(UserService.getUserID(), totalDue, quantity, DateTimeUtils.getCurrentTime(), DateTimeUtils.getFormattedDate());
        ReceiptRepo.addReceipt(newReceipt);
    }
    
    public ArrayList<Receipt> getReceipt() {
        return ReceiptRepo.readReceipt();
    }
    
    public static int getReceiptID() {
        return ReceiptRepo.getReceiptID();
    }
    
    public static void deleteAndResetReceipt(int receiptID) {
        ReceiptRepo.deleteAndResetReceipt(receiptID);
    }
   
    public static String moneyDecimalFormat(double amount) {
        return MONEY_FORMATTER.format(amount);
    }
    
}
