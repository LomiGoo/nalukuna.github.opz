package com.goat.project.system.repository;
import com.goat.project.system.model.User;
import com.goat.project.system.utility.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserRepo {    
    public static void addUser() {
        String sql = "INSERT INTO user(username, password, role) "
                   + "VALUES(?, ?, ?)";
        
        try(Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, User.getUsername());
            pstmt.setString(2, User.getPassword());
            pstmt.setString(3, User.getRole());
            
            pstmt.executeUpdate();
            System.out.println("User added!");
            
        } catch(SQLException e) {
            System.err.println("Error adding User: " + e.getMessage());
        }
    }
        
    public static User getUserById(int userID, String username, String password) {
        String sql = "SELECT * FROM user "
                   + "WHERE user_id = ? AND username = ? AND password = ?";
        
        try(Connection conn = DatabaseConnection.getConnection();
             PreparedStatement statement = conn.prepareStatement(sql)) {
            
            statement.setInt(1, userID);
            statement.setString(2, username);
            statement.setString(3, password);
            ResultSet rs = statement.executeQuery();
            
            if(rs.next()) {
                return new User(
                    rs.getInt("user_id"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                );
            }
            
        } catch(SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        return null;
    }
}
