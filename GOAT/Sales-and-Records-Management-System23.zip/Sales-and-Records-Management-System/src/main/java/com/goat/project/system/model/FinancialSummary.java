package com.goat.project.system.model;

public class FinancialSummary {
    private int year;
    private int month;
    private double sales;
    private double expenses;
    private double profit;

    public FinancialSummary(double sales, double expenses, double profit) {
        this.sales = sales;
        this.expenses = expenses;
        this.profit = profit;
    }
    
    public FinancialSummary(int year, int month, double sales, double expenses, double profit) {
        this.year = year;
        this.month = month;
        this.sales = sales;
        this.expenses = expenses;
        this.profit = profit;
    }
    
    public FinancialSummary(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }

    public double getSales() {
        return sales;
    }

    public double getExpenses() {
        return expenses;
    }

    public double getProfit() {
        return profit;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public void setSales(double sales) {
        this.sales = sales;
    }

    public void setExpenses(double expenses) {
        this.expenses = expenses;
    }

    public void setProfit(double profit) {
        this.profit = profit;
    }
    
    
}
