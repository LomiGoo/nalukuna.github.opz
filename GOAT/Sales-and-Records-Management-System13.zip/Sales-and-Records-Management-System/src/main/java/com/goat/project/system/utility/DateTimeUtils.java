package com.goat.project.system.utility;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class DateTimeUtils {
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMMM dd, yyyy");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("h:mm:ss a");
    public static String CURRENT_TIME;
    
    public static String getFormattedDate() {
        return LocalDate.now().format(DATE_FORMATTER);
    }
    
    public static String getCurrentTime() {
        return LocalTime.now().format(TIME_FORMATTER);
    }
}

