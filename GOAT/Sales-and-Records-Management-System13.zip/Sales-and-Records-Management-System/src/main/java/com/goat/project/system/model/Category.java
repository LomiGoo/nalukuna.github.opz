package com.goat.project.system.model;

public class Category {
    private static int categoryID;
    private static String category;

    public Category(int categoryID, String categoryName) {
        Category.categoryID = categoryID;
        Category.category = categoryName;
    }
    
    public static int getCategoryID() {
        return categoryID;
    }
    
    public static String getCategory() {
        return category;
    }   
}
