package com.goat.project.system.model;

public class ItemList {
    private static int itemID;
    private static String category;
    private static String itemName;
    private static double price;
    
    public ItemList(int itemID, String category, String itemName, double price) {
        ItemList.itemID = itemID;
        ItemList.category = category;
        ItemList.itemName = itemName;
        ItemList.price = price;
    }

    public static int getItemID() {
        return itemID;
    }
    
    public static String getItemName() {
        return itemName;
    }

    public static double getPrice() {
        return price;
    }

    public static String getCategory() {
        return category;
    }  
}
