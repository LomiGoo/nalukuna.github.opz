package com.goat.project.system.controller;

import com.goat.project.system.model.ItemList;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.utility.CashierHelper;
import com.goat.project.system.utility.DateTimeUtils;

import java.util.ArrayList;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class CashierController {
    @FXML
    private Label cashierUser;
    @FXML
    private Label cashierDateDisplay;
    @FXML
    private Label cashierTimeDisplay;
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label refCategoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label refItemLabel, refPriceLabel;
    @FXML
    private VBox refItemFrame;
    @FXML
    private FlowPane itemContainer;
    
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label refTransactQuantity, refTransactItemID, refTransactItem, refTransactPrice;
    @FXML
    private HBox transactionLine;
    @FXML
    private VBox transactionList;
    @FXML
    private VBox receiptPopUp;
    @FXML
    private TextArea receiptBodyDisplay;
    
    @FXML
    private TextField paymentField;
    
    @FXML
    private RadioButton noActionRadio, deductItemRadio, removeItemRadio;
    @FXML
    private RadioButton legalDiscount, ownerDiscount;
   
    @FXML
    private Button clearTransactionButton, completeTransactionButton;
    
    @FXML
    private Label totalPrice;

    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        cashierDateDisplay.setText(DateTimeUtils.getFormattedDate());
        displayClock();
        
        displayCategory();
        transactionList.getChildren().clear();
        itemContainer.getChildren().clear();
        
        clearTransactionButton.setOnAction(e -> {
            transactionList.getChildren().clear();
            totalPrice.setText("TOTAL : ₱0.00");
        });
        
        receiptBodyDisplay.setStyle("-fx-font-family: 'monospace'; -fx-font-size: 11pt;");
        
        paymentField.textProperty().addListener((observable, oldValue, newValue) -> {
        if(!newValue.matches("\\d*")) {
            paymentField.setText(newValue.replaceAll("[^\\d]", ""));
        }
    });
        
        completeTransactionButton.setOnAction(e -> {
            if(!transactionList.getChildren().isEmpty()) {
                String cashierName = cashierUser.getText();
                String receiptContent = buildReceipt(cashierName);
                receiptBodyDisplay.setText(receiptContent);
                displayReceiptPopup();
            }
        });
    }
    
    private void displayReceiptPopup() {
        receiptPopUp.setVisible(true);
        receiptPopUp.setManaged(true);
    }
    
    private String buildReceipt(String cashierName) {
        StringBuilder receipt = new StringBuilder();
        double[] totals = receiptList(new StringBuilder());
        int qtyTotal = (int) totals[0];
        double subTotal = totals[1], discount = totals[2], vatSales = totals[3], 
               vatAmount = totals[4], vatExempt = totals[5], totalDue = totals[6];
        
        double[] payment = calculateCashPayment(totalDue);
        double cash = payment[0], change = payment[1];
        
        if(payment == null) return null;
        
        String headerName = String.format("%27s", "DIOSARAP TAPSIHAN\n");
        String headerLocation = String.format("%33s", "F.Victorino st. Villa Alfonso\n");
        String headerLocation2 = String.format("%28s", "Bambang, Pasig City\n");
        String headerOfficialReceipt = String.format("OR No   : 000001\n");
        String headerDate = "DATE    : FEB 7,2026\n";
        String headerTime = "TIME    : 12:00 PM\n";
        
        String bodyHeader = String.format("%1s %20s %10s\n", "ITEM", "QTY", "PRICE");
        String bodyItemTotal = "ITEM TOTAL : " + qtyTotal + "\n";

        String footSubTotal = String.format("%-20s %15.2f\n", "SUBTOTAL:", subTotal);
        String footDiscount = String.format("%-20s %15.2f\n", "DISCOUNT:", discount);
        String footVatable  = String.format("%-20s %15.2f\n", "VATABLE SALES:", vatSales);
        String footVatAmnt  = String.format("%-20s %15.2f\n", "VAT AMOUNT:", vatAmount);
        String footVatEx = String.format("%-20s %15.2f\n", "VAT EXEMPT:", vatExempt);
        String footTotal = String.format("%-20s %15.2f\n", "TOTAL DUE:", totalDue);
        String footCash = String.format("%-20s %15.2f\n", "CASH:", cash);
        String footChange = String.format("%-20s %15.2f\n", "CHANGE:", change);
        String footThanks = " THANK YOU FOR ORDERING! COME AGAIN\n";
        
        receipt.append("====================================\n");
        receipt.append(headerName);
        receipt.append(headerLocation);
        receipt.append(headerLocation2);
        receipt.append("====================================\n");
        ArrayList<String> wrappedName = wrapText(cashierName, 23);    
        receipt.append(String.format("%s\n", wrappedName.get(0)));
        for (int i = 1; i < wrappedName.size(); i++) {
            receipt.append(String.format("%-10s%s\n", "", wrappedName.get(i)));
        } 
        receipt.append(headerOfficialReceipt);
        receipt.append(headerDate);
        receipt.append(headerTime);
        receipt.append("====================================\n");
        receipt.append(bodyHeader);
        receipt.append("------------------------------------\n");
        receiptList(receipt);
        receipt.append("\n------------------------------------\n");
        receipt.append(bodyItemTotal);
        receipt.append("------------------------------------\n");
        receipt.append(footSubTotal);
        receipt.append(footDiscount);
        receipt.append("------------------------------------\n");
        receipt.append(footVatable);
        receipt.append(footVatAmnt);
        receipt.append(footVatEx);
        receipt.append("------------------------------------\n");
        receipt.append(footTotal);
        receipt.append(footCash);
        receipt.append(footChange);
        receipt.append("====================================\n");
        receipt.append(footThanks);
        receipt.append("====================================\n");
        
        return receipt.toString();
    }
    
    private double[] receiptList(StringBuilder receipt) {      
        double subTotal = 0, discountRate = 0, vatSales = 0, vatAmount = 0, vatExempt = 0, totalDue = 0;
        int totalQty = 0;
        
        for(Node node : transactionList.getChildren()) {
            HBox row = (HBox) node;
            
            String item = CashierHelper.getItemLabel(row).getText();
            String qty = CashierHelper.getQtyLabel(row).getText();
            int qytValue = CashierHelper.parseQtyString(qty);
            String price = CashierHelper.getPriceLabel(row).getText();
            double priceValue = CashierHelper.parsePriceString(price);
            
            subTotal += priceValue;
            totalQty += qytValue;
            
            ArrayList<String> wrappedName = wrapText(item, 18);
            receipt.append(String.format("%-18s %5s %10.2f\n", wrappedName.get(0), qty, priceValue));
            
            for(int i = 1; i < wrappedName.size(); i++) {
                receipt.append(String.format("%-18s %5s %10s\n", wrappedName.get(i), "", ""));
            }    
        }
        
        if(legalDiscount.isSelected()) {
            vatExempt = subTotal / 1.12; 
            discountRate = vatExempt * 0.20; 
            vatSales = 0;
            vatAmount = 0;
            totalDue = vatExempt - discountRate;
        } else if(ownerDiscount.isSelected()){
            discountRate = subTotal * 0.15;
            totalDue = subTotal - discountRate;
            vatSales = totalDue / 1.12;
            vatAmount = totalDue - vatSales;
            vatExempt = 0;
        } else {
            discountRate = 0;
            totalDue = subTotal;
            vatSales = totalDue / 1.12;
            vatAmount = totalDue - vatSales;
            vatExempt = 0;
        }
        
        return new double[]{(double) totalQty, subTotal, discountRate, vatSales, vatAmount, vatExempt, totalDue};
    }
    
    private ArrayList<String> wrapText(String text, int limit) {
        ArrayList<String> lines = new ArrayList<>();
        String cleanText = text.replace(",", "").trim(); 
        String[] words = cleanText.split(" ");
        StringBuilder currentLine = new StringBuilder();

        for (String word : words) {
            if (currentLine.length() + word.length() + 1 <= limit) {
                if (currentLine.length() > 0) currentLine.append(" ");
                currentLine.append(word);
            } else {
                lines.add(currentLine.toString());
                currentLine = new StringBuilder(word);
            }
        }
        if (currentLine.length() > 0) lines.add(currentLine.toString());
        return lines;
    }
    
    private double[] calculateCashPayment(double totalDue) {
        double cashPaid = 0;
        try {
            cashPaid = Double.parseDouble(paymentField.getText());
        } catch (NumberFormatException e) {}

        double change = cashPaid - totalDue;

        if (cashPaid < totalDue) {
            return null;
        }
        return new double[]{cashPaid, change};
    }

    public void createCategory(int categoryCount, String category) {         
        Label newCategory = new Label(categoryCount + ". " + category);
        newCategory.setOnMouseClicked(e -> chooseCategory(category));       
        CashierHelper.setCategoryLabelsCss(newCategory, refCategoryChoice);

        categoryContainer.getChildren().add(newCategory);        
    }
    
    @FXML
    private void displayCategory() {
        categoryContainer.getChildren().clear();
        int displayCount = 1;
        
        do {
            if(!CategoryService.findCategory(displayCount)) return;
                createCategory(displayCount, CategoryService.getCategory());
                displayCount++;
        } while(true);       
    }
    
    @FXML
    private void chooseCategory(String chosenCategory) {      
        displayItemLists(chosenCategory);
    }
    
    @FXML
    private void displayItemLists(String chosenCategory) {
        itemContainer.getChildren().clear();
        int displayCount = 1;
        
        do {
            if(!ItemListService.findItem(displayCount)) return;
            if(!ItemListService.getItemCategory().equals(chosenCategory)) {
                displayCount++;
                continue;
            }
            createItemList(displayCount, ItemList.getItemName(), ItemList.getPrice());
            displayCount++;
        } while(true);
    }
    
    @FXML
    private void createItemList(int itemID, String itemName, double price) {            
        VBox newItemContainer = new VBox();       
        newItemContainer.setOnMouseClicked(e -> chooseItemList(itemID, itemName, price, false));
        CashierHelper.setContainerCss(newItemContainer, refItemFrame);
        
        Label itemNameLabel = new Label(itemName);
        Label itemPriceLabel = new Label(String.format("₱%.2f", price));      
        CashierHelper.setItemLabelsCss(itemNameLabel, itemPriceLabel, refItemLabel, refPriceLabel);
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(itemNameLabel, itemPriceLabel);     
    }
        
    @FXML
    private void chooseItemList(int itemID, String chosenItem, Double itemPrice, boolean isInTransaction) {   
        HBox recordLineExistence = recordLineCheck(chosenItem);
        if(recordLineExistence == null) {
            addItemToTransaction(itemID, chosenItem, itemPrice);
            updateGrandTotal();
            return;
        }
        
        Label qtyLabel = CashierHelper.getQtyLabel(recordLineExistence);
        Label priceLabel = CashierHelper.getPriceLabel(recordLineExistence);
        
        if(!noActionRadio.isSelected() && isInTransaction) {
            removeItem(recordLineExistence);
            deductItem(recordLineExistence, itemPrice, qtyLabel, priceLabel);
            updateGrandTotal();
            return;
        }
        
        int newQty = Integer.parseInt(qtyLabel.getText()) + 1;
        qtyLabel.setText(String.valueOf(newQty));
        priceLabel.setText(String.format("₱%.2f", newQty * itemPrice));
        updateGrandTotal();
    }
    
    @FXML
    private HBox recordLineCheck(String chosenItem) {
        for(Node node : transactionList.getChildren()) {
            HBox row = (HBox) node;
            if(row.getChildren().size() != 4) continue;
            
            Label nameLabel = CashierHelper.getItemLabel(row);
            if(!nameLabel.getText().equals(chosenItem)) continue;  
            
            return row;
        }
        return null;
    }
    
    @FXML
    private void removeItem(HBox existing) {
        if(removeItemRadio.isSelected()) transactionList.getChildren().remove(existing);      
        updateGrandTotal();
    }

    @FXML
    private void deductItem(HBox existing, Double itemPrice, Label qtyLabel, Label priceLabel) {
        if(existing == null) return; 
        
        if(deductItemRadio.isSelected()) {         
            int currentQty = Integer.parseInt(qtyLabel.getText());
            
            if(currentQty <= 1) {
                transactionList.getChildren().remove(existing);
                return;
            }
            
            int deductedQty = currentQty - 1;
            qtyLabel.setText(String.valueOf(deductedQty));            
            priceLabel.setText(String.format("₱%.2f", deductedQty * itemPrice));                            
        }
    }
  
    @FXML
    private void updateGrandTotal() {
    double grandTotal = 0.0;
    for(Node node : transactionList.getChildren()) {
        HBox row = (HBox) node;
        
        Label priceLabel = CashierHelper.getPriceLabel(row);
        String priceText = priceLabel.getText();
        double convertedPrice = CashierHelper.parsePriceString(priceText);
        
        grandTotal += convertedPrice;
     }
    totalPrice.setText("TOTAL : " + String.format("₱%.2f", grandTotal));
}
    
    @FXML
    private void addItemToTransaction(int itemID, String chosenItem, Double itemPrice) {   
        HBox newRow = new HBox();         
        newRow.setOnMouseClicked(e -> {
            chooseItemList(itemID, chosenItem, itemPrice, true);
        });
        
        Label quantityLabel = new Label("1");
        String formattedItemID = String.format("ITEM-%03d", itemID);
        Label itemIDLabel = new Label(formattedItemID);            
        Label itemLabel = new Label(chosenItem);            
        Label priceLabel = new Label(String.format("₱%.2f", itemPrice));
        
        CashierHelper.setTransactionLabelsCss(quantityLabel, itemIDLabel, itemLabel, priceLabel, 
                                                    refTransactQuantity, refTransactItemID, refTransactItem, refTransactPrice);      
        newRow.setPrefSize(transactionLine.getPrefWidth(), transactionLine.getPrefHeight());
        newRow.setMinHeight(transactionLine.getMinHeight());
        
        newRow.getChildren().addAll(quantityLabel, itemIDLabel, itemLabel, priceLabel);
        transactionList.getChildren().add(newRow);
    }
    
    @FXML 
    public void displayName(String username) {
        cashierUser.setText("CASHIER : " + username);
    }
    
    public void displayClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            String CURRENT_TIME = DateTimeUtils.getCurrentTime();
             cashierTimeDisplay.setText(CURRENT_TIME); 
        }),
        new KeyFrame(Duration.seconds(1))
    );    
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelReportSubmission() {
        receiptBodyDisplay.clear();
        receiptPopUp.setVisible(false);
        receiptPopUp.setManaged(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void submitReport() {
        receiptBodyDisplay.clear();
        transactionList.getChildren().clear();
        paymentField.setText(null);
        updateGrandTotal();
        receiptPopUp.setVisible(false);
        receiptPopUp.setManaged(false);
    }
    
    @FXML
    private void printReceipt(ActionEvent e) {
        javafx.print.PrinterJob job = javafx.print.PrinterJob.createPrinterJob();

        if (job != null) {
            javafx.print.PageLayout pageLayout = job.getPrinter().createPageLayout(
                javafx.print.Paper.A4, 
                javafx.print.PageOrientation.PORTRAIT, 
                0, 0, 55, 0 
            );

            javafx.scene.text.Text printableText = new javafx.scene.text.Text(receiptBodyDisplay.getText());
            printableText.setFont(javafx.scene.text.Font.font("Courier New", 9));

            printableText.setWrappingWidth(210); 

            if (job.printPage(pageLayout, printableText)) {
                job.endJob();
            }
        }
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void handleExit() {
        Platform.exit();
    }
}