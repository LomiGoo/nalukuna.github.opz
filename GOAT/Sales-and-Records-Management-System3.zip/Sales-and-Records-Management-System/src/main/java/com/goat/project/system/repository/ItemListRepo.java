package com.goat.project.system.repository;

import com.goat.project.system.model.ItemList;
import java.math.BigInteger;
import java.util.ArrayList;

public class ItemListRepo {
    private final ArrayList<ItemList> itemList;
    
    public ItemListRepo() {
        itemList = new ArrayList<>();
        
        itemList.add(new ItemList(BigInteger.valueOf(1), "Tapsilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(2), "Chicksilog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(3), "Pork silog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(4), "Hungarian silog", 80.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(5), "Hot silog", 40.00, "Main Dish"));
        itemList.add(new ItemList(BigInteger.valueOf(1), "Coke", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(2), "Royal", 25.00, "Drinks"));
        itemList.add(new ItemList(BigInteger.valueOf(3), "Mineral Water", 12.00, "Drinks"));
    }

    public ArrayList<ItemList> getItemList() {
        return itemList;
    }
}
