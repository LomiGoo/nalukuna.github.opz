package com.goat.project.system.controller;

import com.goat.project.system.model.Category;
import com.goat.project.system.model.ItemList;
import com.goat.project.system.model.Transaction;
import com.goat.project.system.service.CategoryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.TransactionService;
import java.math.BigInteger;

import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;

public class CashierController {
    
    // =======================
    // Category Window
    // =======================
    @FXML
    private Label categoryChoice;  
    @FXML
    private VBox categoryContainer;

    // =======================
    // Item Window
    // =======================
    @FXML
    private Label item, price;
    @FXML
    private VBox itemFrame;
    @FXML
    private FlowPane itemContainer;
    
    // =======================
    // Transaction Window
    // =======================
    @FXML
    private Label transactQuantity, transactItemID, transactItem, transactPrice;
    @FXML
    private HBox transactionLine;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {  
        loadAllCategories();
    }
    
    @FXML
    private void createCategory(Long categoryCount, Category category) {         
        Label newCategory = new Label(categoryCount + ". " + category.getCategory());

        newCategory.setOnMouseClicked(e -> {
            chooseCategory(category);
        });
        
        newCategory.getStyleClass().addAll(categoryChoice.getStyleClass());
        newCategory.setStyle(categoryChoice.getStyle());
        newCategory.setFont(categoryChoice.getFont());
        newCategory.setPrefSize(categoryChoice.getPrefWidth(), categoryChoice.getPrefHeight());
        newCategory.setMinSize(categoryChoice.getMinWidth(), categoryChoice.getMinHeight());
        newCategory.setPadding(categoryChoice.getPadding());
        VBox.setMargin(newCategory, VBox.getMargin(categoryChoice));

        categoryContainer.getChildren().add(newCategory);
    }
    
    @FXML
    private void loadAllCategories() {
        CategoryService categoryService = new CategoryService();
        
        long categoryCount = 1;
        for (Category category : categoryService.getCategoryRepo().getCategoryList()) {
            createCategory(categoryCount, category);        
        }
    }
    
    @FXML
    private void chooseCategory(Category category) {      
        loadAllItemList(category);
    }
    
    int marginStop = 0;
    @FXML
    private void createItemList(BigInteger itemCount, String newItem, Double newPrice, String category) {            
        VBox newItemContainer = new VBox();
        
        newItemContainer.setOnMouseClicked(e -> {
            chooseItemList(itemCount, category);
        });
        
        newItemContainer.setStyle(itemFrame.getStyle());
        newItemContainer.setPrefSize(itemFrame.getPrefWidth(), itemFrame.getPrefHeight());
        newItemContainer.setPadding(itemFrame.getPadding());
        newItemContainer.setFillWidth(true);
   
        if(marginStop == 1) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 0));
        if(marginStop == 0) FlowPane.setMargin(newItemContainer, new Insets(0, 0, 0, 10));
        marginStop++;
        if(marginStop == 6) marginStop = 0;
        
        Label newItemName = new Label(newItem);
        Label newItemPrice = new Label("₱" + newPrice);
        
        newItemName.setFont(new Font(17));
        newItemName.setStyle(item.getStyle());
        newItemName.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItemName.setPadding(item.getPadding());
        VBox.setMargin(newItemName, new Insets(15, 0, 0, 0));
        newItemName.setWrapText(true);
        
       
        newItemPrice.setFont(new Font(15));
        newItemPrice.setStyle(price.getStyle());
        newItemPrice.setPrefSize(price.getPrefWidth(), price.getPrefHeight());
        VBox.setMargin(newItemPrice, new Insets(15, 0, 0, 0));
        newItemPrice.setPadding(price.getPadding());
        
        itemContainer.getChildren().addAll(newItemContainer);
        newItemContainer.getChildren().addAll(newItemName, newItemPrice);     
    }
    
    @FXML
    private void loadAllItemList(Category itemCategory) {
    ItemListService itemListService = new ItemListService();
    
    itemContainer.getChildren().clear();
    marginStop = 0;

        for (ItemList items : itemListService.getItemListRepo().getItemList()) {
            if (items.getCategory().equals(itemCategory.getCategory())) {
                createItemList(items.getItemCount(), items.getItemName(), items.getItemPrice(), items.getCategory());
            }  
        }
    }
   
    @FXML
    private void chooseItemList(BigInteger itemCount, String category) {
        
    }
    
    @FXML
    private void createTransaction() {      
        transactionLine.getChildren().clear();
        
        TransactionService transactService = new TransactionService();
        Transaction transaction = transactService.getTransactionRepo().getTransaction().get(0);
        Integer itemQuantityDisplsy = transaction.getQuantity();
        Long itemIDDisplsy = transaction.getItemID();
        String itemDisply = transaction.getItem();
        Double priceDisplay = transaction.getPrice();
                
        Label newQuantity = new Label(Integer.toString(itemQuantityDisplsy));
        Label newItemID = new Label(Long.toString(itemIDDisplsy));
        Label newItem = new Label(itemDisply);
        Label newPrice = new Label(Double.toString(priceDisplay));
        
        newQuantity.setFont(new Font(20));
        newQuantity.setStyle(item.getStyle());
        newQuantity.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newQuantity.setWrapText(true);
        HBox.setMargin(newQuantity, new Insets(0, 96, 0, 0));
        
        newItemID.setFont(new Font(20));
        newItemID.setStyle(item.getStyle());
        newItemID.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItemID.setWrapText(true);
        HBox.setMargin(newItemID, new Insets(0, 45, 0, 0));
        
        newItem.setFont(new Font(20));
        newItem.setStyle(item.getStyle());
        newItem.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newItem.setWrapText(true);
        HBox.setMargin(newItem, new Insets(0, 65, 0, 0));
        
        newPrice.setFont(new Font(20));
        newPrice.setStyle(item.getStyle());
        newPrice.setPrefSize(item.getPrefWidth(), item.getPrefHeight());
        newPrice.setWrapText(true);
        HBox.setMargin(newPrice, new Insets(0, 0, 0, 0));
        
        transactionLine.getChildren().addAll(newQuantity, newItemID, newItem, newPrice);
    }
}
