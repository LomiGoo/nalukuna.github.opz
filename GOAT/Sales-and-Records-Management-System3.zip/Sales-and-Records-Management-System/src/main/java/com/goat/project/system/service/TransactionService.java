package com.goat.project.system.service;

import com.goat.project.system.repository.TransactionRepo;

public class TransactionService {
    private final TransactionRepo transactionRepo = new TransactionRepo();

    public TransactionRepo getTransactionRepo() {
        return transactionRepo;
    }   
}
