package com.goat.project.system.model;

import java.math.BigInteger;

public class ItemList {
    private final BigInteger itemCount;
    private final String itemName;
    private final Double itemPrice;
    private final String category;
    
    public ItemList(BigInteger itemCount, String itemName, Double itemPrice, String category) {
        this.itemCount = itemCount;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.category = category;
    }

    public BigInteger getItemCount() {
        return itemCount;
    }
    
    public String getItemName() {
        return itemName;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public String getCategory() {
        return category;
    }  
}
