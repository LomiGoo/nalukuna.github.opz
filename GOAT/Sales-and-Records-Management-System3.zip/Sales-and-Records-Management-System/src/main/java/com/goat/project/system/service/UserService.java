package com.goat.project.system.service;

import com.goat.project.system.model.User;
import com.goat.project.system.repository.UserRepo;

import java.util.List;
import javafx.event.ActionEvent;


public class UserService {
    private final UserRepo userRepo = new UserRepo();

    public UserRepo getUserRepo() {
        return userRepo;
    }
      
    public boolean AuthenticateLogIn(String username, String password, String selectedRole, ActionEvent loginButtonEvent)  {
        List<User> userList = getUserRepo().getUserList();
                
        for(User account : userList) {
            boolean isCredentialsMatched = account.matches(username, password, selectedRole);  
            
            if(isCredentialsMatched) return true;
        }
        return false;
    }
}
