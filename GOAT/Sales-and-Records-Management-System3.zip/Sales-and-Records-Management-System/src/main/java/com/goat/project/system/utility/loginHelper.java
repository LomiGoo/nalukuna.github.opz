package com.goat.project.system.utility;

import java.io.IOException;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

public class loginHelper {
    public boolean isInputEmpty(String username, String password) {
        if(username.trim().isEmpty()) return false;
        return !password.trim().isEmpty();
    }
    
    static int attempts = 3;
    public void displayErrorNotification(Label notificationError, Label notificationAttempts) {     
        notificationError.setVisible(true);
        notificationError.setText("Note : User Not Found, Please Try Again");
        notificationAttempts.setVisible(true);
        notificationAttempts.setText("Attempts Left : " + --attempts); 

        if(attempts == 0) {
            Platform.exit();
        }
    }
    
    public void switchInterface(String selectedRole, ActionEvent loginButtonActionEvent) throws IOException {
        FxmlHelper fxmlHelper = new FxmlHelper();
        
        switch(selectedRole) {
                case "Admin" :
                        fxmlHelper.switchInterface(loginButtonActionEvent,
                                "/com/goat/project/system/ui/owner_dashboard.fxml",
                                "/com/goat/project/system/css/owner_dashboard.css");
                    break;

                case "Cashier" :
                        fxmlHelper.switchInterface(loginButtonActionEvent,
                                "/com/goat/project/system/ui/cashier.fxml",
                                "/com/goat/project/system/css/cashier.css");
                    break;

                default :
                    System.out.println("No such Role Exists.");
                    break;
            }
    }
}
