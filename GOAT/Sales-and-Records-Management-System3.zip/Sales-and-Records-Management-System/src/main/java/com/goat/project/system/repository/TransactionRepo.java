package com.goat.project.system.repository;

import com.goat.project.system.model.Transaction;
import java.util.ArrayList;

public class TransactionRepo {
    private final ArrayList<Transaction> transaction;

    public TransactionRepo() {
        transaction = new ArrayList<>();
        
        transaction.add(new Transaction(2, 1000, "Sisig", 20.00));
        transaction.add(new Transaction(4, 1000, "adobo", 60.00));
    }

    public ArrayList<Transaction> getTransaction() {
        return transaction;
    }
}
