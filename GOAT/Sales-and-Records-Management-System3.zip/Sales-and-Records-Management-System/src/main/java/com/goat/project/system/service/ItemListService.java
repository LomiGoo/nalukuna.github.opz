package com.goat.project.system.service;

import com.goat.project.system.repository.ItemListRepo;

public class ItemListService {
    private final ItemListRepo itemListRepo = new ItemListRepo();

    public ItemListRepo getItemListRepo() {
        return itemListRepo;
    }
}
