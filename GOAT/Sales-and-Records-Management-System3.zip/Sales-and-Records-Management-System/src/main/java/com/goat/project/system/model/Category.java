package com.goat.project.system.model;

public record Category (long categoryCount, String category) {
    public long getCategoryCount() {
        return categoryCount;
    }

    public String getCategory() {
        return category;
    }   
}
