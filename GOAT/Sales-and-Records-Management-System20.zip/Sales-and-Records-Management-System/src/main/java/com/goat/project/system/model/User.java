package com.goat.project.system.model;

public class User {
    private static int userID;
    private static String username;
    private static String password;
    private static String role;
    
    public User(int user_id, String username, String password, String role) {
        User.userID = user_id;
        User.username = username;
        User.password = password;
        User.role = role;
    }

    public static int getUserID() {
        return userID;
    }
    
    public static String getUsername() {
        return username;
    }
    
    public static String getPassword() {
        return password;
    }

    public static String getRole() {
        return role;
    }
   
    public void setUsername(String username) {
        User.username = username;
    }   
}
