package com.goat.project.system.controller;

import com.goat.project.system.model.Receipt;
import com.goat.project.system.repository.CategoryRepo;
import com.goat.project.system.service.FinancialSummaryService;
import com.goat.project.system.service.ItemListService;
import com.goat.project.system.service.ReceiptService;
import com.goat.project.system.service.UserService;
import com.goat.project.system.utility.CashierHelper;
import com.goat.project.system.utility.Charts;
import com.goat.project.system.utility.DateTimeUtils;
import java.io.IOException;
import java.util.Arrays;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.print.PrinterJob;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;


public class OwnerController {
    @FXML
    private Circle diosarapLogo;
    @FXML
    private Label usernameDisplay;
    @FXML
    private Label dateDisplay;
    @FXML
    private Label timeDisplay;
    @FXML
    private Label upperLabelTitle;
    
    @FXML
    private VBox sideBarMenu;
    
    @FXML
    private AnchorPane dashboardDisplay;
    @FXML
    private TextField searchYearField;
    @FXML
    private ChoiceBox<String> monthChoice;
    private final String months[] = {
        "January",
        "February",
        "March",
        "April",
        "May",
        "June",
        "July",
        "August",
        "September",
        "October",
        "November",
        "December"
    };
    @FXML
    private Label yearLabel, monthLabel, yearProfit, yearSales, yearExpenses, monthProfit, monthSales, monthExpenses;
    @FXML
    private BarChart<String, Number> yearlyBar, monthlyBar;
    
    @FXML
    private StackPane cashierManagementWindow;  
    @FXML
    private AnchorPane addCategoryWindow;
    @FXML
    private TextField addCategoryField;
    
    @FXML
    private AnchorPane addItemWindow;
    @FXML
    private TextField addItemField, addItemPriceField, addItemExpensesField;
    @FXML
    private ChoiceBox<String> categoryChoice;
    @FXML
    private AnchorPane updateItemWindow;
    @FXML
    private TextField updateItemField, updateItemPriceField, updateItemExpensesField, idField;
    @FXML
    private ChoiceBox<String> updateCategoryChoice;
    
    @FXML
    private StackPane systemManagamentWindow;
    @FXML
    private AnchorPane manageUsersWindow;
    @FXML
    private AnchorPane addUserWindow;
    @FXML
    private AnchorPane sessionLogWindow;
    
    @FXML
    private AnchorPane recentRecordsDisplay;
   
    @FXML
    private TextArea recentRecordsBody;
    
    String barType;
    
    @FXML
    @SuppressWarnings("unused")
    private void initialize() {
        Image img = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
        ImagePattern pattern = new ImagePattern(img);
        diosarapLogo.setFill(pattern);     
        
        usernameDisplay.setText("Welcome Admin " + UserService.getUsername() + "!");
        dateDisplay.setText(DateTimeUtils.getFormattedDate());
        displayClock();
        
        searchYearField.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.matches("\\d*")) searchYearField.setText(oldValue);
        });
        
        monthChoice.getItems().addAll(Arrays.asList(months));
        
        String date = DateTimeUtils.getFormattedDate();
        String year = date.split(" ")[2];
        String month = date.split(" ")[0];
        
        FinancialSummaryService.summarizeYearData(Integer.parseInt(year));    
        barType = "year";
        Charts yearSum = new Charts(barType, yearlyBar, yearLabel, yearProfit, yearSales, yearExpenses);
        yearSum.implementYearSum(2026);
        FinancialSummaryService.deleteYearData();
        
        FinancialSummaryService.summarizeMonthData(Integer.parseInt(year), month);    
        barType = "month";
        Charts monthSum = new Charts(barType, monthlyBar, monthLabel, monthProfit, monthSales, monthExpenses);
        monthSum.implementMonthSum(2026, month);
        FinancialSummaryService.deleteMonthData();
        
        addItemPriceField.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.matches("\\d*(\\.\\d*)?")) {
                addItemPriceField.setText(oldValue);
            }
        });
        
        addItemExpensesField.textProperty().addListener((observable, oldValue, newValue) -> {
            if(!newValue.matches("\\d*(\\.\\d*)?")) {
                addItemExpensesField.setText(oldValue);
            }
        });
        
        ItemListService.populateCategoryChoice(categoryChoice);
        ItemListService.populateCategoryChoice(updateCategoryChoice);
        categoryChoice.setStyle("-fx-font-size: 18px;");
        updateCategoryChoice.setStyle("-fx-font-size: 18px;");
        
        Platform.runLater(() -> {
            Node thumb = recentRecordsBody.lookup(".scroll-bar .thumb");
            if(thumb != null) {
                thumb.setStyle("-fx-background-color: #ff6f5a; -fx-background-radius: 5;");
            }

            Node track = recentRecordsBody.lookup(".scroll-bar .track");
            if(track != null) {
                track.setStyle("-fx-background-color: #303344; -fx-background-radius: 5;");
            }
            
            Node content = recentRecordsBody.lookup(".content");
            if(content != null) {
                content.setStyle("-fx-cursor: default;");
            }
        });
        
        recentRecordsBody.addEventFilter(MouseEvent.MOUSE_PRESSED, e -> {
            if(!e.getTarget().toString().contains("ScrollBar")) {
                recentRecordsBody.requestFocus(); // Keep focus if you want, or remove
            }
        });

        recentRecordsBody.addEventFilter(MouseEvent.MOUSE_DRAGGED, Event::consume);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void dashboard() {
        recentRecordsDisplay.setVisible(false);
        dashboardDisplay.setVisible(true);
        
        upperLabelTitle.setText("DASHBOARD");     
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showAddCategoryWindow() {
        cashierManagementWindow.setVisible(true);
        addCategoryWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void addCategory() {
        String newCategory = addCategoryField.getText();
        
        if(newCategory.isBlank()) return;
        CategoryRepo.addCategory(newCategory);  
        
        ItemListService.populateCategoryChoice(categoryChoice);
        addCategoryField.clear();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelAddCategory() {
        cashierManagementWindow.setVisible(false);
        addCategoryWindow.setVisible(false);
        sideBarMenu.setMouseTransparent(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showAddItemWindow() {
        cashierManagementWindow.setVisible(true);
        addItemWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void addItem() {
        String newItem = addItemField.getText();
        String newPrice = addItemPriceField.getText();
        String newExpenses = addItemExpensesField.getText();
        
        if(newItem.isBlank() && newPrice.isBlank() && newExpenses.isBlank()) return;
        if(categoryChoice.getValue() == null) return;
        
        int selectedCategory = categoryChoice.getSelectionModel().getSelectedIndex();

        selectedCategory++;
        ItemListService.addItem(selectedCategory, newItem, newPrice, newExpenses);  
    
        addItemField.clear();
        addItemPriceField.clear();
        addItemExpensesField.clear();

    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelAddItem() {
        cashierManagementWindow.setVisible(false);
        addItemWindow.setVisible(false);
       sideBarMenu.setMouseTransparent(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showUpdateItemWindow() {
        cashierManagementWindow.setVisible(true);
        updateItemWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void updateItem() {
        String updatedItem = updateItemField.getText();
        String updatedPrice = updateItemPriceField.getText();
        String updatedExpenses = updateItemExpensesField.getText();
        int itemID = Integer.parseInt(idField.getText());
        
        if(updatedItem.isBlank() && updatedPrice.isBlank() && updatedExpenses.isBlank() && itemID < 1 && updateCategoryChoice.getValue() == null) return;
        
        int selectedCategory = updateCategoryChoice.getSelectionModel().getSelectedIndex();

        selectedCategory++;
        ItemListService.updateItem(selectedCategory, updatedItem, itemID, updatedPrice, updatedExpenses);  
        
        updateItemField.clear();
        updateItemPriceField.clear();
        updateItemExpensesField.clear();
        idField.clear();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelUpdateItem() {
        cashierManagementWindow.setVisible(false);
        updateItemWindow.setVisible(false);
        sideBarMenu.setMouseTransparent(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showManageUsersWindow() {
        systemManagamentWindow.setVisible(true);
        manageUsersWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelManageUSersWindow() {
        systemManagamentWindow.setVisible(false);
        manageUsersWindow.setVisible(false);
        sideBarMenu.setMouseTransparent(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showAddUserWindow() {
        addUserWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void canceAddUserWindow() {
        addUserWindow.setVisible(false);
        sideBarMenu.setMouseTransparent(false);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void showSessionLogWindow() {
        systemManagamentWindow.setVisible(true);
        sessionLogWindow.setVisible(true);
        sideBarMenu.setMouseTransparent(true);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void cancelSessionLogWindow() {
        systemManagamentWindow.setVisible(false);
        sessionLogWindow.setVisible(false);
        sideBarMenu.setMouseTransparent(false);
    }
    
    private String buildRecords(String receiptID, String userID, String username, String sales, String time, String date) {
    String userIdentifier = username + "#" + userID;

        String cleanSales = sales.replace("PHP", "").trim();
        double salesValue = Double.parseDouble(cleanSales);

        return String.format("%18s %17s            PHP %,-10.2f %21s %27s\n", 
                receiptID, 
                userIdentifier, 
                salesValue, 
                time, 
                date);
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void recentRecords() {
        dashboardDisplay.setVisible(false);
        recentRecordsDisplay.setVisible(true);
        upperLabelTitle.setText("RECENT RECORDS");
        
        StringBuilder allRecords = new StringBuilder();
        ReceiptService receipt = new ReceiptService();

        for(Receipt r : receipt.getReceipt()) {
            String receiptID = CashierHelper.formattedReceiptID(r.getReceiptID());     
            String userID = CashierHelper.formattedUser(r.getUserID());
            String username = r.getUsername();
            String sales = String.format("%s %.2f", "PHP ", (r.getSales()));
            String time = r.getTime();
            String date = r.getDate();

            allRecords.append(buildRecords(
                receiptID, userID, username,
                sales, time, date
            )); 

        allRecords.append("\n");
        }
    
        recentRecordsBody.setStyle(
              "-fx-text-fill: black; " 
            + "-fx-font-size: 23; "  
            + "-fx-font-family: 'Consolas';"
            + "-fx-focus-color: grey;"
            + "-fx-faint-focus-color: transparent;"
        );
        
        recentRecordsBody.setText(allRecords.toString());
        deleteNewLine();
        recentRecordsBody.positionCaret(0);
    }

    @FXML
    private void deleteNewLine() {
        String currentText = recentRecordsBody.getText();

        if (currentText.endsWith("\n")) {
            String backUp = currentText.substring(0, currentText.length() - 1);
            recentRecordsBody.setText(backUp);

            recentRecordsBody.positionCaret(backUp.length());
        }
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void searchYear(KeyEvent ke) {     
        if(searchYearField.getText().isBlank()) return;
        if(ke.getCode() == KeyCode.ENTER) {
            int year = Integer.parseInt(searchYearField.getText()); 
            FinancialSummaryService.getYearSummary(year);
            FinancialSummaryService.summarizeYearData(year);
            
            barType = "year";
            Charts yearSum = new Charts(barType, yearlyBar, yearLabel, yearProfit, yearSales, yearExpenses);
            yearSum.implementYearSum(year);
            FinancialSummaryService.deleteYearData();
            chooseMonth(year);
        }
    }
    
    @FXML
    private void chooseMonth(int year) {
        String selectedMonth = monthChoice.getSelectionModel().getSelectedItem();
        if(selectedMonth == null) return;
        
        FinancialSummaryService.getMonthSummary(year, selectedMonth);
        FinancialSummaryService.summarizeMonthData(year, selectedMonth);
        
        barType = "month";
        Charts monthSum = new Charts(barType, monthlyBar, monthLabel, monthProfit, monthSales, monthExpenses);
        monthSum.implementMonthSum(year, selectedMonth);
        FinancialSummaryService.deleteMonthData();
    }
  
    @FXML
    private void displayClock() {
        Timeline clock = new Timeline(new KeyFrame(Duration.ZERO, e -> {
            String CURRENT_TIME = DateTimeUtils.getCurrentTime();
             timeDisplay.setText(CURRENT_TIME); 
        }),
        new KeyFrame(Duration.seconds(1))
    );    
        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void print(ActionEvent e) {
        PrinterJob job = PrinterJob.createPrinterJob();
        if(job == null) return;

        javafx.print.PageLayout pageLayout = job.getPrinter().createPageLayout(
                javafx.print.Paper.LEGAL, 
                javafx.print.PageOrientation.LANDSCAPE, 
                javafx.print.Printer.MarginType.HARDWARE_MINIMUM 
        );

        if(job.showPrintDialog(null)) {
            String[] lines = recentRecordsBody.getText().split("\n");
            int totalLines = lines.length;
            int linesPerPage = 50; 
            int currentLine = 0;

            java.time.LocalDateTime now = java.time.LocalDateTime.now();
            java.time.format.DateTimeFormatter formatter = 
                java.time.format.DateTimeFormatter.ofPattern("MMMM dd, yyyy - hh:mm:ss a");
            String timestamp = now.format(formatter);

            while(currentLine < totalLines) {
                VBox printRoot = new VBox(5);
                printRoot.setPadding(new javafx.geometry.Insets(30, 0, 0, 20)); 
                printRoot.setAlignment(Pos.TOP_LEFT);

                if(currentLine == 0) {
                    Text title = new Text("DIOSARAP'S RECENT RECORDS");
                    title.setStyle("-fx-font-family: 'Courier New'; -fx-font-weight: bold; -fx-font-size: 20;");

                    Text timeGenerated = new Text("Generated on: " + timestamp + "\n");
                    timeGenerated.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 12; -fx-font-weight: bold; -fx-font-style: italic;");

                    VBox titleBox = new VBox(2, title, timeGenerated);
                    titleBox.setAlignment(Pos.CENTER);
                    titleBox.setMinWidth(pageLayout.getPrintableWidth()); 
                    printRoot.getChildren().add(titleBox);
                }

                String colHeaderStr = String.format("%17s %15s %17s %22s %22s\n", 
                                                    "RECORD_ID", "USER_ID", "SALES", "TIME", "DATE");

                Text colHeader = new Text(colHeaderStr + "----------------------------------------------------------------------------------------------------------");
                colHeader.setStyle("-fx-font-family: 'Courier New'; -fx-font-size: 15; -fx-font-weight: bold;");
                printRoot.getChildren().add(colHeader);

                StringBuilder pageContent = new StringBuilder();
                for(int i = 0; i < linesPerPage && currentLine < totalLines; i++) {
                    if(!lines[currentLine].trim().isEmpty()){
                        pageContent.append(lines[currentLine]).append("\n");
                    }
                    currentLine++;
                }

                Text bodyText = new Text(pageContent.toString());
                bodyText.setStyle("-fx-font-family: 'Consolas'; -fx-font-size: 15;");
                bodyText.setWrappingWidth(pageLayout.getPrintableWidth()); 

                printRoot.getChildren().add(bodyText);

                if(!job.printPage(pageLayout, printRoot)) break;
            }
            job.endJob();
        }
    }
    
    @SuppressWarnings("unused")
    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/goat/project/system/view/loginPane.fxml"));     
            Parent root = loader.load();
            
            Stage newStage = new Stage();

            Scene scene = new Scene(root);
            newStage.setScene(scene);
            
            Image iconImage = new Image(getClass().getResourceAsStream("/com/goat/project/system/images/diosarapIcon.png"));
            newStage.getIcons().add(iconImage);
            newStage.setTitle("Sales and Records Management System");

            newStage.setResizable(true);
            newStage.setMaximized(false);

            newStage.initStyle(StageStyle.TRANSPARENT);
            scene.setFill(Color.TRANSPARENT);

            Stage currentStage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            currentStage.close();

            newStage.show();
        } catch (IOException e) {
            System.err.println("Error loading login screen: " + e.getMessage());
        }
    }
}