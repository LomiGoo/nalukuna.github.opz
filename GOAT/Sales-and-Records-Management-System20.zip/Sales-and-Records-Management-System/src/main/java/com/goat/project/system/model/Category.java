package com.goat.project.system.model;

public class Category {
    private int categoryID;
    private String categoryName;

    public Category(int categoryID, String categoryName) {
        this.categoryID = categoryID;
        this.categoryName = categoryName;
    }
        
    public Category(){};
    
    public int getCategoryID() {
        return categoryID;
    }
    
    public String getCategoryName() {
        return categoryName;
    }   
    
    @Override
    public String toString() {
        return this.categoryName;
    }
}
