package com.goat.project.system.service;

import com.goat.project.system.model.ItemList;
import com.goat.project.system.repository.ItemListRepo;
import javafx.scene.control.ChoiceBox;

public class ItemListService {
    public static void addItem(int categoryID, String itemName, String price, String expenses) {
        double formattedPrice = Double.parseDouble(price);
        double formattedExpenses = Double.parseDouble(expenses);
        
        ItemListRepo.addItem(categoryID, itemName, formattedPrice, formattedExpenses);
    }
    
    public static void updateItem(int categoryID, String itemName, int itemID, String price, String expenses) {
        double formattedPrice = Double.parseDouble(price);
        double formattedExpenses = Double.parseDouble(expenses);
        
        ItemListRepo.updateItem(categoryID, itemName, itemID, formattedPrice, formattedExpenses);
    }
    
    public static void populateCategoryChoice(ChoiceBox categoryChoice) {
        ItemListRepo.populateCategory(categoryChoice);
    }
    
    public static boolean findItem(int itemID)  {
        return ItemListRepo.getItemByID(itemID) != null;
    }
    
    public static int getItemID() {
        return ItemList.getItemID();
    }
    
    public static int getItemCategoryID() {
        return ItemList.getCategoryID();
    }
}
