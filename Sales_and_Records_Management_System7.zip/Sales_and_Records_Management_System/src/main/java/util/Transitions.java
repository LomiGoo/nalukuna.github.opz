package util;

import javafx.animation.FadeTransition;
import javafx.scene.Node;
import javafx.util.Duration;

public class Transitions {
    
    public void fade(Node node) {
        node.setVisible(true);
        node.setOpacity(0);
        
        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), node);
        ft.setFromValue(0); 
        ft.setToValue(1);   
        ft.setCycleCount(2); 
        ft.setAutoReverse(true);

        ft.setOnFinished(e -> node.setVisible(false));
        ft.play();
    }
}
