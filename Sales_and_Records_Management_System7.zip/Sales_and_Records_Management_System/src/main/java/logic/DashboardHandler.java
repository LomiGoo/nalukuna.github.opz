package logic;

import database.DataProcessExecutor;
import database.ExpensesDataProcessor;
import database.SalesDataProcessor;

public class DashboardHandler {
    private int salesYearly, expensesYearly, profitYearly;
    private int salesMonthly, expensesMonthly, profitMonthly;
    
    public void processSummaryYearly(int year) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, year) && process.valueCheck(expensesData, year)) {
            process.readData(salesData, year);
            process.readData(expensesData, year);
            
            this.salesYearly = salesData.getSalesSumYearly();
            this.expensesYearly = expensesData.getExpensesSumYearly();
            this.profitYearly = this.salesYearly - this.expensesYearly;
        } else {
            System.out.println("row not exists.");
        }
    }
    
    public void processSummaryMonthly(int year, int month) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, year, month) && process.valueCheck(expensesData, year, month)) {
            process.readData(salesData, year, month);
            process.readData(expensesData, year, month);
            
            this.salesMonthly = salesData.getSalesSumMonthly();
            this.expensesMonthly =  expensesData.getExpensesSumMonthly();           
            this.profitMonthly = this.salesMonthly - this.expensesMonthly;
        } else {
            System.out.println("row not exists.");
        }
    }
   
    public int getSalesYearly() {
        return salesYearly;
    }

    public int getExpensesYearly() {
        return expensesYearly;
    }

    public int getProfitYearly() {
        return profitYearly;
    }

    public int getSalesMonthly() {
        return salesMonthly;
    }

    public int getExpensesMonthly() {
        return expensesMonthly;
    }

    public int getProfitMonthly() {
        return profitMonthly;
    }  
}
