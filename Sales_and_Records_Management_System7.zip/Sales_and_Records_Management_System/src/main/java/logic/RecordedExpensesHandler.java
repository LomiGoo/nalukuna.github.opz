package logic;
import database.DataProcessExecutor;
import database.ExpensesData;
import database.ExpensesDataProcessor;
import entity.Expenses;
import entity.Records;

import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import util.Date;

public class RecordedExpensesHandler {
    private static int calculatedExpenses;
    private static int calculatedExpensesGrandTotal;
    private static int calculatedExpensesRecord;
    private static int calculatedExpensesRecordGrandTotal;
    
    private static final ArrayList<Integer> expensestotalAcquired = new ArrayList<>();
    private static final ArrayList<Integer> grandExpensesTotal = new ArrayList<>();
    private static final ArrayList<Integer> expensesRecordAcquired = new ArrayList<>();
    private static final ArrayList<Integer> grandExpensesRecordTotal = new ArrayList<>();
    
    private final Label[] monthsExpenses;
    private final Label[] recordsTotalExpenses;
    private final Label grandTotalExpenses2, grandTotalRecords2;
    private final Label yearDisplay2;
    private final TextField yearSearchBar2;
    
    private final Date date = new Date();
    /*
    int currentMonth = 10;
    int newMonth = 10;
    int currentYear = 2025;
    int newYear = 2025;
    */
    public RecordedExpensesHandler(Label[] monthsExpenses, Label[] recordsTotalExpenses, Label grandTotalExpenses, Label grandTotalRecords, TextField yearSearchBar2, Label yearDisplay2) {
        this.monthsExpenses = monthsExpenses;
        this.grandTotalExpenses2 = grandTotalExpenses;
        this.recordsTotalExpenses = recordsTotalExpenses;
        this.grandTotalRecords2 = grandTotalRecords;
        this.yearSearchBar2 = yearSearchBar2;
        this.yearDisplay2 = yearDisplay2;
    }
    
    public void storeExpensesTotal() {
        int expensesTotal = Expenses.getExpenses();
        expensestotalAcquired.add(expensesTotal);      
        grandExpensesTotal.add(expensesTotal);
        
    } 
    
    public void storeRecordsTotal() {
        int recordsTotal = Records.getRecord();
        expensesRecordAcquired.add(recordsTotal);
        grandExpensesRecordTotal.add(recordsTotal);
    }
    
    public void calculatedExpensesTotal() {
        int singleMonthTotal = 0;
        int grandTotal = 0;
        for(Integer expenses : expensestotalAcquired) {
            singleMonthTotal += expenses;
        }
        
        for(Integer expenses : grandExpensesTotal) {
            grandTotal += expenses;
        }
        calculatedExpenses = singleMonthTotal;
        calculatedExpensesGrandTotal = grandTotal;
    }
    
    public void calculatedExpensesRecordTotal() {
        int singleMonthTotal = 0;
        int grandTotal = 0;
        for(Integer expensesRecord : expensesRecordAcquired) {
            singleMonthTotal += expensesRecord;
        }
        
        for(Integer grandRecord : grandExpensesRecordTotal) {
            grandTotal += grandRecord;
        }
        calculatedExpensesRecord = singleMonthTotal;
        calculatedExpensesRecordGrandTotal = grandTotal;
    }
    
    int year = 2025;
    int newYear = 2025;
    int month = 11;
    int newMonth = 11;
    int day = 29;
    public void displayRecord() {            
        ExpensesData expensesData = new ExpensesDataProcessor(); 
        DataProcessExecutor executeProcess = new DataProcessExecutor();
        
        if(year != newYear) {
            year = newYear;
            for(int i = 0; i < monthsExpenses.length; i++) {
                monthsExpenses[i].setText("PHP 0");
                recordsTotalExpenses[i].setText("0");
                grandTotalExpenses2.setText("PHP 0");
                grandExpensesTotal.clear();
                grandTotalRecords2.setText("0");     
                grandExpensesRecordTotal.clear();
            }
        }
              
        if(month != newMonth) {
           month = newMonth;
           expensestotalAcquired.clear();
           expensesRecordAcquired.clear();
        }
        
        storeExpensesTotal();
        calculatedExpensesTotal();
        storeRecordsTotal();
        calculatedExpensesRecordTotal();
        
        boolean isYearAndMonthExists = executeProcess.valueCheck(expensesData, year, (month + 1));
        System.out.println(isYearAndMonthExists);
        if(!isYearAndMonthExists) {
            executeProcess.createData(expensesData, year, (month + 1), calculatedExpenses, calculatedExpensesRecord);
            System.out.println("not");
        } else {        
            executeProcess.updateData(expensesData, year, (month + 1), calculatedExpenses, calculatedExpensesRecord);
            System.out.println("exists");
        }
            
        yearDisplay2.setText("YEAR : " + year);
        monthsExpenses[month].setText("PHP " + calculatedExpenses);
        recordsTotalExpenses[month].setText(String.valueOf(calculatedExpensesRecord));
        grandTotalExpenses2.setText("PHP " + calculatedExpensesGrandTotal);
        grandTotalRecords2.setText("Total Records : " + calculatedExpensesRecordGrandTotal);
        
        System.out.println("\nrecorded in year = " + year);
        System.out.println("recorded in month = " + month);
        System.out.println("recorded in day = " + day + "\n");
        day++;
        
        if(month == 0) {
            newMonth = 11;
        }
        if(day > 31) {
            newMonth = 0;
            newYear++;
            day = 30;
        }
    }
    
    public void searchYear() {
        String searchedYear = yearSearchBar2.getText();
        
        ExpensesData expensesData = new ExpensesDataProcessor(); 
        ExpensesDataProcessor yearData = new ExpensesDataProcessor();
        DataProcessExecutor executeProcess = new DataProcessExecutor();
       
        if(executeProcess.valueCheck(expensesData, Integer.parseInt(searchedYear))) {
            executeProcess.readData(yearData, Integer.parseInt(searchedYear));
            int[] expenses = yearData.getExpenses();
            int[] total_Records = yearData.getTotal_Records();
            int expensesSum = yearData.getExpensesSumYearly();
            int recordSum = yearData.getRecordsSumYearly();
            
            yearDisplay2.setText("YEAR : " + searchedYear);
            grandTotalExpenses2.setText("PHP " + expensesSum);
            grandTotalRecords2.setText("Total Records : " + recordSum);
            
            int counter = 0;
            while(counter < 12) {
                monthsExpenses[counter].setText("PHP 0");
                recordsTotalExpenses[counter].setText("0");
                counter++;
            }
            counter = 0;
            while(counter < 12) {
                monthsExpenses[counter].setText("PHP " + expenses[counter]);
                recordsTotalExpenses[counter].setText(Integer.toString(total_Records[counter]));
                counter++;
            }          
        } else {
            System.out.println("YEAR " + searchedYear + " does not exist");
        }
        
    }
}