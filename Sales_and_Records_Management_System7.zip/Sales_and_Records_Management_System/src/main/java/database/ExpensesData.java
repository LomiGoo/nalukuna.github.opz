package database;

public abstract class ExpensesData {
    abstract void createRecExpensesData(int year, int month, int expenses, int totalRecords); 
    abstract void readRecExpensesData(int year);
    abstract void readRecExpensesData(int year, int month);
    abstract void updateRecExpensesData(int year, int month, int expenses, int totalRecords);
    
    abstract boolean existsYearMonth(int year, int month);
    abstract boolean existsYear(int year);
}

