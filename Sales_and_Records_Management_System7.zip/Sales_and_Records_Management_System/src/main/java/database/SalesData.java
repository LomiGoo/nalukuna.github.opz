package database;

public abstract class SalesData {
    abstract void createRecSalesData(int year, int month, int sales, int totalRecords); 
    abstract void readRecSalesData(int year);
    abstract void readRecSalesData(int year, int month);
    abstract void updateRecSalesData(int year, int month, int sales, int totalRecords);
    
    abstract boolean existsYearMonth(int year, int month);
    abstract boolean existsYear(int year);
}
