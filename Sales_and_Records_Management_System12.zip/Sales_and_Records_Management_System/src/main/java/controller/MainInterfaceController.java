package controller;
import entity.User;
import java.text.NumberFormat;
import logic.RecordSalesHandler;
import util.Date;
import visualhelper.SalesRecordComponent;
import util.Transitions;

import navigation.Navigator;
import visualhelper.Charts;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import logic.DashboardHandler;
import logic.RecordExpensesHandler;
import logic.RecordedExpensesHandler;
import logic.RecordedSalesHandler;

@SuppressWarnings("unused")
public class MainInterfaceController {
    @FXML
    private Circle logo;
    @FXML
    private BarChart<String, Number> monthlyBar, yearlyBar;
    @FXML
    private PieChart monthlyPie, yearlyPie;
    @FXML
    private AnchorPane dashboardMenu, recordSalesMenu, recordExpensesMenu, viewSalesMenu, viewExpensesMenu;
    @FXML
    private TextField addSalesTxtField, addExpensesField;
    @FXML
    private Label line1Sales, line2Sales, line3Sales, line4Sales, line5Sales, line6Sales, line7Sales;  
    @FXML
    private Label line1Expenses, line2Expenses, line3Expenses, line4Expenses, line5Expenses, line6Expenses, line7Expenses;
    @FXML
    private Label line1Date1, line2Date1, line3Date1, line4Date1, line5Date1, line6Date1, line7Date1;    
    @FXML
    private Label line1Date2, line2Date2, line3Date2, line4Date2, line5Date2, line6Date2, line7Date2;
    @FXML
    private Label nextRecordIndicator1, nextRecordIndicator2;
    @FXML
    private Label nextCurrentDate1, nextCurrentDate2;
    @FXML
    private Label month1Sales, month2Sales, month3Sales, month4Sales, month5Sales, month6Sales, month7Sales, month8Sales, month9Sales, month10Sales, month11Sales, month12Sales;
    @FXML Label month1Expenses, month2Expenses, month3Expenses, month4Expenses, month5Expenses, month6Expenses, month7Expenses, month8Expenses, month9Expenses, month10Expenses, month11Expenses, month12Expenses; 
    @FXML
    private Label month1recordTotal, month2recordTotal, month3recordTotal, month4recordTotal, month5recordTotal, month6recordTotal, month7recordTotal, month8recordTotal, month9recordTotal, month10recordTotal, month11recordTotal, month12recordTotal;
    @FXML
    private Label month1recordTotal2, month2recordTotal2, month3recordTotal2, month4recordTotal2, month5recordTotal2, month6recordTotal2, month7recordTotal2, month8recordTotal2, month9recordTotal2, month10recordTotal2, month11recordTotal2, month12recordTotal2;
    @FXML
    private Label grandTotalSales1, grandTotalSales2, grandTotalRecords1, grandTotalRecords2;
    @FXML
    private Label yearDisplay1, yearDisplay2;
    @FXML
    private HBox line1RecSales, line2RecSales, line3RecSales, line4RecSales, line5RecSales, line6RecSales, line7RecSales; 
    @FXML
    private HBox line1RecExpenses, line2RecExpenses, line3RecExpenses, line4RecExpenses, line5RecExpenses, line6RecExpenses, line7RecExpenses;
    @FXML
    private HBox createSalesMenu, createExpensesMenu, recordedSalesMenu, recordedExpensesMenu;
    @FXML
    private Label incomeYearlyDisplay, incomeMonthlyDisplay, expensesYearlyDisplay, expensesMonthlyDisplay, profitYearlyDisplay, profitMonthlyDisplay;
    @FXML
    private Label notifyRecorded1, notifyRecorded2;
    @FXML
    private Button deleteItem1, deleteItem2;
    @FXML
    private Button sumButton, addToRecentButton;
    @FXML
    private TextField yearSearchBar1, yearSearchBar2, searchYear;
    @FXML
    private ChoiceBox<String> monthChoice;
    @FXML
    private ChoiceBox<String> deleteSelection1, deleteSelection2;
    @FXML
    private Navigator navigator;
    private Charts charts;
   
    private SalesRecordComponent salesRecordComponent;
    private RecordSalesHandler recordSalesHandler;
    private RecordExpensesHandler recordExpensesHandler;
    private RecordedSalesHandler recordedSalesHandler;
    private RecordedExpensesHandler recordedExpensesHandler;
    private DashboardHandler dashboardHandler;
    
    private final Date date = new Date();
    private final Transitions transition = new Transitions();
    
    private final NumberFormat numFormat = NumberFormat.getInstance();
    private final String[] months = {"January", "February", "March",
                           "April", "May", "June", "July",
                           "August", "September", "October",
                           "November", "December"};
    
    private final Integer currentUserID = User.getCurrentUserID();
    
    @FXML
    private void initialize() {
        navigator = new Navigator(
            dashboardMenu, recordSalesMenu, recordExpensesMenu, 
            viewSalesMenu, viewExpensesMenu
        );
        
        charts = new Charts(
            monthlyBar,
            yearlyBar,
            monthlyPie,
            yearlyPie
        );
        
        HBox[] linesSales = {
            line1RecSales, line2RecSales, line3RecSales, 
            line4RecSales, line5RecSales, line6RecSales, 
            line7RecSales
        };
        
        HBox[] linesExpenses = {
            line1RecExpenses, line2RecExpenses, line3RecExpenses, 
            line4RecExpenses, line5RecExpenses, line6RecExpenses, 
            line7RecExpenses
        };

        Label[] salesLabel = {
            line1Sales, line2Sales, line3Sales, 
            line4Sales, line5Sales, line6Sales, 
            line7Sales
        };
        
        Label[] expensesLabel = {
            line1Expenses, line2Expenses, line3Expenses,
            line4Expenses, line5Expenses, line6Expenses,
            line7Expenses
        };

        Label[] dateLabelsSales = {
            line1Date1, line2Date1, line3Date1,
            line4Date1, line5Date1, line6Date1,
            line7Date1
        };
        
        Label[] dateLabelsExpenses = {
            line1Date2, line2Date2, line3Date2,
            line4Date2, line5Date2, line6Date2,
            line7Date2
        };
       
        Label[] monthsSales = {
            month1Sales, month2Sales, month3Sales,
            month4Sales, month5Sales, month6Sales,
            month7Sales, month8Sales, month9Sales,
            month10Sales, month11Sales, month12Sales
        };
            
        Label[] recordsTotalSales = {
            month1recordTotal, month2recordTotal, month3recordTotal,
            month4recordTotal, month5recordTotal, month6recordTotal,
            month7recordTotal, month8recordTotal, month9recordTotal,
            month10recordTotal, month11recordTotal, month12recordTotal
        };
        
         Label[] monthsExpenses = {
            month1Expenses, month2Expenses, month3Expenses,
            month4Expenses, month5Expenses, month6Expenses,
            month7Expenses, month8Expenses, month9Expenses,
            month10Expenses, month11Expenses, month12Expenses
        };
         
        Label[] recordsTotalExpenses = {
            month1recordTotal2, month2recordTotal2, month3recordTotal2,
            month4recordTotal2, month5recordTotal2, month6recordTotal2,
            month7recordTotal2, month8recordTotal2, month9recordTotal2,
            month10recordTotal2, month11recordTotal2, month12recordTotal2
        };
        
        recordSalesHandler = new RecordSalesHandler(linesSales, salesLabel, dateLabelsSales, deleteSelection1, deleteItem1, nextRecordIndicator1);
        recordExpensesHandler = new RecordExpensesHandler(linesExpenses, expensesLabel, dateLabelsExpenses, deleteSelection2, deleteItem2, nextRecordIndicator2);
        recordedSalesHandler = new RecordedSalesHandler(currentUserID, monthsSales, recordsTotalSales, grandTotalSales1, grandTotalRecords1, yearSearchBar1, yearDisplay1);
        recordedExpensesHandler = new RecordedExpensesHandler(currentUserID, monthsExpenses, recordsTotalExpenses, grandTotalSales2, grandTotalRecords2, yearSearchBar2, yearDisplay2);
        dashboardHandler = new DashboardHandler(currentUserID);
        String currentDate = date.getCurrentDate();
        
        recordSalesHandler.showNextRecord();
        nextCurrentDate1.setText("Date : " + currentDate);
        
        recordExpensesHandler.showNextRecord();
        nextCurrentDate2.setText("Date : " + currentDate);
        
        yearDisplay1.setText("YEAR : " + 2025);
        yearDisplay2.setText("YEAR : " + 2025);
        
        Image logoImg = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        logo.setFill(new ImagePattern(logoImg));
        
        System.out.println("user ID = " + currentUserID);
   
        //if(currentUserID == null) Platform.exit();
        
        searchYear.setText("2025");
        readyChartAndRecordedList();
        
        monthChoice.getItems().addAll(months);
        
        notifyRecorded1.setVisible(false);
        notifyRecorded2.setVisible(false);
        
        monthChoice.getSelectionModel().select(11);
        dataSummary();
        
        deleteSelection1.setValue("Select Record...");
        deleteSelection2.setValue("Select Record...");
        
        addSalesTxtField.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) addSalesTxtField.setText(oldTxt);     
            if(addSalesTxtField.getText().length() > 19) addSalesTxtField.setText(oldTxt);
            if(addSalesTxtField.getText().length() == 1 && newTxt.matches("0")) addSalesTxtField.setText(oldTxt);
        }); 
        
        addExpensesField.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) addExpensesField.setText(oldTxt);
            if(addExpensesField.getText().length() > 19) addExpensesField.setText(oldTxt);         
            if(addExpensesField.getText().length() == 1 && newTxt.matches("0")) addExpensesField.setText(oldTxt);
        });
        
        searchYear.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) searchYear.setText(oldTxt);
        });
        
        yearSearchBar1.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) yearSearchBar1.setText(oldTxt);
        });
        
        yearSearchBar2.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) yearSearchBar2.setText(oldTxt);
        });
    }
    
    @FXML
    private boolean readyChartAndRecordedList() {
        if(currentUserID == null) return false;
        
        yearSearchBar1.setText("2025");
        recordedSalesHandler.searchYear();
        yearSearchBar2.setText("2025");
        recordedExpensesHandler.searchYear();
        return true;
    }
    @FXML
    private void showDashboardMenu(MouseEvent e) {
        navigator.showDashboardMenu();
    }
    
    @FXML
    private void showRecordSalesMenu(MouseEvent e) {
        navigator.showRecordSalesMenu();
    }
     
    @FXML
    private void showRecordExpensesMenu(MouseEvent e) {
        navigator.showRecordExpensesMenu();
    }
     
    @FXML
    private void showViewSalesMenu(MouseEvent e) {
        navigator.showViewSalesMenu();
    }
      
    @FXML
    private void showViewExpensesMenu(MouseEvent e) {
        navigator.showViewExpensesMenu();
    }
    
    @FXML
    private void getInputENTER(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER) getInput();
    }
    
    @FXML
    private void getInput() {
        if(recordSalesMenu.isVisible()) {
            if(addSalesTxtField.getText().isEmpty()) return;  
            recordSalesHandler.getInputSales(addSalesTxtField.getText());
            addSalesTxtField.clear();
            displayRecord();
        }
        
        if(recordExpensesMenu.isVisible()) {
            if(addExpensesField.getText().isEmpty()) return;
            recordExpensesHandler.getInputExpenses(addExpensesField.getText());
            addExpensesField.clear();           
            displayRecord();
        }       
    } 
    
    @FXML
    private void displayRecord() {
        String currentDate = date.getCurrentDate();
        
        if(recordSalesMenu.isVisible()) {
            recordSalesHandler.showRecordedList();     
            String processedInput = recordSalesHandler.getProcessedInput();                     
            recordSalesHandler.showRecordedLine(processedInput, currentDate);           
            recordSalesHandler.showNextRecord();          
            recordSalesHandler.resetInput();        
        }
        
        if(recordExpensesMenu.isVisible()) {
            recordExpensesHandler.showRecordedList();        
            String processedInput = recordExpensesHandler.getProcessedInput();
            recordExpensesHandler.showRecordedLine(processedInput, currentDate);
            recordExpensesHandler.showNextRecord();
            recordExpensesHandler.resetInput();
        }    
    }
    
    @FXML
    private void removeRecord() {
        if(recordSalesMenu.isVisible()) recordSalesHandler.deleteRecord();
        if(recordExpensesMenu.isVisible()) recordExpensesHandler.deleteRecord();
    }
    
    @FXML
    private void addToRecordedList() {
        if(recordSalesMenu.isVisible()) {
            if(!line1RecSales.isVisible()) return;
            recordSalesHandler.addToRecordedList();
            transition.fade(notifyRecorded1);
            recordedSalesHandler.displayRecord();
            return;
        }   
        if(recordExpensesMenu.isVisible()) {
            if(!line1RecExpenses.isVisible()) return;
            recordExpensesHandler.addToRecordedList();
            transition.fade(notifyRecorded2);
            recordedExpensesHandler.displayRecord();
        }
    }
    
    @FXML
    private void searchYear1(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER) recordedSalesHandler.searchYear();
    }
    
    @FXML
    private void searchYear2(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER) recordedExpensesHandler.searchYear();
    }
    
    @FXML
    private void dataSummary() {          
        if(searchYear.getText().trim().isEmpty()) return;
        
        DashboardHandler dashhandler = new DashboardHandler(currentUserID);
        int searchedYear = Integer.parseInt(searchYear.getText().trim());      
        
        if(monthChoice.getValue() == null) {
            dataSummaryYear(dashhandler, searchedYear);
        } else {
            dataSummaryMonth(dashhandler, searchedYear);
            dataSummaryYear(dashhandler, searchedYear);
        }
    }
    
    @FXML
    private void dataSummaryMonth(DashboardHandler dashHandler, int searchedYear) {
        int choice = monthChoice.getSelectionModel().getSelectedIndex();

        dashHandler.processSummaryMonthly(searchedYear, (choice + 1));
        int salesMonthly = dashHandler.getSalesMonthly();
        int expensesMonthly = dashHandler.getExpensesMonthly();
        int profitMonthly = dashHandler.getProfitMonthly();
        
        incomeMonthlyDisplay.setText("PHP " + numFormat.format(salesMonthly));
        expensesMonthlyDisplay.setText("PHP " + numFormat.format(expensesMonthly));
        profitMonthlyDisplay.setText("PHP " + numFormat.format(profitMonthly));
        
        charts.implementMonthlyBar(searchedYear, choice, salesMonthly, expensesMonthly, profitMonthly);
        charts.implementMonthlyPie(searchedYear, choice, salesMonthly, expensesMonthly, profitMonthly);
    }
    
    @FXML
    private void dataSummaryYear(DashboardHandler dashHandler, int searchedYear) {
        if(searchedYear < 2025) {
            System.out.println("year not available");
            return;
        }      
        dashHandler.processSummaryYearly(searchedYear); 
        int salesYear = dashHandler.getSalesYearly();
        int expensesYear = dashHandler.getExpensesYearly();
        int profitYear = dashHandler.getProfitYearly();
        
        incomeYearlyDisplay.setText("PHP " + numFormat.format(salesYear));
        expensesYearlyDisplay.setText("PHP " + numFormat.format(expensesYear));
        profitYearlyDisplay.setText("PHP " + numFormat.format(profitYear));
        
        charts.implementYearlyBar(searchedYear, salesYear, expensesYear, profitYear);
        charts.implementYearlyPie(searchedYear, salesYear, expensesYear, profitYear);   
    }
    
    private boolean isMenuRecorderVisible = false;    
    @FXML
    private void openNewRecords(MouseEvent event) {       
        if(!isMenuRecorderVisible) {
            createSalesMenu.setVisible(true);
            createSalesMenu.setManaged(true);
            createExpensesMenu.setVisible(true);
            createExpensesMenu.setManaged(true);
            isMenuRecorderVisible = true;
        } else {
            createSalesMenu.setVisible(false);
            createSalesMenu.setManaged(false);
            createExpensesMenu.setVisible(false);
            createExpensesMenu.setManaged(false);
            isMenuRecorderVisible = false;
        }
    }
    
    private boolean isMenuListVisible = false;    
    @FXML
    private void openListRecords(MouseEvent event) {       
        if(!isMenuListVisible) {
            recordedSalesMenu.setVisible(true);
            recordedSalesMenu.setManaged(true);
            recordedExpensesMenu.setVisible(true);
            recordedExpensesMenu.setManaged(true);
            isMenuListVisible = true;
        } else {
            recordedSalesMenu.setVisible(false);
            recordedSalesMenu.setManaged(false);
            recordedExpensesMenu.setVisible(false);
            recordedExpensesMenu.setManaged(false);
            isMenuListVisible = false;
        }
    }
}