package database;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    private static final Path APP_DIR_FOLDER = Paths.get(System.getProperty("java.io.tmpdir"), "GOAT_MANAGEMENT");
    private static final Path DB_PATH = APP_DIR_FOLDER.resolve("Management.dat");

    public static Connection connectTest() throws SQLException, IOException {
        Files.createDirectories(APP_DIR_FOLDER);
       
        if (Files.notExists(DB_PATH)) {
            try (InputStream in = DBConnection.class.getResourceAsStream("/database/Management.db")) {

                if (in == null) {
                    throw new RuntimeException("Starter DB missing in resources!");
                }

                Files.copy(in, DB_PATH);
                System.out.println("Starter DB copied to user folder.");
            }
        }

        String DB_URL = "jdbc:sqlite:" + DB_PATH.toAbsolutePath();
        Connection connection = DriverManager.getConnection(DB_URL);
        System.out.println("Connection Successful.");
        return connection;
    }
}
