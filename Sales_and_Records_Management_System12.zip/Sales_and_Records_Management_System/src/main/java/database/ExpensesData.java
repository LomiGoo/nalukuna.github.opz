package database;

public abstract class ExpensesData {
    abstract void createRecExpensesData(int userID, int year, int month, int expenses, int totalRecords); 
    abstract void readRecExpensesData(int userID, int year);
    abstract void readRecExpensesData(int userID, int year, int month);
    abstract void updateRecExpensesData(int userID, int year, int month, int expenses, int totalRecords);
    
    abstract boolean existsYearMonth(int userID, int year, int month);
    abstract boolean existsYear(int userID, int year);
}

