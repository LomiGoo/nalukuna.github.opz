package logic;

import database.DataProcessExecutor;
import database.ExpensesDataProcessor;
import database.SalesDataProcessor;

public class DashboardHandler {
    private int salesYearly, expensesYearly, profitYearly;
    private int salesMonthly, expensesMonthly, profitMonthly;
    private final Integer currentUserID;

    public DashboardHandler(Integer currentUserID) {
        this.currentUserID = currentUserID;
    }
    
    public void processSummaryYearly(int year) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, currentUserID, year) && process.valueCheck(expensesData, currentUserID, year)) {
            process.readData(salesData, currentUserID, year);
            process.readData(expensesData, currentUserID, year);
            
            this.salesYearly = salesData.getSalesSumYearly();
            this.expensesYearly = expensesData.getExpensesSumYearly();
            this.profitYearly = this.salesYearly - this.expensesYearly;
        } else {
            System.out.println("row not exists.");
        }
    }
    
    public void processSummaryMonthly(int year, int month) {
        SalesDataProcessor salesData = new SalesDataProcessor();
        ExpensesDataProcessor expensesData = new ExpensesDataProcessor();
        DataProcessExecutor process = new DataProcessExecutor();
        
        if(process.valueCheck(salesData, currentUserID, year, month) && process.valueCheck(expensesData, currentUserID, year, month)) {
            process.readData(salesData, currentUserID, year, month);
            process.readData(expensesData, currentUserID, year, month);
            
            this.salesMonthly = salesData.getSalesSumMonthly();
            this.expensesMonthly =  expensesData.getExpensesSumMonthly();           
            this.profitMonthly = this.salesMonthly - this.expensesMonthly;
        } else {
            System.out.println("row not exists.");
        }
    }
   
    public int getSalesYearly() {
        return salesYearly;
    }

    public int getExpensesYearly() {
        return expensesYearly;
    }

    public int getProfitYearly() {
        return profitYearly;
    }

    public int getSalesMonthly() {
        return salesMonthly;
    }

    public int getExpensesMonthly() {
        return expensesMonthly;
    }

    public int getProfitMonthly() {
        return profitMonthly;
    }  
}
