package logic;
import database.DataProcessExecutor;
import database.SalesData;
import database.SalesDataProcessor;
import entity.Sales;
import entity.Records;

import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import util.Date;

public class RecordedSalesHandler {
    private static int calculatedSales;
    private static int calculatedSalesGrandTotal;
    private static int calculatedSalesRecord;
    private static int calculatedSalesRecordGrandTotal;
    
    private static final ArrayList<Integer> salestotalAcquired = new ArrayList<>();
    private static final ArrayList<Integer> grandSalesTotal = new ArrayList<>();
    private static final ArrayList<Integer> salesRecordAcquired = new ArrayList<>();
    private static final ArrayList<Integer> grandSalesRecordTotal = new ArrayList<>();
    
    private final Label[] monthsSales;
    private final Label[] recordsTotalSales;
    private final Label grandTotalSales1, grandTotalRecords1;
    private final Label yearDisplay1;
    private final TextField yearSearchBar1;
    private final Integer currentUserID;
    
    private final Date date = new Date();
    /*
    int currentMonth = 10;
    int newMonth = 10;
    int currentYear = 2025;
    int newYear = 2025;
    */
    public RecordedSalesHandler(Integer currentUserID, Label[] monthsSales, Label[] recordsTotalSales, Label grandTotalSales, Label grandTotalRecords, TextField yearSearchBar1, Label yearDisplay1) {
        this.currentUserID = currentUserID;
        this.monthsSales = monthsSales;
        this.grandTotalSales1 = grandTotalSales;
        this.recordsTotalSales = recordsTotalSales;
        this.grandTotalRecords1 = grandTotalRecords;
        this.yearSearchBar1 = yearSearchBar1;
        this.yearDisplay1 = yearDisplay1;
    }
    
    public void storeSalesTotal() {
        int salesTotal = Sales.getSales();
        salestotalAcquired.add(salesTotal);      
        grandSalesTotal.add(salesTotal);
        
    } 
    
    public void storeRecordsTotal() {
        int recordsTotal = Records.getRecord();
        salesRecordAcquired.add(recordsTotal);
        grandSalesRecordTotal.add(recordsTotal);
    }
    
    public void calculatedSalesTotal() {
        int singleMonthTotal = 0;
        int grandTotal = 0;
        for(Integer sales : salestotalAcquired) {
            singleMonthTotal += sales;
        }
        
        for(Integer sales : grandSalesTotal) {
            grandTotal += sales;
        }
        calculatedSales = singleMonthTotal;
        calculatedSalesGrandTotal = grandTotal;
    }
    
    public void calculatedSalesRecordTotal() {
        int singleMonthTotal = 0;
        int grandTotal = 0;
        for(Integer salesRecord : salesRecordAcquired) {
            singleMonthTotal += salesRecord;
        }
        
        for(Integer grandRecord : grandSalesRecordTotal) {
            grandTotal += grandRecord;
        }
        calculatedSalesRecord = singleMonthTotal;
        calculatedSalesRecordGrandTotal = grandTotal;
    }
    
    int year = 2025;
    int newYear = 2025;
    int month = 11;
    int newMonth = 11;
    int day = 29;
    public void displayRecord() {            
        SalesData salesData = new SalesDataProcessor(); 
        DataProcessExecutor executeProcess = new DataProcessExecutor();
        
        if(year != newYear) {
            year = newYear;
            for(int i = 0; i < monthsSales.length; i++) {
                monthsSales[i].setText("PHP 0");
                recordsTotalSales[i].setText("0");
                grandTotalSales1.setText("PHP 0");
                grandSalesTotal.clear();
                grandTotalRecords1.setText("0");     
                grandSalesRecordTotal.clear();
            }
        }      
        
        if(month != newMonth) {
           month = newMonth;
           salestotalAcquired.clear();
           salesRecordAcquired.clear();
        }
        
        storeSalesTotal();
        calculatedSalesTotal();
        storeRecordsTotal();
        calculatedSalesRecordTotal();
        
        boolean isYearAndMonthExists = executeProcess.valueCheck(salesData, currentUserID, year, (month + 1));
        System.out.println(isYearAndMonthExists);
        if(!isYearAndMonthExists) {
            executeProcess.createData(salesData, currentUserID, year, (month + 1), calculatedSales, calculatedSalesRecord);
            System.out.println("not");
        } else {        
            executeProcess.updateData(salesData, currentUserID, year, (month + 1), calculatedSales, calculatedSalesRecord);
            System.out.println("exists");
        }
        
        yearDisplay1.setText("YEAR : " + year);
        monthsSales[month].setText("PHP " + calculatedSales);
        recordsTotalSales[month].setText(String.valueOf(calculatedSalesRecord));
        grandTotalSales1.setText("PHP " + calculatedSalesGrandTotal);
        grandTotalRecords1.setText("Total Records : " + calculatedSalesRecordGrandTotal);
        
        System.out.println("\nrecorded in year = " + year);
        System.out.println("recorded in month = " + month);
        System.out.println("recorded in day = " + day + "\n");
        day++;
        
        if(month == 0) {
            newMonth = 11;
        }
        if(day > 31) {
            newMonth = 0;
            newYear++;
            day = 30;
        }
    }
    
    public void searchYear() {
        String searchedYear = yearSearchBar1.getText();
        
        SalesData salesData = new SalesDataProcessor(); 
        SalesDataProcessor yearData = new SalesDataProcessor();
        DataProcessExecutor executeProcess = new DataProcessExecutor();
       
        if(executeProcess.valueCheck(salesData, currentUserID, Integer.parseInt(searchedYear))) {
            executeProcess.readData(yearData, currentUserID, Integer.parseInt(searchedYear));
            int[] sales = yearData.getSales();
            int[] total_Records = yearData.getTotal_Records();
            int salesSum = yearData.getSalesSumYearly();
            int recordSum = yearData.getRecordsSumYearly();
            
            yearDisplay1.setText("YEAR : " + searchedYear);
            grandTotalSales1.setText("PHP " + salesSum);
            grandTotalRecords1.setText("Total Records : " + recordSum);
            
            int counter = 0;
            while(counter < 12) {
                monthsSales[counter].setText("PHP 0");
                recordsTotalSales[counter].setText("0");
                counter++;
            }
            counter = 0;
            while(counter < 12) {
                monthsSales[counter].setText("PHP " + sales[counter]);
                recordsTotalSales[counter].setText(Integer.toString(total_Records[counter]));
                counter++;
            }          
        } else {
            System.out.println("YEAR " + searchedYear + " does not exist");
        }
        
    }
}