package entity;

public class Expenses {
     private static int expenses;

    public static void setExpenses(int expenses) {
        Expenses.expenses = expenses;
    }

    public static int getExpenses() {
        return expenses;
    }

}
