package database;

public abstract class SalesData {
    abstract void createRecSalesData(int userID, int year, int month, int sales, int totalRecords); 
    abstract void readRecSalesData(int userID, int year);
    abstract void readRecSalesData(int userID, int year, int month);
    abstract void updateRecSalesData(int userID, int year, int month, int sales, int totalRecords);
    
    abstract boolean existsYearMonth(int userID, int year, int month);
    abstract boolean existsYear(int userID, int year);
}
