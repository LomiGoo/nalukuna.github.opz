package visualhelper;

import javafx.scene.layout.HBox;

public class SalesRecordComponent {
    private final HBox line1RecSales, line2RecSales, line3RecSales, line4RecSales, line5RecSales, line6RecSales, line7RecSales;

    public SalesRecordComponent(HBox line1RecSales, HBox line2RecSales, HBox line3RecSales, HBox line4RecSales, HBox line5RecSales, HBox line6RecSales, HBox line7RecSales) {
        this.line1RecSales = line1RecSales;
        this.line2RecSales = line2RecSales;
        this.line3RecSales = line3RecSales;
        this.line4RecSales = line4RecSales;
        this.line5RecSales = line5RecSales;
        this.line6RecSales = line6RecSales;
        this.line7RecSales = line7RecSales;
    }

    public void setVisibleLine1() {
        line1RecSales.setVisible(true);
        line1RecSales.setManaged(true);
    }
    
    public void setVisibleLine2() {
        line2RecSales.setVisible(true);
        line2RecSales.setManaged(true);
    }
    
    public void setVisibleLine3() {
        line3RecSales.setVisible(true);
        line3RecSales.setManaged(true);
    }
    
    public void setVisibleLine4() {
        line4RecSales.setVisible(true);
        line4RecSales.setManaged(true);
    }
    
    public void setVisibleLine5() {
        line5RecSales.setVisible(true);
        line5RecSales.setManaged(true);
    }
    
    public void setVisibleLine6() {
        line6RecSales.setVisible(true);
        line6RecSales.setManaged(true);
    }
    
    public void setVisibleLine7() {
        line7RecSales.setVisible(true);
        line7RecSales.setManaged(true);
    }
}
