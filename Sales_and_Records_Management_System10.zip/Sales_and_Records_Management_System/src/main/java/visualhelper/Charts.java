package visualhelper;

import javafx.collections.FXCollections;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

public class Charts {
    private final BarChart<String, Number> monthlyBar, yearlyBar;
    private final PieChart monthlyPie, yearlyPie;
    
    String[] months = {"January", "February", "March",
                           "April", "May", "June", "July",
                           "August", "September", "October",
                           "November", "December"};
    
    public Charts(BarChart<String, Number> monthlyBar, BarChart yearlyBar, PieChart monthlyPie, PieChart yearlyPie) {
        this.monthlyBar = monthlyBar;
        this.yearlyBar = yearlyBar;
        this.monthlyPie = monthlyPie;
        this.yearlyPie = yearlyPie;
    }
    
    public void implementMonthlyBar(int year, int month, int sales, int expenses, int profit) { 
        monthlyBar.getData().clear();
        CategoryAxis xAxis = (CategoryAxis) monthlyBar.getXAxis();
        xAxis.setLabel(months[month]);
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.setName("Sales");
        series1.getData().add(new XYChart.Data<>("", sales));
      
        XYChart.Series<String, Number> series2 = new XYChart.Series<>();
        series2.setName("Expenses");
        series2.getData().add(new XYChart.Data<>("",expenses));
      
        XYChart.Series<String, Number> series3 = new XYChart.Series<>();
        series3.setName("Profit");
        series3.getData().add(new XYChart.Data<>("", profit));
        
        monthlyBar.getData().addAll(series1, series2, series3);
    }
    
    public void implementYearlyBar(int year, int sales, int expenses, int profit) {      
        yearlyBar.getData().clear();
        CategoryAxis xAxis = (CategoryAxis) yearlyBar.getXAxis();
        xAxis.setLabel(Integer.toString(year));
        
        XYChart.Series<String, Number> series1 = new XYChart.Series<>();
        series1.setName("Sales");
        series1.getData().add(new XYChart.Data<>("", sales));
      
        XYChart.Series<String, Number> series2 = new XYChart.Series<>();
        series2.setName("Expenses");
        series2.getData().add(new XYChart.Data<>("", expenses));
   
        XYChart.Series<String, Number> series3 = new XYChart.Series<>();
        series3.setName("Profit");
        series3.getData().add(new XYChart.Data<>("", profit));
    
        yearlyBar.getData().addAll(series1, series2, series3);
    }
    
    public void implementMonthlyPie(int year, int month, int sales, int expenses, int profit) {
        monthlyPie.getData().clear();
        PieChart.Data salesData = new PieChart.Data("Sales", sales);
        PieChart.Data expensesData = new PieChart.Data("Expenses", expenses);
        PieChart.Data profitData = new PieChart.Data("Profit", profit);
        
        monthlyPie.setData(FXCollections.observableArrayList(
                salesData, expensesData, profitData
        ));
        monthlyPie.setTitle(months[month]);
        monthlyPie.setLegendVisible(true);
    }
    
     public void implementYearlyPie(int year, int sales, int expenses, int profit) {
         yearlyPie.getData().clear();
        PieChart.Data salesData = new PieChart.Data("Sales", sales);
        PieChart.Data expensesData  = new PieChart.Data("Expenses", expenses);
        PieChart.Data profitData = new PieChart.Data("Profit", profit);
        
        yearlyPie.setData(FXCollections.observableArrayList(
                salesData, expensesData, profitData
        ));
        yearlyPie.setTitle(Integer.toString(year));
        yearlyPie.setLegendVisible(true);
    }
}
