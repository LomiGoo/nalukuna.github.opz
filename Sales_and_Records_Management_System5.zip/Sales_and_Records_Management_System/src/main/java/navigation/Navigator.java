package navigation;
import controller.MainInterfaceController;
import javafx.scene.layout.AnchorPane;

public class Navigator {
    private final AnchorPane dashboardMenu, recordSalesMenu, recordExpensesMenu, viewSalesMenu, viewExpensesMenu;

    public Navigator(AnchorPane dashboardMenu, AnchorPane recordSalesMenu, AnchorPane recordExpensesMenu, AnchorPane viewSalesMenu, AnchorPane viewExpensesMenu) {
        this.dashboardMenu = dashboardMenu;
        this.recordSalesMenu = recordSalesMenu;
        this.recordExpensesMenu = recordExpensesMenu;
        this.viewSalesMenu = viewSalesMenu;
        this.viewExpensesMenu = viewExpensesMenu;
    }
    
    public void hideAll() {
        dashboardMenu.setVisible(false);
        recordSalesMenu.setVisible(false);
        recordExpensesMenu.setVisible(false);
        viewSalesMenu.setVisible(false);
        viewExpensesMenu.setVisible(false);
    }
    
    public void showDashboardMenu() {
        hideAll();
        dashboardMenu.setVisible(true);
    }
    
     public void showRecordSalesMenu() {
        hideAll();
        recordSalesMenu.setVisible(true);
    }
     
    public void showRecordExpensesMenu() {
        hideAll();
        recordExpensesMenu.setVisible(true);
    }
      
    public void showViewSalesMenu() {
        hideAll();
        viewSalesMenu.setVisible(true);
    }
       
    public void showViewExpensesMenu() {
        hideAll();
        viewExpensesMenu.setVisible(true);
    }
    
}
