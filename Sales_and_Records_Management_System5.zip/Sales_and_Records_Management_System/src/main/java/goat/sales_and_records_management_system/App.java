package goat.sales_and_records_management_system;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;

public class App extends Application {

    public static void main(String[] args) {
        launch(args);
    }
    
    @Override
    public void start(Stage stage) throws Exception {
        //FXMLLoader loader = new FXMLLoader(getClass().getResource("login_pane.fxml"));
        //FXMLLoader loader = new FXMLLoader(getClass().getResource("signup_pane.fxml"));
        FXMLLoader loader = new FXMLLoader(getClass().getResource("main_app_interface.fxml"));
        Parent root = loader.load();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        stage.setMaximized(true);
        
        Image iconImage = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        stage.getIcons().add(iconImage);
        stage.setTitle("Sales and Records Management System");
        
        //scene.getStylesheets().add(getClass().getResource("/CSS/login_pane_styler.css").toExternalForm());
        //scene.getStylesheets().add(getClass().getResource("/CSS/main_app_interface_styler.css").toExternalForm());
        scene.getStylesheets().add(getClass().getResource("/CSS/record_sales_styler.css").toExternalForm());
        
        stage.setFullScreen(true);
        scene.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.F11) {
                stage.setFullScreen(!stage.isFullScreen());
            }
        }); 

    }

}