package visualhelper;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;

public class Charts {
    private final BarChart<String, Number> barChartDB;
    private final PieChart pieChartSales, pieChartExpenses;


    public Charts(BarChart<String, Number> barChartDB, PieChart pieChartSales, PieChart pieChartExpenses) {
        this.barChartDB = barChartDB;
        this.pieChartSales = pieChartSales;
        this.pieChartExpenses = pieChartExpenses;
    }
    
    public void implementBarChart() {
        CategoryAxis xAxis = (CategoryAxis) barChartDB.getXAxis();
        xAxis.setLabel("February");
        
        XYChart.Series<String, Number> cashflowSeries = new XYChart.Series<>();
        cashflowSeries.setName("2025 Sales");

        cashflowSeries.getData().add(new XYChart.Data<>("Sales", 100));
        cashflowSeries.getData().add(new XYChart.Data<>("Expenses", 150));
          
        barChartDB.getData().addAll(cashflowSeries);
    }
    
    public void implementPieSales() {
        ObservableList<PieChart.Data> pieSales = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 500),
            new PieChart.Data("Feb", 100)
        ); 
        pieChartSales.setData(pieSales);
        pieChartSales.setTitle("INCOME");
    }
    
    public void implementPieExpenses() {
        ObservableList<PieChart.Data> pieExpenses = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 50),
            new PieChart.Data("Feb", 10)
        ); 
        pieChartExpenses.setData(pieExpenses);
        pieChartExpenses.setTitle("EXPENSES");
    }
}
