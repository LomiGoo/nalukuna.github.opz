package controller;
import entity.User;
import logic.RecordSalesHandler;
import util.Date;
import visualhelper.SalesRecordComponent;

import javafx.event.ActionEvent;
import navigation.Navigator;
import visualhelper.Charts;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import logic.RecordExpensesHandler;
import logic.RecordedSalesHandler;

@SuppressWarnings("unused")
public class MainInterfaceController {
    @FXML
    private Circle logo;
    @FXML
    private BarChart<String, Number> barChartDB;
    @FXML
    private PieChart pieChartSales, pieChartExpenses;
    @FXML
    private AnchorPane dashboardMenu, recordSalesMenu, recordExpensesMenu, viewSalesMenu, viewExpensesMenu;
    @FXML
    private TextField addSalesTxtField, addExpensesField;
    @FXML
    private Label line1Sales, line2Sales, line3Sales, line4Sales, line5Sales, line6Sales, line7Sales;  
    @FXML
    private Label line1Expenses, line2Expenses, line3Expenses, line4Expenses, line5Expenses, line6Expenses, line7Expenses;
    @FXML
    private Label line1Date1, line2Date1, line3Date1, line4Date1, line5Date1, line6Date1, line7Date1;    
    @FXML
    private Label line1Date2, line2Date2, line3Date2, line4Date2, line5Date2, line6Date2, line7Date2;
    @FXML
    private Label nextRecordIndicator1, nextRecordIndicator2;
    @FXML
    private Label nextCurrentDate1, nextCurrentDate2;
    @FXML
    private Label month1Sales, month2Sales, month3Sales, month4Sales, month5Sales, month6Sales, month7Sales, month8Sales, month9Sales, month10Sales, month11Sales, month12Sales;
    @FXML
    private Label month1recordTotal, month2recordTotal, month3recordTotal, month4recordTotal, month5recordTotal, month6recordTotal, month7recordTotal, month8recordTotal, month9recordTotal, month10recordTotal, month11recordTotal, month12recordTotal;
    @FXML
    private Label grandTotalSales, grandTotalRecords;
    @FXML
    private Label yearDisplay;
    @FXML
    private HBox line1RecSales, line2RecSales, line3RecSales, line4RecSales, line5RecSales, line6RecSales, line7RecSales; 
    @FXML
    private HBox line1RecExpenses, line2RecExpenses, line3RecExpenses, line4RecExpenses, line5RecExpenses, line6RecExpenses, line7RecExpenses;
    @FXML
    private ChoiceBox<String> deleteSelection1, deleteSelection2;
    @FXML
    private Button deleteItem1, deleteItem2;
    @FXML
    private TextField yearSearchBar;
    @FXML
    private Navigator navigator;
    private Charts charts;
    
   
    private SalesRecordComponent salesRecordComponent;
    private RecordSalesHandler recordSalesHandler;
    private RecordExpensesHandler recordExpensesHandler;
    private RecordedSalesHandler recordedSalesHandler;
    private final Date date = new Date();
    
    private final Integer currentUserID = User.getCurrentUserID();
    
    @FXML
    private void initialize() {
        navigator = new Navigator(
            dashboardMenu, recordSalesMenu, recordExpensesMenu, 
            viewSalesMenu, viewExpensesMenu
        );
        
        charts = new Charts(
            barChartDB, pieChartSales, pieChartExpenses
        );
        
        HBox[] linesSales = {
            line1RecSales, line2RecSales, line3RecSales, 
            line4RecSales, line5RecSales, line6RecSales, 
            line7RecSales
        };
        
        HBox[] linesExpenses = {
            line1RecExpenses, line2RecExpenses, line3RecExpenses, 
            line4RecExpenses, line5RecExpenses, line6RecExpenses, 
            line7RecExpenses
        };

        Label[] salesLabel = {
            line1Sales, line2Sales, line3Sales, 
            line4Sales, line5Sales, line6Sales, 
            line7Sales
        };
        
        Label[] expensesLabel = {
            line1Expenses, line2Expenses, line3Expenses,
            line4Expenses, line5Expenses, line6Expenses,
            line7Expenses
        };

        Label[] dateLabelsSales = {
            line1Date1, line2Date1, line3Date1,
            line4Date1, line5Date1, line6Date1,
            line7Date1
        };
        
        Label[] dateLabelsExpenses = {
            line1Date2, line2Date2, line3Date2,
            line4Date2, line5Date2, line6Date2,
            line7Date2
        };
       
        Label[] monthsSales = {
            month1Sales, month2Sales, month3Sales,
            month4Sales, month5Sales, month6Sales,
            month7Sales, month8Sales, month9Sales,
            month10Sales, month11Sales, month12Sales
        };
    
        Label[] recordsTotalSales = {
            month1recordTotal, month2recordTotal, month3recordTotal,
            month4recordTotal, month5recordTotal, month6recordTotal,
            month7recordTotal, month8recordTotal, month9recordTotal,
            month10recordTotal, month11recordTotal, month12recordTotal
        };
        
        recordSalesHandler = new RecordSalesHandler(linesSales, salesLabel, dateLabelsSales, deleteSelection1, deleteItem1, nextRecordIndicator1);
        recordExpensesHandler = new RecordExpensesHandler(linesExpenses, expensesLabel, dateLabelsExpenses, deleteSelection2, deleteItem2, nextRecordIndicator2);
        recordedSalesHandler = new RecordedSalesHandler(monthsSales, recordsTotalSales, grandTotalSales, grandTotalRecords, yearSearchBar, yearDisplay);
        
        String currentDate = date.getCurrentDate();
        
        recordSalesHandler.showNextRecord();
        nextCurrentDate1.setText("Date : " + currentDate);
        
        recordExpensesHandler.showNextRecord();
        nextCurrentDate2.setText("Date : " + currentDate);
        
        yearDisplay.setText("YEAR : " + date.getYear());
        
        Image logoImg = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        logo.setFill(new ImagePattern(logoImg));
        
        System.out.println("user ID = " + currentUserID);
   
        //if(currentUserID == null) Platform.exit();
        
        charts.implementBarChart();
        charts.implementPieSales();
        charts.implementPieExpenses();
        
        addSalesTxtField.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) addSalesTxtField.setText(oldTxt);            
        }); 
        
        addExpensesField.textProperty().addListener((obs, oldTxt, newTxt) -> {
            if(!newTxt.matches("\\d*")) addExpensesField.setText(oldTxt);            
        });
    }
    
    
    @FXML
    private void showDashboardMenu(MouseEvent e) {
        navigator.showDashboardMenu();
    }
    
    @FXML
    private void showRecordSalesMenu(MouseEvent e) {
        navigator.showRecordSalesMenu();
    }
     
    @FXML
    private void showRecordExpensesMenu(MouseEvent e) {
        navigator.showRecordExpensesMenu();
    }
     
    @FXML
    private void showViewSalesMenu(MouseEvent e) {
        navigator.showViewSalesMenu();
    }
      
    @FXML
    private void showViewExpensesMenu(MouseEvent e) {
        navigator.showViewExpensesMenu();
    }
  
    @FXML
    private void getInput(ActionEvent e) {
        if(recordSalesMenu.isVisible()) {
            if(addSalesTxtField.getText().isEmpty()) return;
            recordSalesHandler.getInputSales(addSalesTxtField.getText());
            addSalesTxtField.clear();
            displayRecord();
        }
        
        if(recordExpensesMenu.isVisible()) {
            recordExpensesHandler.getInputExpenses(addExpensesField.getText());
            addExpensesField.clear();           
            displayRecord();
        }       
    } 
    
    @FXML
    private void displayRecord() {
        String currentDate = date.getCurrentDate();
        
        if(recordSalesMenu.isVisible()) {
            recordSalesHandler.showRecordedList();
            String processedInput = recordSalesHandler.getProcessedInput();                     
            recordSalesHandler.showRecordedLine(processedInput, currentDate);           
            recordSalesHandler.showNextRecord();          
            recordSalesHandler.resetInput();        
        }
        
        if(recordExpensesMenu.isVisible()) {
            recordExpensesHandler.showRecordedList();
            String processedInput = recordExpensesHandler.getProcessedInput();
            recordExpensesHandler.showRecordedLine(processedInput, currentDate);
            recordExpensesHandler.showNextRecord();
            recordExpensesHandler.resetInput();
        }    
    }
    
    @FXML
    private void removeRecord() {
        if(recordSalesMenu.isVisible()) recordSalesHandler.deleteRecord();
        if(recordExpensesMenu.isVisible()) recordExpensesHandler.deleteRecord();
    }
    
    @FXML
    private void addToRecordedList() {
        recordSalesHandler.addToRecordedList();   
        recordedSalesHandler.displayRecord();
    }
    
    @FXML
    private void searchYear(KeyEvent event) {
        if(event.getCode() == KeyCode.ENTER) recordedSalesHandler.searchYear();
    }
}