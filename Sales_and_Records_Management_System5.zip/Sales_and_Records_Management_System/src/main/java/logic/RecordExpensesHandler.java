package logic;
import entity.Expenses;
import javafx.collections.FXCollections;


import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class RecordExpensesHandler {
    private String expensesProcessHolder;
    private final Label nextRecordIndicator;
    
    private final HBox[] linesExpenses;
    private final Label[] expensesLabel;
    private final Label[] dateLabel;
    private final ChoiceBox<String> deleteSelection;
    
    private final String[] recordedLines = {"Record #1", "Record #2", "Record #3", "Record #4", "Record #5", "Record #6", "Record #7"};
    
    private final Expenses expenses = new Expenses();

    public RecordExpensesHandler(HBox[] linesExpenses, Label[] expensesLabel, Label[] dateLabel, ChoiceBox<String> deleteSelection, Button deleteItem, Label nextRecordIndicator) {
        this.linesExpenses = linesExpenses;
        this.expensesLabel = expensesLabel;
        this.dateLabel = dateLabel;
        this.deleteSelection = deleteSelection;
        this.nextRecordIndicator = nextRecordIndicator;
    }
    
    public void showNextRecord() {
        for(int i = 0; i < recordedLines.length; i++) {
            if(!linesExpenses[i].isVisible()) {
                String convertedCounter = Integer.toString(i + 1);
                
                nextRecordIndicator.setText("RECORD ID #" + convertedCounter);
                return;
            }   
            nextRecordIndicator.setText("RECORD ID #N/A");
        }
    }
    
    public void showRecordedLine(String processedInput, String date) {
        for(int i = 0; i < linesExpenses.length; i++) {
            if(processedInput != null) {
                if(!linesExpenses[i].isVisible()) {
                    linesExpenses[i].setVisible(true);
                    linesExpenses[i].setManaged(true);
                    expensesLabel[i].setText("PHP" + processedInput);
                    dateLabel[i].setText(date);
                    break;
                }
            }
        }
    }
    
    public void showRecordedList() { 
        int count = 0;  
        for(HBox line : linesExpenses) {
            if(!line.isVisible()) {
                deleteSelection.getItems().add(recordedLines[count]);
                FXCollections.sort(deleteSelection.getItems());
                return;
            }
            count++;         
        }
    }

    public void deleteRecord() {
        if(deleteSelection.getValue() == null) {
            System.out.println("this is null");
            return;
        } 
        
        String selectedValue = deleteSelection.getSelectionModel().getSelectedItem();
        
        for(int i = 0; i < recordedLines.length; i++) {
            if(selectedValue.equals(recordedLines[i])) {
                linesExpenses[i].setVisible(false);
                linesExpenses[i].setManaged(false);
                
                showNextRecord();
                break;
            }
        }
        deleteSelection.getItems().remove(selectedValue);
        deleteSelection.setValue(null);
    }
    
    public void setExpensesProcessHolder(String processedInput) {
        this.expensesProcessHolder = processedInput;
    }
    
  
    public void getInputExpenses(String input) {      
        String stringExpensesInput = input.trim();
        if(stringExpensesInput.isEmpty()) return;

        int integerExpenses = Integer.parseInt(stringExpensesInput);   
        expenses.setExpenses(integerExpenses);
        //database line
        String stringExpenses = Integer.toString(integerExpenses);
        setExpensesProcessHolder(stringExpenses);        
    }
    
    public String getProcessedInput() {
        return expensesProcessHolder;
    }
  
    public void resetInput() {
        expensesProcessHolder = null;
    }
}
