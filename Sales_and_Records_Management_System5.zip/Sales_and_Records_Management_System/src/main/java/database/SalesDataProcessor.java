package database;


import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

public class SalesDataProcessor extends SalesData {
    private static final String INSERT_TO_RECORDED_SALES = "INSERT INTO Recorded_Sales(Year, Month, Sales, Total_Records) "
                                                         + "VALUES(?, ?, ?, ?)";
    
    @Override
    public void createRecSalesData(int year, int month, int sales, int totalRecords){
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(INSERT_TO_RECORDED_SALES)) {
            prst.setInt(1, year);
            prst.setInt(2, (month + 1));
            prst.setInt(3, sales);
            prst.setInt(4, totalRecords);
            
            prst.executeUpdate();
            
            System.out.println("Data Inserted!");
            
        } catch(SQLException exc) {
            System.out.println("Data not Inserted.");
        }
    }

    private static final String READ_RECORD_SALES = "SELECT Month, Sales, Total_Records "
                                                  + "FROM Recorded_Sales "
                                                  + "WHERE Year = ?";
    
    private static final String SUM_SALES = "SELECT SUM(Sales) AS sales, SUM(Total_Records) AS total_records "
                                          + "FROM Recorded_Sales "
                                          + "WHERE Year = ?";
    private final int[] Sales = new int[12];
    private final int[] Total_Records = new int[12];
    private int salesSum, recordsSum;
    @Override
    public void readRecSalesData(int year) {
        try(
            PreparedStatement prstRead = DBConnection.connectTest().prepareStatement(READ_RECORD_SALES);
            PreparedStatement prstSum = DBConnection.connectTest().prepareStatement(SUM_SALES)
            ) {
            prstRead.setInt(1, year);
            prstSum.setInt(1, year);
            
            ResultSet rsRead = prstRead.executeQuery();
            ResultSet rsSum = prstSum.executeQuery();
            
            while(rsRead.next()) {
                int month = rsRead.getInt("Month") - 1;
                Sales[month] = rsRead.getInt("sales");
                Total_Records[month] = rsRead.getInt("total_Records");
            }
            
            if(rsSum.next()) {
                salesSum = rsSum.getInt("Sales");
                recordsSum = rsSum.getInt("Total_Records");
            }
        } catch(SQLException exc) {
            exc.printStackTrace();
        }
    }
    
    private static final String UPDATE_RECORD_SALES = "UPDATE Recorded_Sales "
                                                    + "SET Sales = ?, Total_Records = ? "
                                                    + "WHERE year = ? AND month = ?";
    
    @Override
    public void updateRecSalesData(int year, int month, int sales, int totalRecords) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(UPDATE_RECORD_SALES)) {
            prst.setInt(1, sales);
            prst.setInt(2, totalRecords);
            prst.setInt(3, year);
            prst.setInt(4, (month + 1));
            
            prst.executeUpdate();
            
            System.out.println("Update Successful.");
        } catch(SQLException exc) {
            System.out.println("Failed to Update.");
        }
    }
    
    private static final String CHECK_YEAR_MONTH = "SELECT * "
                                                 + "FROM Recorded_Sales "
                                                 + "WHERE Year = ? AND Month = ?";
    
    @Override
    public boolean existsYearMonth(int year, int month) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(CHECK_YEAR_MONTH)) {
            prst.setInt(1, year);
            prst.setInt(2, month);
            
            ResultSet rs = prst.executeQuery();
            
            return rs.next();
            
        } catch(SQLException exc) {
            System.out.println("Failed to Check Year & Month.");
            return false;
        }       
    }
    
    private static final String CHECK_YEAR = "SELECT Year "
                                           + "FROM Recorded_Sales "
                                           + "WHERE Year = ?";
    
    @Override
    public boolean existsYear(int year) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(CHECK_YEAR)) {
            prst.setInt(1, year);
            
            ResultSet rs = prst.executeQuery();
            
            return rs.next();
            
        } catch(SQLException exc) {
            System.out.println("Failed to Check Year.");
            return false;
        }       
    }

    public int[] getSales() {
        return Sales;
    }

    public int[] getTotal_Records() {
        return Total_Records;
    }

    public int getSalesSum() {
        return salesSum;
    }

    public int getRecordsSum() {
        return recordsSum;
    }
}
