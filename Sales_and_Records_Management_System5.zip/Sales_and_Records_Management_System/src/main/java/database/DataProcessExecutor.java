package database;

public class DataProcessExecutor {
    public void createData(UserData ud, String usernameInput, String passwordInput) {   
        ud.createUsersData(usernameInput, passwordInput);
        System.out.println("executed\n");
    }  
 
    public boolean readData(UserData ud, String user, String pass) {
        boolean readExist = ud.readUsersData(user, pass);
        System.out.println("executed\n");
        return readExist;
    }
     
    public void createData(SalesData sd, int year, int month, int sales, int totalRecords) {
        sd.createRecSalesData(year, month, sales, totalRecords);
        System.out.println("executed\n");
    }
    
    public void readData(SalesData sd, int year) {
        sd.readRecSalesData(year);
    }
    
    public void updateData(SalesData sd, int year, int month, int sales, int totalRecords) {
        sd.updateRecSalesData(year, month, sales, totalRecords);
    }
    
    public boolean valueCheck(SalesData sd, int year, int month) {
        return sd.existsYearMonth(year, month);
    }
    
    public boolean valueCheck(SalesData sd, int year) {
        return sd.existsYear(year);
    }
}
