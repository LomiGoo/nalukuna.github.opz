package entity;

public class Expenses {
     private int expenses;

    public void setExpenses(int expenses) {
        this.expenses = expenses;
    }

    public int getExpenses() {
        return expenses;
    }

}
