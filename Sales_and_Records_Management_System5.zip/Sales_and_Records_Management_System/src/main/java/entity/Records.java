package entity;

public class Records {
    private static int record;

    public static void setRecord(int record) {
        Records.record = record;
    }
    
    public static int getRecord() {
        return record;
    }
}
