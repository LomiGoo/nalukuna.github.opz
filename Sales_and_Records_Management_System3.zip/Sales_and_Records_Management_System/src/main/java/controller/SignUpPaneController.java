package controller;
import logic.UserValidation;
import logic.PasswordValidation;
import util.Transitions;
import database.DataCreate;
import database.UserInputFinalizer;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;


public class SignUpPaneController {
    @FXML
    private Circle loginLogo;
    @FXML
    private Label inputNotify, usernameNotifier, passwordNotifier, passwordShowNotifier;
    @FXML
    private TextField userField, passShownField;
    @FXML
    private VBox vboxPassword, vboxShownPass;
    @FXML
    private PasswordField passField;  
    @FXML
    private CheckBox showPasswordCB;
    @FXML
    private Button signUpButton;
    @FXML
    private Hyperlink loginHyperLink;
    
    private UserValidation validateUser;
    private PasswordValidation validatePass;
    
    @SuppressWarnings("unused")
    @FXML
    private void initialize() {
        validateUser = new UserValidation(userField, usernameNotifier);
        validatePass = new PasswordValidation(passField, passwordNotifier, passwordShowNotifier);
        
        Image imgImage = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        loginLogo.setFill(new ImagePattern(imgImage));
        
        passShownField.textProperty().bindBidirectional(passField.textProperty());

        showPasswordCB.setOnAction(e -> {
            if(showPasswordCB.isSelected()) {
                vboxPassword.setVisible(false);
                vboxPassword.setManaged(false);
                vboxShownPass.setVisible(true);
                vboxShownPass.setManaged(true);
            } else {
                vboxShownPass.setVisible(false);
                vboxShownPass.setManaged(false);
                vboxPassword.setVisible(true);
                vboxPassword.setManaged(true);
            }
        });
        
        validateUser.dynamicValidation();
        validatePass.dynamicValidation();
        
        inputNotify.setOpacity(0);
        signUpButton.setOnAction(e -> {          
                signUpValidate();         
        });
        
        loginHyperLink.setOnAction(e -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/login_pane.fxml"));
                Parent root = loader.load();
                loginHyperLink.getScene().setRoot(root);
                } catch(IOException ex) {
                    System.out.println("Something Went Wrong on Hyper Switch.");
                }
            });
    }
      
    private void signUpValidate() {    
        UserInputFinalizer finalProcess = new DataCreate();
  
        String processedUsername = validateUser.getUsernameInput();
        String processedPassword = validatePass.getPasswordInput();
        
        if(validateUser.validateInput() && validatePass.validateInput() == true) {
            finalProcess.executeCreateData(processedUsername, processedPassword);
            switchToLoginPane();
        }      
    }
    
    private void switchToLoginPane() {
        Transitions fadeTrans = new Transitions();
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/login_pane.fxml"));
        Parent root = loader.load();
        
        LoginPaneController loginControl = loader.getController();
        
        fadeTrans.fade(loginControl.getInputNotify());
        loginControl.getInputNotify().setText("Account Successfully Created.");
        
        signUpButton.getScene().setRoot(root);
        
        } catch(IOException e) {
            System.out.println("Something Went Wrong on Switching.");
        }
    }
}
