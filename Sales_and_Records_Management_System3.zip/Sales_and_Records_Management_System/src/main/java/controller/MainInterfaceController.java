package controller;
import entity.AppSession;

import java.io.IOException;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;

public class MainInterfaceController {
    @FXML
    private Circle logo;
    @FXML
    private BarChart<String, Number> barChartDB;
    @FXML
    private PieChart pieChartSales, pieChartExpenses;
    @FXML
    private AnchorPane dashboardMenu, recordSalesMenu, recordExpensesMenu, viewSalesMenu, viewExpensesMenu;
    
    private Integer currentUserID = AppSession.getCurrentUserID();
    
    public void initialize() {
        Image logoImg = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        logo.setFill(new ImagePattern(logoImg));

        System.out.println("user ID = " + currentUserID);
       
        
        //if(currentUserID == null) Platform.exit();
        
        implementBarChart();
        implementPieSales();
        implementPieExpenses();
    }
   
    public void showDashboardMenu(MouseEvent e) {
        dashboardMenu.setVisible(true);
        recordSalesMenu.setVisible(false);
        recordExpensesMenu.setVisible(false);
        viewSalesMenu.setVisible(false);
        viewExpensesMenu.setVisible(false);
    }
    
     public void showRecordSalesMenu(MouseEvent e) {
        dashboardMenu.setVisible(false);
        recordSalesMenu.setVisible(true);
        recordExpensesMenu.setVisible(false);
        viewSalesMenu.setVisible(false);
        viewExpensesMenu.setVisible(false);
    }
     
      public void showRecordExpensesMenu(MouseEvent e) {
        dashboardMenu.setVisible(false);
        recordSalesMenu.setVisible(false);
        recordExpensesMenu.setVisible(true);
        viewSalesMenu.setVisible(false);
        viewExpensesMenu.setVisible(false);
    }
      
       public void showViewSalesMenu(MouseEvent e) {
        dashboardMenu.setVisible(false);
        recordSalesMenu.setVisible(false);
        recordExpensesMenu.setVisible(false);
        viewSalesMenu.setVisible(true);
        viewExpensesMenu.setVisible(false);
    }
       
        public void showViewExpensesMenu(MouseEvent e) {
        dashboardMenu.setVisible(false);
        recordSalesMenu.setVisible(false);
        recordExpensesMenu.setVisible(false);
        viewSalesMenu.setVisible(false);
        viewExpensesMenu.setVisible(true);
    }
    
    private void implementBarChart() {
        CategoryAxis xAxis = (CategoryAxis) barChartDB.getXAxis();
        xAxis.setLabel("February");
        
        XYChart.Series<String, Number> cashflowSeries = new XYChart.Series<>();
        cashflowSeries.setName("2025 Sales");

        cashflowSeries.getData().add(new XYChart.Data<>("Sales", 100));
        cashflowSeries.getData().add(new XYChart.Data<>("Expenses", 150));
       
        
        barChartDB.getData().addAll(cashflowSeries);
    }
    
    private void implementPieSales() {
        ObservableList<PieChart.Data> pieSales = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 500),
            new PieChart.Data("Feb", 100)
        ); 
        pieChartSales.setData(pieSales);
        pieChartSales.setTitle("INCOME");
    }
    
    private void implementPieExpenses() {
        ObservableList<PieChart.Data> pieExpenses = FXCollections.observableArrayList(
            new PieChart.Data("Jan", 50),
            new PieChart.Data("Feb", 10)
        ); 
        pieChartExpenses.setData(pieExpenses);
        pieChartExpenses.setTitle("EXPENSES");
    }
    
}
