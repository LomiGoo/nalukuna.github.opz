module goat.sales_and_records_management_system {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    
    opens goat.sales_and_records_management_system to javafx.fxml, javafx.graphics;
    opens controller to javafx.fxml;
}
