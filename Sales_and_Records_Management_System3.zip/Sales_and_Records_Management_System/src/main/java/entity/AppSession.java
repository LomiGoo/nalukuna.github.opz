package entity;

public class AppSession {
    private static Integer currentUserID;

    public static void setCurrentUserID(Integer currentUserID) {
        AppSession.currentUserID = currentUserID;
    }

    public static Integer getCurrentUserID() {
        return currentUserID;
    }
    
    public static Integer endSession() {
        return currentUserID = null;
    }
}
