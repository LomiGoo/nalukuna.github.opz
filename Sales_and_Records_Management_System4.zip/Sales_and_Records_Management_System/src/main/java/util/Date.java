package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Date {
    LocalDate date = LocalDate.now();
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    String currentDate = date.format(formatter);

    public String getCurrentDate() {
        return currentDate;
    }
}
