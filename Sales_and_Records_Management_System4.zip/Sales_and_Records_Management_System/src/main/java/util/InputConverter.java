package util;

public class InputConverter {
    public int convertToInteger(String stringInput) {
        int convertedToInt = Integer.parseInt(stringInput);
        return convertedToInt;       
    }
    
    public String convertToString(int integerInput) {
        String convertedToString = Integer.toString(integerInput);
        return convertedToString;
    }
}
