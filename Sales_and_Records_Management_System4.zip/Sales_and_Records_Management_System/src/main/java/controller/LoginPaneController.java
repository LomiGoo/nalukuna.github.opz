package controller;
import database.DataRead;
import database.UserInputFinalizer;
import entity.User;
import util.Transitions;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;


public class LoginPaneController {
   @FXML
    private Circle loginLogo;
    @FXML
    private Label inputNotify, usernameNotifier, passwordNotifier, passwordShowNotifier;
    @FXML
    private TextField userField, passShownField;
    @FXML
    private VBox vboxPassword, vboxShownPass;
    @FXML
    private PasswordField passField;  
    @FXML
    private CheckBox showPasswordCB;
    @FXML
    private Button loginButton;
    @FXML
    private Hyperlink signUpHyperLink;
    
    private final Transitions fadeTrans = new Transitions();
    private User session;
    
    @SuppressWarnings("unused")
    @FXML
    private void initialize() {
        Image imgImage = new Image(getClass().getResourceAsStream("/images/diosarapIcon.png"));
        loginLogo.setFill(new ImagePattern(imgImage));
        
        passShownField.textProperty().bindBidirectional(passField.textProperty());
        showPasswordCB.setOnAction(e -> {
            if(showPasswordCB.isSelected()) {
                vboxPassword.setVisible(false);
                vboxPassword.setManaged(false);
                vboxShownPass.setVisible(true);
                vboxShownPass.setManaged(true);
            } else {
                vboxShownPass.setVisible(false);
                vboxShownPass.setManaged(false);
                vboxPassword.setVisible(true);
                vboxPassword.setManaged(true);
            }
        });
        
        UserInputFinalizer finalProcess = new DataRead();  
        dynamicValidateInput();
        inputNotify.setOpacity(0);
        loginButton.setOnAction(e -> {
            if(!userField.getText().isEmpty() && !passField.getText().isEmpty()){
                boolean inputExists = finalProcess.executeReadData(userField.getText(), passField.getText());
              
                if(inputExists) {
                    System.out.println("INFO EXIST");
                    
                    switchToMainAppPane();
                } else {
                    System.out.println("INFO NOT EXIST");
                }
            }  
        });
        
        signUpHyperLink.setOnAction(e -> {
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/signup_pane.fxml"));
                Parent root = loader.load();
                signUpHyperLink.getScene().setRoot(root);
                } catch(IOException ex) {
                    System.out.println("Something Went Wrong.");
                }
        });
    }
    
    private void validateInput() {       
        String username = userField.getText();
        String password = passField.getText(); 
      
        if(username.isEmpty()) {
            passNotifyOff();
            userNotify("Username Required.");
        } 
        
        if(password.isEmpty()) {
            userNotifyOff();
            passNotify("Password Required.");
        } 
        
        if(!username.isEmpty() && !password.isEmpty()) {
            userNotifyOff();
            passNotifyOff();
        }
    }
    
    private void dynamicValidateInput() {
        userNotify("Username Required.");
        userField.textProperty().addListener((obs, oldTxt, newTxt) -> {         
            validateInput();
        });
        
        passNotify("Password Required.");
        passField.textProperty().addListener((obs, oldTxt, newTxt) -> {          
            validateInput();
        });
    }
    
    private void switchToMainAppPane() {
        try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/goat/sales_and_records_management_system/main_app_interface.fxml"));
        Parent root = loader.load();
        
        loginButton.getScene().setRoot(root);       
        } catch(IOException e) {
            System.out.println("Something Went Wrong on Switching.");
        }
    }
    
    public void userNotify(String message) {
        usernameNotifier.setVisible(true);
        usernameNotifier.setText(message);
    }
    
    public void passNotify(String message) {
        passwordNotifier.setVisible(true);
        passwordNotifier.setText(message);
        passwordShowNotifier.setVisible(true);
        passwordShowNotifier.setText(message);
    }
    
    public void userNotifyOff() {
        usernameNotifier.setVisible(false);
    }
    
    public void passNotifyOff() {
        passwordNotifier.setVisible(false);
        passwordShowNotifier.setVisible(false);
    }
    
    public Label getInputNotify() {
        return inputNotify;
    }
}
