package logic;
import entity.Sales;
import javafx.collections.FXCollections;


import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import util.InputConverter;

public class RecordSalesHandler {
    private String salesProcessHolder;
    private final Label nextRecordIndicator;
    
    private final HBox[] linesSales;
    private final Label[] salesLabel;
    private final Label[] dateLabel;
    private final ChoiceBox<String> deleteSelection;
    
    private final String[] recordedLines = {"Record #1", "Record #2", "Record #3", "Record #4", "Record #5", "Record #6", "Record #7"};
    
    private final InputConverter inputConverter = new InputConverter();
    private final Sales sales = new Sales();

    public RecordSalesHandler(HBox[] linesSales, Label[] salesLabel, Label[] dateLabel, ChoiceBox<String> deleteSelection, Button deleteItem, Label nextRecordIndicator) {
        this.linesSales = linesSales;
        this.salesLabel = salesLabel;
        this.dateLabel = dateLabel;
        this.deleteSelection = deleteSelection;
        this.nextRecordIndicator = nextRecordIndicator;
    }
    
    public void showNextRecord() {
        for(int i = 0; i < recordedLines.length; i++) {
            if(!linesSales[i].isVisible()) {
                String convertedCounter = inputConverter.convertToString(i + 1);
                
                nextRecordIndicator.setText("RECORD ID #" + convertedCounter);
                return;
            }   
            nextRecordIndicator.setText("RECORD ID #N/A");
        }
    }
    
    public void showRecordedLine(String processedInput, String date) {
        for(int i = 0; i < linesSales.length; i++) {
            if(processedInput != null) {
                if(!linesSales[i].isVisible()) {
                    linesSales[i].setVisible(true);
                    linesSales[i].setManaged(true);
                    salesLabel[i].setText("PHP" + processedInput);
                    dateLabel[i].setText(date);
                    break;
                }
            }
        }
    }
    
    public void showRecordedList() { 
        int count = 0;  
        for(HBox line : linesSales) {
            if(!line.isVisible()) {
                deleteSelection.getItems().add(recordedLines[count]);
                FXCollections.sort(deleteSelection.getItems());
                return;
            }
            count++;         
        }
    }

    public void deleteRecord() {
        if(deleteSelection.getValue() == null) {
            System.out.println("this is null");
            return;
        } 
        
        String selectedValue = deleteSelection.getSelectionModel().getSelectedItem();
  
        for(int i = 0; i < recordedLines.length; i++) {
            if(selectedValue.equals(recordedLines[i])) {
                linesSales[i].setVisible(false);
                linesSales[i].setManaged(false);
                
                showNextRecord();
                break;
            }
        }
        deleteSelection.getItems().remove(selectedValue);
        deleteSelection.setValue(null);
    }
    
    public void setSalesProcessHolder(String processedInput) {
        this.salesProcessHolder = processedInput;
    }
    
  
    public void getInputSales(String input) {      
        String stringSalesInput = input.trim();
        if(stringSalesInput.isEmpty()) return;

        int integerSales = inputConverter.convertToInteger(stringSalesInput);   
        sales.setSales(integerSales);
        //database line
        String stringSales = inputConverter.convertToString(integerSales);
        setSalesProcessHolder(stringSales);        
    }
    
    public String getProcessedInput() {
        return salesProcessHolder;
    }
  
    public void resetInput() {
        salesProcessHolder = null;
    }
}
