package entity;

public class Sales {
    private int sales;

    public void setSales(int sales) {
        this.sales = sales;
    }

    public int getSales() {
        return sales;
    }
    
}
