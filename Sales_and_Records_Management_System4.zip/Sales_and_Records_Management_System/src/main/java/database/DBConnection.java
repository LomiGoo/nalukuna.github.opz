package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static final String DB_URL = "jdbc:sqlite:database/Sales and Records Management System.db";
    
    public Connection connectTest() throws SQLException {
        try {       
            Connection connection = DriverManager.getConnection(DB_URL);        
            System.out.println("Connection Successful.");
            return connection;
        } catch(SQLException e) {
            System.out.println("Connection Failed.");
            return null;
        }    
    }
}
