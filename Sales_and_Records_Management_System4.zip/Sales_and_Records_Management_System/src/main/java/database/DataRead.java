package database;
import entity.User;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataRead extends UserInputFinalizer {
    private final DBConnection dbConnect = new DBConnection();
    private final String readDB = ("SELECT * FROM USERS WHERE Username = ? AND Password = ?");
    
    @Override
    public boolean readData(String user, String pass) {
        try {
            PreparedStatement prst = dbConnect.connectTest().prepareStatement(readDB);
            
            prst.setString(1, user);
            prst.setString(2, pass);
            
            ResultSet resultSet = prst.executeQuery();
            
            if(resultSet.next()) {
                System.out.println("user exists");
                int user_ID = resultSet.getInt("User_ID");
                
                User.setCurrentUserID(user_ID);
                return true;
            } else {
                System.out.println("user not found");
                return false;
            }                       
        } catch(SQLException e) {
            System.out.println("Reading Error.");
            return false;
        }
    }
}
