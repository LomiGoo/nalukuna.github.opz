package util;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Date {
    private final LocalDate date = LocalDate.now();
    private final int year = date.getYear();
    private final int month = date.getMonthValue() - 1;
    
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
    String currentDate = date.format(formatter);

    public String getCurrentDate() {
        return currentDate;
    }

    public int getYear() {
        return year;
    }

    public int getMonth() {
        return month;
    }
}
