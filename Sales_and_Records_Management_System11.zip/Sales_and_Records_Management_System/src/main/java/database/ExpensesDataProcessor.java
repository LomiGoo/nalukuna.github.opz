package database;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;

public class ExpensesDataProcessor extends ExpensesData {
    private static final String INSERT_TO_RECORDED_EXPENSES = "INSERT INTO Recorded_Expenses(User_ID, Year, Month, Expenses, Total_Records) "
                                                         + "VALUES(?, ?, ?, ?, ?)";
    
    @Override
    public void createRecExpensesData(int userID, int year, int month, int expenses, int totalRecords){
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(INSERT_TO_RECORDED_EXPENSES)) {
            prst.setInt(1, userID);
            prst.setInt(2, year);
            prst.setInt(3, month);
            prst.setInt(4, expenses);
            prst.setInt(5, totalRecords);
            
            prst.executeUpdate();
            
            System.out.println("Data Inserted!");
            
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
        }
    }

    private static final String READ_RECORD_EXPENSES = "SELECT Month, Expenses, Total_Records "
                                                  + "FROM Recorded_Expenses "
                                                  + "WHERE User_ID = ? AND Year = ?";
    
    private static final String SUM_EXPENSES_YEAR = "SELECT SUM(Expenses) AS expenses, SUM(Total_Records) AS total_records "
                                          + "FROM Recorded_Expenses "
                                          + "WHERE User_ID = ? AND Year = ?";
    private final int[] Expenses = new int[12];
    private final int[] Total_Records = new int[12];
    private int expensesSumYearly, recordsSumYearly;
    
    @Override
    public void readRecExpensesData(int userID, int year) {
        try(
            PreparedStatement prstRead = DBConnection.connectTest().prepareStatement(READ_RECORD_EXPENSES);
            PreparedStatement prstSum = DBConnection.connectTest().prepareStatement(SUM_EXPENSES_YEAR)
            ) {
            prstRead.setInt(1, userID);
            prstRead.setInt(2, year);
            prstSum.setInt(1, userID);
            prstSum.setInt(2, year);
            
            ResultSet rsRead = prstRead.executeQuery();
            ResultSet rsSum = prstSum.executeQuery();
            
            while(rsRead.next()) {
                int month = rsRead.getInt("Month") - 1;
                Expenses[month] = rsRead.getInt("expenses");
                Total_Records[month] = rsRead.getInt("total_Records");
            }
            
            if(rsSum.next()) {
                expensesSumYearly = rsSum.getInt("Expenses");
                recordsSumYearly = rsSum.getInt("Total_Records");
            }
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
        }
    }
    
     private static final String EXPENSES_MONTH = "SELECT Expenses "
                                          + "FROM Recorded_Expenses "
                                          + "WHERE User_ID = ? AND Year = ? AND Month = ?";
    private int expensesSumMonthly;
    
    @Override
    public void readRecExpensesData(int userID, int year, int month) {
        try(
            PreparedStatement prstRead = DBConnection.connectTest().prepareStatement(EXPENSES_MONTH);
            ) {
            prstRead.setInt(1, userID);
            prstRead.setInt(2, year);
            prstRead.setInt(3, month);
            
            ResultSet rsRead = prstRead.executeQuery();
            
            if(rsRead.next()) expensesSumMonthly = rsRead.getInt("Expenses");
            
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
        }
    }
    
    private static final String UPDATE_RECORD_EXPENSES = "UPDATE Recorded_Expenses "
                                                    + "SET Expenses = ?, Total_Records = ? "
                                                    + "WHERE User_ID = ? AND year = ? AND month = ?";
    
    @Override
    public void updateRecExpensesData(int userID, int year, int month, int expenses, int totalRecords) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(UPDATE_RECORD_EXPENSES)) {
            prst.setInt(1, expenses);
            prst.setInt(2, totalRecords);
            prst.setInt(3, userID);
            prst.setInt(4, year);
            prst.setInt(5, month);
            
            prst.executeUpdate();
            
            System.out.println("Update Successful.");
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
        }
    }
    
    private static final String CHECK_YEAR_MONTH = "SELECT * "
                                                 + "FROM Recorded_Expenses "
                                                 + "WHERE User_ID = ? AND Year = ? AND Month = ?";
    
    @Override
    public boolean existsYearMonth(int userID, int year, int month) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(CHECK_YEAR_MONTH)) {
            prst.setInt(1, userID);
            prst.setInt(2, year);
            prst.setInt(3, month);
            
            ResultSet rs = prst.executeQuery();
            
            return rs.next();
            
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
            return false;
        }    
    }
    
    private static final String CHECK_YEAR = "SELECT Year "
                                           + "FROM Recorded_Expenses "
                                           + "WHERE User_ID = ? AND Year = ?";
    
    @Override
    public boolean existsYear(int userID, int year) {
        try(PreparedStatement prst = DBConnection.connectTest().prepareStatement(CHECK_YEAR)) {
            prst.setInt(1, userID);
            prst.setInt(2, year);
            
            ResultSet rs = prst.executeQuery();
            
            return rs.next();
            
        } catch(IOException | SQLException ioEx) {
            ioEx.printStackTrace();
            return false;
        }  
    }

    public int[] getExpenses() {
        return Expenses;
    }

    public int[] getTotal_Records() {
        return Total_Records;
    }

    public int getExpensesSumYearly() {
        return expensesSumYearly;
    }

    public int getRecordsSumYearly() {
        return recordsSumYearly;
    }

    public int getExpensesSumMonthly() {
        return expensesSumMonthly;
    }
}